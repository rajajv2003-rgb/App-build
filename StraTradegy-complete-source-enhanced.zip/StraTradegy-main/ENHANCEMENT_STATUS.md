# StraTradegy enhancement status

## Implemented in this source checkpoint
- Optional TP-before-entry cancellation (default ON), stored on each result.
- Optional BE trigger in R (default OFF), independent of TP RR, for long and short trades.
- Initial risk remains the R denominator; BE exits are 0R.
- Conservative handling of ambiguous same-candle entry/TP and trigger/SL/TP cases.
- Expanded trade CSV with instrument, initial SL, original TP/RR, BE state, final exit,
  final R, exit reason and duration.
- Overall, weekly, monthly and yearly analytics; chronological equity and drawdown.
- Monthly/yearly/equity charts in the Results screen and exported as PNG.
- PDF includes configuration/overall summary, analytics charts and individual trade pages.
- Immutable per-run JSON snapshots; previous runs are not overwritten.
- Saved-run comparison CSV filtered to the selected instrument.
- Instrument selection remains the existing ES/NQ input; no forced combined portfolio.

## Validation completed
- `python -m pytest -q`: 54 passed.
- `python -m compileall -q main.py stratradegy tests`: passed.
- Analytics PDF summary-page smoke test: passed.
- Original unmodified source test suite: 41 passed; the same legacy tests pass in the enhanced tree.

## Not verified / release blocker
- Kivy is not installed in this execution environment, so the Android UI has not been
  launched here.
- Buildozer, Android SDK/NDK and internet access are unavailable in this environment.
  Therefore a new APK could not be compiled or signed here.
- The GitHub Actions workflow remains the intended APK build route. Run the existing
  `Build APK` workflow after pushing this source tree to its GitHub repository, then
  download the `stratradegy-apk` artifact. Do not install the previously uploaded APK
  as if it contained these changes; it is the original APK.
