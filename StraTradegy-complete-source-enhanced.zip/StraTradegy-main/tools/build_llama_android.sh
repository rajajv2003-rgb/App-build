#!/usr/bin/env bash
# Cross-compile llama.cpp for Android (arm64-v8a) and vendor llama-cpp-python's
# pure-Python package, so the APK can run the on-device AI model.
#
#   ANDROID_NDK=/path/to/android-ndk tools/build_llama_android.sh
#
# Produces:
#   libs/arm64-v8a/libllama.so, libggml*.so   -> packaged as native libs (buildozer.spec)
#   vendor/llama_cpp/                          -> Python bindings (ctypes), added to sys.path
#
# The native library is built from the llama.cpp sources bundled inside the same
# llama-cpp-python release, so the Python bindings and the C ABI always match.
set -euo pipefail

VERSION="${LLAMA_CPP_PYTHON_VERSION:-0.3.36}"
NDK="${ANDROID_NDK:-${ANDROID_NDK_LATEST_HOME:-}}"
API="${ANDROID_API:-29}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

if [[ -z "$NDK" || ! -f "$NDK/build/cmake/android.toolchain.cmake" ]]; then
  echo "Set ANDROID_NDK to an Android NDK (r26+ recommended)." >&2
  exit 1
fi

echo ">> fetching llama-cpp-python $VERSION source"
URL="$(python3 -c "import json,sys,urllib.request as u; d=json.load(u.urlopen('https://pypi.org/pypi/llama-cpp-python/$VERSION/json')); print(next(x['url'] for x in d['urls'] if x['packagetype']=='sdist'))")"
curl -sSL -o "$WORK/src.tar.gz" "$URL"
tar -xzf "$WORK/src.tar.gz" -C "$WORK"
SRC="$(find "$WORK" -maxdepth 1 -type d -name 'llama_cpp_python-*' | head -1)"

echo ">> building llama.cpp for arm64-v8a (API $API)"
cmake -S "$SRC/vendor/llama.cpp" -B "$WORK/build" -G "Unix Makefiles" \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM="android-$API" -DANDROID_STL=c++_static \
  -DCMAKE_BUILD_TYPE=Release -DBUILD_SHARED_LIBS=ON \
  -DGGML_NATIVE=OFF -DGGML_OPENMP=OFF -DGGML_CPU_ARM_ARCH=armv8.2-a+dotprod+fp16 \
  -DLLAMA_BUILD_COMMON=OFF -DLLAMA_OPENSSL=OFF -DLLAMA_BUILD_TESTS=OFF -DLLAMA_BUILD_EXAMPLES=OFF \
  -DLLAMA_BUILD_TOOLS=OFF -DLLAMA_BUILD_SERVER=OFF -DLLAMA_BUILD_APP=OFF
cmake --build "$WORK/build" --config Release -j "$(nproc 2>/dev/null || sysctl -n hw.ncpu)" --target llama

mkdir -p "$ROOT/libs/arm64-v8a"
rm -f "$ROOT"/libs/arm64-v8a/lib{llama,ggml}*.so
find "$WORK/build" -name 'lib*.so' \( -name 'libllama.so' -o -name 'libggml*.so' \) -exec cp {} "$ROOT/libs/arm64-v8a/" \;
"$NDK"/toolchains/llvm/prebuilt/*/bin/llvm-strip --strip-unneeded "$ROOT"/libs/arm64-v8a/*.so

echo ">> vendoring the llama_cpp Python package"
rm -rf "$ROOT/vendor/llama_cpp"
mkdir -p "$ROOT/vendor"
cp -r "$SRC/llama_cpp" "$ROOT/vendor/llama_cpp"
rm -rf "$ROOT/vendor/llama_cpp/server"   # the HTTP server needs fastapi; not used

ls -lh "$ROOT/libs/arm64-v8a"
echo ">> done"
