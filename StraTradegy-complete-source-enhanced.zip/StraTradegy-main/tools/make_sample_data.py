"""Generate synthetic 1-minute futures data for testing.

Timestamps are written in America/Chicago (CME exchange time) by default, so a
test run proves the NY conversion and DST handling: 07:00 New York must always
be 06:00 Chicago, across the March/November DST switches.

    python tools/make_sample_data.py --out sample_NQ.csv --start 2024-02-01 --end 2024-04-30
    python tools/make_sample_data.py --style ninja --out sample_ninja.txt
"""

import argparse
import sys
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import numpy as np

STYLES = {
    # header, line formatter
    "iso": "Timestamp,Open,High,Low,Close,Volume",
    "split": "Date,Time,Open,High,Low,Close,Volume",
    "ninja": None,  # headerless "yyyyMMdd HHmmss;o;h;l;c;v", bar CLOSE time
}


def session_minutes(d: date):
    """Globex equity session (Chicago time): Sun 17:00 - Fri 16:00, break 16:00-17:00."""
    wd = d.weekday()
    m = np.arange(1440)
    if wd == 5:  # Saturday
        return m[:0]
    if wd == 6:  # Sunday
        return m[m >= 17 * 60]
    if wd == 4:  # Friday
        return m[m < 16 * 60]
    return m[(m < 16 * 60) | (m >= 17 * 60)]


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="sample_NQ.csv")
    ap.add_argument("--start", default="2024-02-01")
    ap.add_argument("--end", default="2024-04-30")
    ap.add_argument("--price", type=float, default=17500.0)
    ap.add_argument("--style", choices=STYLES, default="iso")
    ap.add_argument("--tz", default="America/Chicago")
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args(argv)

    rng = np.random.default_rng(a.seed)
    tz = ZoneInfo(a.tz)
    d = date.fromisoformat(a.start)
    end = date.fromisoformat(a.end)
    price = a.price
    closed = {date(2024, 1, 1), date(2024, 3, 29), date(2024, 12, 25)}  # full closures
    with open(a.out, "w", newline="") as f:
        if STYLES[a.style]:
            f.write(STYLES[a.style] + "\n")
        while d <= end:
            mins = session_minutes(d) if d not in closed else np.arange(0)
            if len(mins):
                n = len(mins)
                # more volatility around 9:30 ET (= 8:30 CT)
                vol = np.where((mins >= 8 * 60 + 30) & (mins < 10 * 60), 9.0, 3.5)
                steps = rng.normal(0, vol)
                closes = price + np.cumsum(steps)
                opens = np.concatenate([[price], closes[:-1]])
                hi = np.maximum(opens, closes) + np.abs(rng.normal(0, vol * 0.6))
                lo = np.minimum(opens, closes) - np.abs(rng.normal(0, vol * 0.6))
                q = lambda x: np.round(x * 4) / 4
                opens, closes, hi, lo = q(opens), q(closes), q(hi), q(lo)
                vols = rng.integers(50, 3000, n)
                price = float(closes[-1])
                base = datetime(d.year, d.month, d.day)
                for k in range(n):
                    t = base + timedelta(minutes=int(mins[k]))
                    if a.tz != "America/Chicago":
                        t = (t.replace(tzinfo=ZoneInfo("America/Chicago"))
                             .astimezone(tz).replace(tzinfo=None))
                    row = (opens[k], hi[k], lo[k], closes[k])
                    if a.style == "iso":
                        f.write(f"{t:%Y-%m-%d %H:%M:%S},{row[0]:.2f},{row[1]:.2f},{row[2]:.2f},{row[3]:.2f},{vols[k]}\n")
                    elif a.style == "split":
                        f.write(f"{t:%m/%d/%Y},{t:%H:%M},{row[0]:.2f},{row[1]:.2f},{row[2]:.2f},{row[3]:.2f},{vols[k]}\n")
                    else:
                        tc = t + timedelta(minutes=1)  # NinjaTrader labels by bar close
                        f.write(f"{tc:%Y%m%d %H%M%S};{row[0]:.2f};{row[1]:.2f};{row[2]:.2f};{row[3]:.2f};{vols[k]}\n")
            d += timedelta(days=1)
    print(f"wrote {a.out}", file=sys.stderr)


if __name__ == "__main__":
    main()
