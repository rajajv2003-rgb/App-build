[app]

title = StraTradegy
package.name = stratradegy
package.domain = org.stratradegy

source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,ttf
# keep data, tests and build output out of the APK
source.exclude_dirs = tests, tools, samples, out, bin, libs, .venv, .cache, .cache_big, .buildozer, .github, __pycache__, vendor/llama_cpp/server
source.exclude_exts = spec,md,csv,txt
source.exclude_patterns = desktop_test.py

version = 0.1.0

# --- Requirements ----------------------------------------------------------
# kivy       UI
# numpy      cache + vectorised parsing (p4a recipe)
# matplotlib chart rendering, Agg backend (p4a recipe; pulls in freetype, kiwisolver, ...)
# pillow     PNG writing + thumbnails (matplotlib needs it anyway)
# tzdata     IANA timezone database for zoneinfo. REQUIRED: Android's own tz files
#            are not in the format Python's zoneinfo reads. (pytz is not needed.)
# pyjnius / android   Storage Access Framework, MediaStore, share sheet
#
# pandas is deliberately NOT included: the app does not need it (numpy covers the
# chunked CSV parsing and the cache), and the p4a pandas recipe adds ~25 MB plus a
# long, fragile build. pyarrow (Parquet) has no p4a recipe at all.
# On-device AI (llama.cpp): the native engine is cross-compiled by
# tools/build_llama_android.sh into libs/arm64-v8a and the Python bindings are
# vendored in vendor/llama_cpp; these pure-Python packages are what they import.
requirements = python3,kivy==2.3.1,numpy,matplotlib,pillow,tzdata,pyjnius,android,typing-extensions,diskcache,jinja2,markupsafe,certifi

orientation = portrait, landscape
fullscreen = 0

# presplash.filename = %(source.dir)s/assets/presplash.png
# icon.filename = %(source.dir)s/assets/icon.png
android.presplash_color = #0E121B

# --- Android -----------------------------------------------------------------
# No storage permissions are needed:
#  * CSV files are opened with the system file picker (Storage Access Framework)
#  * PNGs are written to Pictures/ through MediaStore (own files, API 29+)
# INTERNET is only used for the optional one-time AI model download.
android.permissions = INTERNET

android.api = 35
android.minapi = 29
# Both target devices (Lenovo Idea Tab, iQOO Neo 10) are 64-bit ARM. One arch
# halves build time and APK size. Add armeabi-v7a only for old 32-bit phones.
android.archs = arm64-v8a
android.accept_sdk_license = True
# llama.cpp engine for the on-device AI (built by tools/build_llama_android.sh)
android.add_libs_arm64_v8a = libs/arm64-v8a/*.so
android.allow_backup = False
android.logcat_filters = *:S python:D

# Use the develop branch only if a recipe (usually matplotlib) fails on master:
# p4a.branch = develop

[buildozer]
log_level = 2
warn_on_root = 1
