"""StraTradegy - Android/desktop entry point (Kivy).

Desktop:  python main.py
Android:  buildozer android debug deploy run   (see README.md)
"""

import os

import sys

# vendored llama-cpp-python bindings (Android build); harmless on desktop
_VENDOR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vendor")
if os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.append(_VENDOR)

def _drop_foreign_extensions():
    """python-for-android sometimes packs a pure-Python package's optional C speedups
    built for the build machine (x86-64), e.g. fontTools/markupsafe. Android can't load
    them and the import fails instead of falling back to the bundled .py version, so
    remove any extension module that is not for this CPU (they only live in our
    private app folder and come back only if the APK is reinstalled)."""
    import struct

    want = {"aarch64": 183, "arm64": 183, "armv7l": 40, "armv8l": 40, "x86_64": 62, "i686": 3}
    machine = want.get(os.uname().machine)
    if machine is None:
        return
    root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_python_bundle", "site-packages")
    for dirpath, _dirs, files in os.walk(root):
        for f in files:
            if not f.endswith(".so"):
                continue
            p = os.path.join(dirpath, f)
            try:
                with open(p, "rb") as fh:
                    head = fh.read(20)
                if head[:4] == b"\x7fELF" and struct.unpack("<H", head[18:20])[0] != machine:
                    os.remove(p)
                    print(f"removed wrong-CPU module {os.path.relpath(p, root)}")
            except OSError:
                pass


if "ANDROID_ARGUMENT" in os.environ or "ANDROID_PRIVATE" in os.environ:
    _drop_foreign_extensions()

if "--cli" in sys.argv:  # desktop backtest, no window (must run before Kivy reads argv)
    from stratradegy.cli import main as _cli_main

    sys.exit(_cli_main(sys.argv[1:]))

from stratradegy.platform_io import app_storage_dir, is_android  # noqa: E402

# matplotlib needs a writable config/font-cache dir; Android's $HOME is not
# writable, which would otherwise rebuild the font cache on every launch.
os.environ.setdefault("MPLCONFIGDIR", os.path.join(app_storage_dir(), "mplconfig"))
os.environ.setdefault("MPLBACKEND", "Agg")

if not is_android():
    from kivy.config import Config

    Config.set("graphics", "width", "1100")
    Config.set("graphics", "height", "860")
    Config.set("input", "mouse", "mouse,multitouch_on_demand")  # no red dots on right-click

from stratradegy.ui.app import StraTradegyApp  # noqa: E402

if __name__ == "__main__":
    StraTradegyApp().run()
