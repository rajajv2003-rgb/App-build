# Updated APK build status

The modified source is ready for an Android build, but no new APK is included in this
package. This execution environment has no Kivy installation, Buildozer, Android SDK/NDK,
or network access to install/download them. The existing uploaded APK is the old build
and must not be represented as containing these changes.

## Build with the included GitHub Actions workflow

1. Push this complete source tree to the StraTradegy GitHub repository (keep
   `.github/workflows/build-apk.yml`, `ci/debug.keystore`, and `tools/build_llama_android.sh`).
2. Open the repository's **Actions** tab.
3. Select **Build APK**.
4. Select **Run workflow** and run it on the intended branch.
5. Wait for the job to finish successfully.
6. Open the successful run and download the `stratradegy-apk` artifact.
7. Install the generated `*-debug.apk` on the Android device.

The workflow builds the debug APK for `arm64-v8a` and checks that it is signed with the
project's fixed debug key. A successful workflow run is required before the APK can be
called built or tested. The app UI and Android runtime still need device validation.
