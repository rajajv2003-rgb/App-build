# StraTradegy

Android app (Kivy + Buildozer) that turns local 1-minute NQ / ES futures CSVs into one
candlestick PNG per trading day, for the 07:00–11:00 New York window (editable), with
labelled lines at 07:00, 08:00, 09:00 and 09:30.

Target devices: Lenovo Idea Tab (main) and iQOO Neo 10 (testing). Both are arm64-v8a,
Android 14/15, so one APK covers both.

```
main.py                         Kivy entry point (Android + desktop)
desktop_test.py                 Desktop test mode: sniff / index / render from the command line
buildozer.spec                  Android build config
stratradegy/
  config.py                     CsvFormat (column mapping), settings, instruments, resolutions
  timeparse.py                  vectorised timestamp parsing, zoneinfo/DST conversion, format detection
  data_loader.py                CSV sniffing, one-time streaming index build, memory-mapped queries
  calendar_us.py                NYSE holiday rules (Good Friday, Juneteenth, observed days, closures)
  chart_renderer.py             matplotlib (Agg) candlestick renderer, dark/light themes
  generator.py                  date range -> PNGs, skip logic, summary, manifest
  platform_io/android_io.py     SAF file picker, fd-based reading, MediaStore saves, share sheet
  platform_io/desktop_io.py     desktop equivalents
  ui/app.py, ui/widgets.py      screens, date/time pickers, pinch-zoom viewer
tests/test_core.py              parsing, DST, holidays, end-to-end pipeline
tools/make_sample_data.py       synthetic 1-minute data (Chicago time, crosses DST)
.github/workflows/build-apk.yml builds the APK in the cloud
```

## 1. Try it on your PC first

```bash
python3 -m venv .venv
```
```bash
.venv/bin/pip install -r requirements-desktop.txt
```

Check that your CSV is read correctly. This prints the detected columns, format and the
first rows converted to New York time:

```bash
.venv/bin/python desktop_test.py sniff --csv /path/to/NQ_1min.csv --tz America/Chicago
```

Render a month (the first run builds the index):

```bash
.venv/bin/python desktop_test.py render --csv /path/to/NQ_1min.csv --tz America/Chicago --instrument NQ --start 2024-03-01 --end 2024-03-31
```

PNGs land in `out/NQ/2024-03-01_to_2024-03-31/`. Add `--pictures ~/Pictures` to also copy
them to `~/Pictures/FuturesCharts/...`, `--window 09:00 12:00` for a custom window,
`--theme light`, `--resolution 2560x1440`. Override anything the auto-detection gets
wrong with `--ts-format "%m/%d/%Y %H:%M"`, `--delimiter ";"`, `--bar-label close`,
`--open-col ...` and so on.

Run the full app UI on the desktop:

```bash
.venv/bin/python main.py
```

Tests:

```bash
.venv/bin/python -m pytest -q
```

No real data handy? `python tools/make_sample_data.py --out samples/test.csv` writes
3 months of synthetic Chicago-time data. A copy is already in `samples/`.

## 2. Build the APK

Buildozer runs on Linux, and on macOS with some setup. It downloads the Android SDK/NDK
(~5 GB) and cross-compiles Python, numpy and matplotlib. The first build takes 40–60
minutes. Later builds take a few minutes.

**Option A, GitHub Actions (easiest from a Mac).** Push the project to a GitHub repo, open
*Actions → Build APK → Run workflow*, then download the `stratradegy-apk` artifact.

**Option B, local Linux, WSL2 or a Linux VM (Ubuntu 22.04):**

```bash
sudo apt install -y git zip unzip openjdk-17-jdk autoconf automake libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev build-essential
```
```bash
pip install --user "buildozer==1.5.0" "Cython==0.29.37" virtualenv setuptools
```
```bash
buildozer -v android debug
```

The APK is written to `bin/stratradegy-0.1.0-arm64-v8a-debug.apk`.

**Option C, Docker.** Use the `kivy/buildozer` image. On Apple Silicon it runs under x86
emulation and is slow.

**Install on the tablet or phone:** enable Developer options → USB debugging, then:

```bash
adb install -r bin/stratradegy-0.1.0-arm64-v8a-debug.apk
```

Or copy the APK over and open it. You will need to allow "Install unknown apps" for your
file manager. To see Python errors from the device:

```bash
adb logcat -s python
```

## 3. Using the app

1. Tap **Add CSV files** and choose your file(s). You can add more later.
2. Check the detected columns, timestamp format and **timezone of the timestamps**, then
   tap **Test parse**. The preview shows the first rows in New York time with the weekday.
   Make sure 09:30 lines up with the cash-open move in your data.
3. Tap **Build index**. This is a one-time streaming pass over the CSV. If the file has a
   contract column, NQ and ES are both indexed in this pass. On the Mac it runs at ~0.8 M bars/s. On the Idea Tab, expect 1–3 minutes. Keep
   the app in the foreground (the screen stays on during the job).
4. Choose the date range and window. The home screen shows a **live preview** of the real
   chart and a **calendar heatmap** of the range: each trading day is green or red by its
   window return, holidays are outlined in amber, and days without data are hatched. Tap a
   day to preview it. The render button shows the exact number of PNGs. Tap **Render**. A progress bar and live preview
   are shown, followed by a summary of charts made and days skipped (weekend, holiday,
   no data).
5. **Gallery** lists every run. Tap a chart to open it full screen, then pinch or
   double-tap to zoom, swipe or use Prev/Next, and tap **Share**.

Output: `Pictures/FuturesCharts/<NQ|ES>/<start>_to_<end>/NQ_2024-03-15.png`. Charts are
visible in Google Photos and the Gallery app right away (MediaStore). Re-running the same
range overwrites the files.

## Backtest (pre-market sweep + FVG)

The **Backtest** button in the top bar opens one settings screen: your data, NQ/ES, date
range, Model 1/2 and risk-to-reward. Results come in two tabs. **Summary** has the counts,
win rate and streaks. **Trades** is the table; tap a trade to see its chart.
**Download CSV** saves the trade table and a day-by-day log (with the contract used each
day), and **Download PDF** saves one chart page per trade, both to
`Download/NQES_Backtest/<instrument>_<start>_to_<end>/`. The exact rules and how each
ambiguity in the original request was resolved are in
[docs/BACKTEST_SPEC.md](docs/BACKTEST_SPEC.md). They are also shown in the app under
**Strategy rules**. All of the logic is in `simulate_day()` in `stratradegy/backtest.py`.

Desktop check before building the APK (same engine):

```bash
.venv/bin/python main.py --cli --csv ~/Downloads/glbx-mdp3-20110101-20261107.ohlcv-1m.csv --instrument NQ --start 2026-05-11 --end 2026-11-06 --model 1 --rr 2
```

### Test plan

1. Run the unit tests (`.venv/bin/python -m pytest -q`). `tests/test_backtest.py` covers
   FVG detection, both models, cancellation (TP before fill, 11:00), same-candle SL+TP,
   Open at 11:00, ambiguous days, DST dates in March and November, contract choice by
   07:00–11:00 volume, spread filtering and streaks.
2. Run the CLI command above. Open `trades.csv` and `charts.pdf`, then check three or
   four trades by hand against the chart (PMH/PML, sweep, FVG, entry, fill, exit).
3. On the phone, run the same settings in the app. The counts must match the CLI output.
4. Tap **Download CSV** and **Download PDF**. Check that the files appear in Files →
   Download → NQES_Backtest and that **Open PDF** opens them.
5. Try a bad RR (empty or 0), a date range with no data, and Model 2. Each must show a
   clear message or result.

## Several CSV files

Step 1 on the home screen is a file list. Tap **Add CSV files** as often as you like.
Each file keeps its own detected format, so you can mix a Databento export with a
NinjaTrader or TradeStation file, or keep one file per year. Files without a contract
column get an NQ/ES switch. You can turn a file off without removing it, and
**Check format** opens that file's column mapping. When the list changes, tap
**Prepare data** once: all enabled files are merged, overlapping minutes are
de-duplicated, and every chart still uses one contract.

## On-device AI ("Explain this day")

* **What the data says** is computed by the app (`stratradegy/analysis.py`) and is always
  exact: the result, high and low times, previous close and overnight range, the move into
  09:30, the opening range and which side broke first, trend vs. chop, the range compared
  with the last 20 days, and the fastest 5-minute move.
* **Ask the AI** runs a small Qwen2.5 model (Apache-2.0, GGUF) through llama.cpp, fully
  offline. The model only sees the facts relevant to your question and is told to copy
  numbers exactly. Any number in an answer that is not in the data is flagged.
  Download it in the app (0.5B = 491 MB, faster; 1.5B = 1.1 GB, clearly better answers),
  or pick a `.gguf` file you already have.
* Tiny models can still mix things up (for example, calling the overnight high the 9:30
  price). Treat AI answers as a reading aid; the details list is the source of truth.
  The AI describes what happened and never recommends trades.
* Desktop: `pip install llama-cpp-python==0.3.36`. Android: `tools/build_llama_android.sh`
  cross-compiles llama.cpp with the NDK into `libs/arm64-v8a/` and vendors the bindings.
  The GitHub workflow runs it automatically before Buildozer.

## Your data: Databento GLBX.MDP3 `ohlcv-1m`

`glbx-mdp3-20110101-20261107.ohlcv-1m.csv` (1.7 GB) is detected automatically. Nothing
needs to be typed in:

| Setting | Value |
|---|---|
| Timestamp | `ts_event`, ISO-8601 UTC with nanoseconds (`2011-01-02T23:00:00.000000000Z`). It marks the bar open. |
| Prices / volume | `open high low close` / `volume` |
| Contract | `symbol`, e.g. `NQH4`, `ESZ4`, plus calendar spreads such as `ESZ4-ESH5` |

The file holds **both NQ and ES, every listed contract month, and calendar spreads**,
so several rows share each minute. The app:

* indexes NQ and ES in **one pass** (a single import fills both instruments),
* drops spreads and any other roots (micros like MNQ would be kept separate),
* keeps all contract months, and for each chart uses **the contract with the most
  volume inside that day's window**. A chart never mixes contracts around a roll.
  On 16 Dec 2024, for example, ES had already rolled to ESH5 while NQ was still
  NQZ4. The contract appears in the chart subtitle and in the gallery.

The full file indexes in ~20 s on an M-series Mac; expect a few minutes on the tablet.
Because back months are kept, the on-device cache is roughly 0.5–0.7 GB for both
instruments.

## How it handles the hard parts

* **2 GB of CSV.** The CSV is never loaded whole. It is streamed in 8 MB chunks, parsed
  with numpy, and written to a column cache (`ts.npy`, `open.npy`, …) in the app's private
  storage. Queries memory-map the cache and binary-search the timestamps, so a single
  day's window takes under a millisecond. The cache for 15 years of one instrument is
  about 220–260 MB (with volume).
* **Timezones and DST.** Every timestamp is converted once to UTC with `zoneinfo`, using
  the source timezone you choose. Each day's window is then computed as
  `datetime(day, 07:00, America/New_York)`. 07:00 is therefore always 07:00 New York time,
  whether the data is in Chicago time, UTC or NY time, and across both DST switches.
  `tests/test_core.py` checks this on both sides of the March and November changes.
* **Bar timestamp convention.** Some vendors stamp a 1-minute bar with its close time
  (NinjaTrader: 09:31 = the 09:30 candle). Set "Bar time marks the bar's: close" and the
  app shifts by one minute, so the window and the 09:30 line stay exact.
* **Holidays.** CME equity futures still trade on several stock-market holidays (MLK Day,
  Presidents Day, …), so "has data" alone would produce extra charts. The app skips
  NYSE holidays by rule, including Good Friday, Juneteenth from 2022, observed
  Fri/Mon days and special closures. You can turn this off. Days with no bars in the
  window are always skipped. March 2024 gives 20 charts and July 2024 gives 22.
* **Scoped storage.** No storage permissions are requested. Reading uses the system
  picker (SAF) with a persistable grant and reads straight from the file descriptor, so
  the CSV is not copied. Writing goes through MediaStore with `RELATIVE_PATH`.
  Sharing passes the MediaStore URI, so no FileProvider is needed.

## Limitations and alternatives

* **Build weight.** matplotlib and numpy make the APK ~60–80 MB, and the first build is
  long. If the matplotlib recipe fails, set `p4a.branch = develop` in `buildozer.spec`.
  Delete `.buildozer/` before rebuilding after requirement changes.
* **pandas / Parquet are intentionally not used on Android.** pyarrow has no
  python-for-android recipe. The pandas recipe works only sometimes and adds a lot of
  size. The numpy cache replaces both and is faster for this access pattern. pandas is
  only useful on the desktop.
* **Speed on the Idea Tab** (Dimensity-class CPU): roughly 0.5–1 s per chart at
  1920×1080, so about 20 s for a month and a few minutes for a year. 3840×2160 is
  about 3× slower.
* **Background work.** iQOO (OriginOS/Funtouch) and some Lenovo builds kill background
  apps aggressively. Keep the app open during long jobs, or exclude it from battery
  optimisation.
* **Your Databento file is damaged in two places.** It has ~130 MB of zero bytes, so there
  is no data for 2017-01-05 to 2017-08-22 or 2022-02-16 to 2022-08-28. The Drive copy has
  the same holes. The app skips the zeroed blocks safely and lists the gaps on the home
  screen; a fresh export from Databento fills them.
* **Reinstalling the app** loses ownership of earlier MediaStore files. A later re-run of
  the same range then creates `NQ_2024-03-15 (1).png` instead of overwriting. Delete the
  old folder in the Gallery app first.
* **Windows past midnight** (e.g. 18:00–02:00) are not supported. The end must be after
  the start on the same day.
* **Ambiguous DST hour.** The fall-back hour (01:00–02:00 local) resolves to its first
  occurrence. CME is closed then, so this never affects real data.
* **Alternatives if Kivy/Buildozer gets painful:** *Chaquopy* (Python inside a native
  Android Studio app, with ready wheels for pandas, pyarrow and matplotlib) or *BeeWare
  Briefcase*. For no build at all, run `desktop_test.py` in *Termux* or *Pydroid 3* on the
  tablet.

### Enhanced backtest analytics and model snapshots

Each completed run now writes an immutable JSON snapshot under the app's private
`backtest/run_history/` directory. The snapshot includes the selected instrument,
model, target RR, BE setting/trigger, TP-before-entry cancellation setting, date range,
trade records and summary metrics. Re-running the same model creates a new snapshot;
it does not replace the prior one. The CSV export includes a saved-model comparison
for the selected instrument.

The Results summary now builds equity, monthly and yearly performance charts. CSV
export includes trade history, day log, overall metrics, weekly/monthly/yearly tables,
instrument metrics, chronological equity, saved-model comparison and three PNG charts.
The PDF begins with the performance/configuration summary and analytics charts, then
continues with the individual trade chart pages.

Execution note: if a candle touches both a pending limit entry and its TP before the
order's intrabar sequence can be established, the engine does not assume a favourable
fill. With TP-before-entry cancellation ON it cancels the setup; with the setting OFF
it marks the setup ambiguous/unresolved. Such a setup is not included in realised R.
Maximum drawdown percentage is measured relative to a prior positive cumulative-R
peak; it is not a compounded account-equity return percentage.
