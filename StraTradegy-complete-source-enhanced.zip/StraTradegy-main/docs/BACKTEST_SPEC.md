# StraTradegy: Backtest feature brief

This is the client's backtester request, rewritten for StraTradegy. Most of the
infrastructure already exists, so this brief only describes what is new and how it
plugs into the app.

## What already exists and is reused

| Client requirement | Already in StraTradegy |
|---|---|
| Databento 1-min OHLCV CSV, up to ~2 GB, streamed, no pandas | CSV library + one-time streaming index (`data_loader.py`) |
| UTC → America/New_York with DST | `timeparse.py` (zoneinfo + tzdata, tested on both DST switches) |
| Ignore spreads, accept only `NQ/ES + month code + year digit` | `parse_contract()`; spreads such as `NQZ6-NQH7` are dropped at import |
| One contract per day = highest 07:00–11:00 volume | `BarStore.window()` already picks the highest-volume contract in a window |
| Background thread + progress bar | `ProgressScreen` + worker threads |
| Save files on Android 11+ without permissions | MediaStore (scoped storage) |
| matplotlib (Agg) candlestick charts | `chart_renderer.py` |
| Desktop test mode | `desktop_test.py` / `python main.py` |
| APK build without a Linux machine | GitHub Actions workflow (`.github/workflows/build-apk.yml`) |

## New: the Backtest screen (one screen)

1. **Data**: the files already added in the app (same "Add CSV files" picker, so a ~2 GB file works).
2. **Instrument**: NQ / ES.
3. **Date range**: start / end date pickers.
4. **Model**: Model 1 or Model 2.
5. **Risk-to-reward**: a decimal you type (for example 2 or 1.5).
6. **Run backtest**: runs in the background with a progress bar.
7. **Strategy rules**: a button that shows the rules below in plain language.

## Strategy rules (New York time; candles are stamped with their open time)

1. **Pre-market range.** PMH is the highest high and PML the lowest low of the candles from 07:00 to 09:29.
2. **First sweep from 09:30.** The first candle from 09:30 onward with high > PMH means look **short**. The first with low < PML means look **long**. Only the first sweep counts.
3. **Ambiguous day.** If one candle takes both PMH and PML, the day is skipped and logged as *Ambiguous*.
4. **First FVG in the trade direction after the sweep**, using 3-candle logic:
   - Bullish FVG (long): low of candle 3 > high of candle 1.
   - Bearish FVG (short): high of candle 3 < low of candle 1.
   - The sweep candle may be candle 1, 2 or 3. The FVG is confirmed when candle 3 closes.
5. **Limit order** (at most one per day), active from the candle after candle 3:
   - Model 1: entry = open of candle 3.
   - Model 2: entry = low of candle 3 (long) / high of candle 3 (short).
   - Both models: SL = low of candle 2 (long) / high of candle 2 (short).
   - Risk = |entry − SL|. TP = entry ± RR × risk.
6. **Cancellation.** The order is cancelled if price reaches TP before it fills, or if it has not filled by 11:00.
7. **Fill.** A long fills when a candle's low ≤ entry. A short fills when a candle's high ≥ entry.
8. **Outcome**, checked from the fill candle onward:
   - Only SL touched = **Loss**.
   - Only TP touched = **Win**.
   - SL and TP in the same candle = **Both Hit (Same Candle)**.
   - Neither by 11:00 = **Open at 11:00**.
   - Both Hit and Open at 11:00 count as neither a win nor a loss.

## Decisions on ambiguous points (shown in the app's rules screen)

1. **"The sweep candle may be candle 1, 2 or 3" vs "no FVG candles before the sweep candle".**
   These contradict each other if the sweep is candle 2 or 3. Resolved as: the FVG must
   *include or follow* the sweep candle. Candle 3 is at or after the sweep, and candle 1
   is at most two candles before it. An FVG that completed before the sweep never counts.
2. **Fill and TP in the same candle.** The rules say to check the fill candle itself for
   SL/TP, so in a candle that reaches the entry, the fill happens first. The "TP before
   fill" cancellation only applies to candles that touch TP *without* reaching the entry.
3. **11:00 cutoff.** The last candle used is the one stamped 10:59. An FVG whose candle 3
   is 10:59 still creates an order, but it can never fill, so it is counted as
   *cancelled (not filled by 11:00)*.
4. **Zero or negative risk** (entry at or beyond SL, which is possible with Model 1): no
   order is placed and the day is logged as *Invalid order (zero risk)*. It is not counted
   as a limit order.
5. **Contract per day.** This is chosen once per day from total 07:00–10:59 volume, and
   PMH/PML, sweep, FVG and trade all use that contract. The contract is written in the
   trade table and the day log.
6. **US market holidays** (for example Good Friday, Thanksgiving) are skipped by default,
   because there is no 09:30 cash open. Weekends and days without data are always
   skipped. A setting turns holiday skipping off.
7. **Missing data.** A day with no pre-market candles or no candles after 09:30 is logged
   as *No data*. Gaps in the damaged parts of the Databento file therefore show up here.
8. **Streaks** use only Win and Loss trades in date order. Both Hit and Open at 11:00 are
   skipped and neither break nor extend a streak. "Shortest" is the smallest streak of
   that type (minimum 1). If there are no streaks of a type, it shows "–".
9. **Points.** "Entry-to-SL points" = risk. "Entry-to-TP points" = RR × risk.

## Outputs

**Summary on screen:** limit orders, filled, not filled / cancelled (TP before fill,
11:00 cutoff), take profits, stop losses, Both Hit, Open at 11:00, ambiguous days,
no-sweep days, no-FVG days, win rate = TP / (TP + SL), and longest / shortest winning
and losing streaks.

**Trade table** (scrollable): Date, Day, Contract, Direction, Outcome, Entry-to-SL points,
Entry-to-TP points. **Download CSV** saves it, plus a day-by-day log, to
`Download/NQES_Backtest/<instrument>_<start>_to_<end>/` and shows the saved path.

**Download PDF**: one page per filled trade in date order. An *Include cancelled orders*
checkbox adds pages for cancelled orders. Each page shows 07:00–11:00 1-minute candles
with PMH, PML, the 09:30 line, the FVG shaded, entry, SL and TP with prices, and the fill
and exit candles marked. The title has the date, day, instrument, contract, direction,
model, RR and outcome. Pages are rendered at 1920×1080, 200 dpi, one page at a time to
keep memory low. The PDF goes to the same folder as the CSV.

## Desktop test mode

    python main.py --cli --csv file.csv --instrument NQ --start 2026-05-11 --end 2026-11-06 --model 1 --rr 2

This runs the same engine, indexes the CSV if needed, and writes the CSV, day log and PDF
to `./backtest_out/NQES_Backtest/<instrument>_<start>_to_<end>/`.

## Tests

FVG detection; both entry models; cancellation (TP before fill, 11:00 cutoff); same-candle
SL+TP; Open at 11:00; ambiguous PMH/PML day; DST dates (March and November); contract
choice by 07:00–11:00 volume; spread filtering; streaks that skip excluded trades.

## Build

There are no new Android libraries. Everything uses packages already in the APK (numpy,
matplotlib, Pillow, tzdata, pyjnius). The APK is built by the existing GitHub Actions
workflow.
