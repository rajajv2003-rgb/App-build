from types import SimpleNamespace
from stratradegy.advanced_analytics import monthly_summary, render_analytics_charts
from stratradegy.run_history import save_run, load_runs, compare_runs
from stratradegy.backtest import BacktestResult


def _trade(day, outcome, rr=2, final_r=None, time='09:45'):
    return SimpleNamespace(date=day, fill_time=time, outcome=outcome, rr=rr,
        final_r=final_r if final_r is not None else (rr if outcome=='Win' else -1 if outcome=='Lose' else 0),
        status='filled', be_activated=False, instrument='ES')


def test_monthly_summary_and_charts(tmp_path):
    trades=[_trade('2025-01-02','Lose'), _trade('2025-01-03','Lose'), _trade('2025-02-03','Win',3)]
    m=monthly_summary(trades)
    assert m['best_month']=='2025-02' and m['worst_month']=='2025-01'
    assert m['profitable_months']==1 and m['losing_months']==1
    files=render_analytics_charts(trades, str(tmp_path))
    assert len(files)==3 and all(__import__('os').path.getsize(p)>0 for p in files)


def test_run_history_is_immutable_and_comparable(tmp_path):
    r=BacktestResult('ES','2025-01-01','2025-01-31',1,2,True,None)
    r.trades=[_trade('2025-01-02','Win')]
    p1=save_run(r,str(tmp_path)); p2=save_run(r,str(tmp_path))
    assert p1 != p2
    runs=load_runs(str(tmp_path)); assert len(runs)==2
    rows=compare_runs(str(tmp_path),'ES')
    assert len(rows)==2 and rows[0]['instrument']=='ES' and rows[0]['total_trades']==1


def test_performance_sort_options():
    from stratradegy.advanced_analytics import sort_grouped_performance
    rows=[{"period":"2025-01","net_r":1,"win_rate":.5},
          {"period":"2025-02","net_r":-2,"win_rate":.2},
          {"period":"2025-03","net_r":3,"win_rate":.8}]
    assert sort_grouped_performance(rows,"best")[0]["period"]=="2025-03"
    assert sort_grouped_performance(rows,"worst")[0]["period"]=="2025-02"
    assert sort_grouped_performance(rows,"highest_win_rate")[0]["period"]=="2025-03"
    assert sort_grouped_performance(rows,"lowest_win_rate")[0]["period"]=="2025-02"
