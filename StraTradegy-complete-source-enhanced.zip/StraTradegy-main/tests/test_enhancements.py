from datetime import date
import numpy as np
from stratradegy import backtest as bt

def _day(rth):
    rows=[(105.,106.,104.,105.)]*150
    rows[10]=(105.,110.,104.,105.)
    rows[20]=(105.,106.,100.,105.)
    rows+=rth
    a=np.array(rows,float)
    return np.arange(420,420+len(rows)),a[:,0],a[:,1],a[:,2],a[:,3]

LONG=[(102.,104.,99.,103.),(103.,103.,101.5,102.5),(102.5,108.,101.,107.5),(106.,109.,104.,108.5)]
FLAT=(105.,106.,104.,105.)

def test_be_activation_then_exit():
    r=bt.simulate_day(*_day(LONG+[(106.,108.,105.,107.),(108.,112.,107.,111.),(107.,108.,105.,106.)]),1,2.,True,1.)
    assert r.be_activated and r.outcome==bt.BREAKEVEN and r.final_exit==106.

def test_be_activation_then_tp():
    r=bt.simulate_day(*_day(LONG+[(106.,108.,105.,107.),(108.,112.,107.,111.),(111.,117.,110.,116.)]),1,2.,True,1.)
    assert r.be_activated and r.outcome==bt.WIN and r.final_exit==116.

def test_original_sl_before_trigger():
    r=bt.simulate_day(*_day(LONG+[(106.,108.,100.,101.)]),1,2.,True,1.)
    assert not r.be_activated and r.outcome==bt.LOSE

def test_cancel_tp_toggle():
    candles=LONG+[(108.5,117.,107.,116.),(106.,107.,100.,101.)]
    a=bt.simulate_day(*_day(candles),1,2.,True,None)
    b=bt.simulate_day(*_day(candles),1,2.,False,None)
    assert a.outcome==bt.CANCEL_TP and b.status=="filled"



def test_analytics_chronological_curve():
    from types import SimpleNamespace
    from stratradegy.advanced_analytics import equity_metrics, grouped_performance
    trades=[SimpleNamespace(date="2026-01-02",outcome="Win",rr=2.,fill_time="09:40"),
            SimpleNamespace(date="2026-01-05",outcome="Lose",rr=2.,fill_time="09:45"),
            SimpleNamespace(date="2026-01-06",outcome="Breakeven",rr=2.,fill_time="09:50")]
    m=equity_metrics(trades)
    assert m["net_r"]==1.0 and m["max_drawdown_r"]==1.0
    assert m["wins"]==1 and m["losses"]==1 and m["breakeven"]==1
    assert len(grouped_performance(trades,"weekly"))==2


def test_analytics_zero_trade_and_zero_loss_cases():
    from stratradegy.advanced_analytics import equity_metrics
    empty = equity_metrics([])
    assert empty["trades"] == 0
    assert empty["win_rate"] is None
    assert empty["profit_factor"] is None
    from types import SimpleNamespace
    one_win = SimpleNamespace(date="2026-02-02", fill_time="09:45", outcome="Win", rr=2,
                              final_r=2, status="filled")
    m = equity_metrics([one_win])
    assert m["net_r"] == 2
    assert m["profit_factor"] == float("inf")
    assert m["max_drawdown_r"] == 0


def test_analytics_uses_final_r_and_counts_unfilled_separately(tmp_path):
    from types import SimpleNamespace
    from stratradegy.advanced_analytics import equity_metrics, write_metrics_csv, write_equity_csv
    trades = [
        SimpleNamespace(date="2026-03-02", fill_time="09:40", outcome="Win", rr=3,
                        final_r=3, status="filled"),
        SimpleNamespace(date="2026-03-03", fill_time="09:40", outcome="Breakeven", rr=3,
                        final_r=0, status="filled"),
        SimpleNamespace(date="2026-03-04", fill_time="", outcome="Cancelled: TP before fill",
                        rr=3, final_r=0, status="cancelled"),
    ]
    m = equity_metrics(trades)
    assert m["trades"] == 2 and m["cancelled_unfilled"] == 1
    assert m["net_r"] == 3 and m["breakeven"] == 1
    assert m["win_rate"] == 1.0
    assert len(m["equity_curve"]) == 2
    assert write_metrics_csv(m, str(tmp_path / "summary.csv"))
    assert write_equity_csv(m, str(tmp_path / "equity.csv"))


def test_entry_and_tp_same_candle_is_not_assumed_favourable():
    # The order is first eligible after the FVG; one bar spans both entry and TP.
    candles = LONG + [(108.0, 117.0, 105.0, 116.0)]
    on = bt.simulate_day(*_day(candles), 1, 2.0, True, None)
    off = bt.simulate_day(*_day(candles), 1, 2.0, False, None)
    assert on.status == "cancelled" and on.outcome == bt.CANCEL_TP
    assert off.status == "ambiguous" and "same candle" in off.outcome


def test_short_be_activation_then_be_exit_and_tp():
    short_setup = [
        (108., 111., 107., 107.5),
        (107.5, 107.8, 102., 102.5),
        (103., 106., 101., 101.5),
    ]
    # Model 1 entry=103, initial SL=107.8, trigger at 1R=98.2.
    be_exit = short_setup + [(103.,104.,102.,103.), (99.,102.,97.,98.), (101.,104.,99.,103.)]
    r = bt.simulate_day(*_day(be_exit), 1, 2., True, 1.)
    assert r.be_activated and r.outcome == bt.BREAKEVEN and r.final_exit == 103.
    tp_exit = short_setup + [(103.,104.,102.,103.), (99.,102.,97.,98.), (96.,99.,92.,94.)]
    r = bt.simulate_day(*_day(tp_exit), 1, 2., True, 1.)
    assert r.be_activated and r.outcome == bt.WIN


def test_be_trigger_is_independent_of_target_rr():
    candles = LONG + [(106.,108.,105.,107.), (108.,112.,107.,111.), (111.,114.,110.,113.), (114.,122.,113.,121.)]
    r = bt.simulate_day(*_day(candles), 1, 3., True, 1.5)
    assert r.be_activated and r.outcome == bt.WIN
    assert r.tp == 121.  # original 3R target remains unchanged
