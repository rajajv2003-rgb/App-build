import os
from datetime import date, datetime, time as dtime, timedelta, timezone
from zoneinfo import ZoneInfo

import numpy as np
import pytest

from stratradegy.calendar_us import holiday_name, nyse_holidays
from stratradegy.chart_renderer import ny_epoch
from stratradegy.config import CsvFormat
from stratradegy.data_loader import BarStore, CacheBuilder, CsvFormatError, Source, read_head, sniff
from stratradegy.generator import GenerateRequest, run_generation
from stratradegy.timeparse import detect_format, parse_timestamps

NY = ZoneInfo("America/New_York")


def utc(dt_local, tz):
    return int(dt_local.replace(tzinfo=ZoneInfo(tz)).timestamp())


# ---------------------------------------------------------------- timestamps
@pytest.mark.parametrize("fmt,s,expected", [
    ("%Y-%m-%d %H:%M:%S", "2024-03-15 07:00:00", datetime(2024, 3, 15, 7)),
    ("%m/%d/%Y %H:%M", "03/15/2024 07:05", datetime(2024, 3, 15, 7, 5)),
    ("%m/%d/%Y %H:%M", "3/5/2024 7:05", datetime(2024, 3, 5, 7, 5)),  # non-padded fallback
    ("%Y%m%d %H%M%S", "20240315 070000", datetime(2024, 3, 15, 7)),
    ("%d.%m.%Y %H:%M", "15.03.2024 07:00", datetime(2024, 3, 15, 7)),
])
def test_parse_formats_ny(fmt, s, expected):
    ts, ok = parse_timestamps([s], fmt, "America/New_York")
    assert ok.all()
    assert ts[0] == utc(expected, "America/New_York")


def test_invalid_rows_flagged():
    ts, ok = parse_timestamps(["2024-02-30 07:00:00", "garbage", "2024-02-29 07:00:00"],
                              "%Y-%m-%d %H:%M:%S", "UTC")
    assert ok.tolist() == [False, False, True]


def test_dst_chicago_to_ny():
    # 06:00 Chicago is 07:00 New York both before and after the 2024-03-10 switch
    for d in (date(2024, 3, 8), date(2024, 3, 11), date(2024, 11, 1), date(2024, 11, 4)):
        s = f"{d.isoformat()} 06:00:00"
        ts, _ = parse_timestamps([s], "%Y-%m-%d %H:%M:%S", "America/Chicago")
        assert datetime.fromtimestamp(int(ts[0]), NY).time() == dtime(7, 0)


def test_utc_source_dst():
    # 07:00 NY = 12:00 UTC in winter, 11:00 UTC in summer
    w, _ = parse_timestamps(["2024-01-10 12:00:00"], "%Y-%m-%d %H:%M:%S", "UTC")
    s, _ = parse_timestamps(["2024-07-10 11:00:00"], "%Y-%m-%d %H:%M:%S", "UTC")
    assert datetime.fromtimestamp(int(w[0]), NY).hour == 7
    assert datetime.fromtimestamp(int(s[0]), NY).hour == 7


def test_iso_offsets_and_epoch():
    ts, ok = parse_timestamps(["2024-03-15T11:00:00Z", "2024-03-15T07:00:00-04:00"], "iso8601", "UTC")
    assert ok.all() and ts[0] == ts[1]
    ts2, _ = parse_timestamps([str(int(ts[0]) * 1000)], "epoch_ms", "UTC")
    assert ts2[0] == ts[0]


def test_detect():
    assert detect_format(["2024-03-15 07:00:00"])[0] == "%Y-%m-%d %H:%M:%S"
    assert detect_format(["20240315 0700"])[0] == "%Y%m%d %H%M"  # not %H%M%S
    assert detect_format(["15/03/2024 07:00"])[0] == "%d/%m/%Y %H:%M"
    assert detect_format(["1710500400"])[0] == "epoch_s"


# ---------------------------------------------------------------- calendar
def test_holidays():
    assert holiday_name(date(2024, 3, 29)) == "Good Friday"
    assert holiday_name(date(2023, 6, 19)) == "Juneteenth"
    assert holiday_name(date(2021, 6, 18)) is None  # before Juneteenth existed
    assert holiday_name(date(2021, 12, 31)) is None  # NYSE doesn't observe Sat New Year
    assert holiday_name(date(2022, 12, 26)) == "Christmas"
    assert holiday_name(date(2025, 1, 9))
    assert len(nyse_holidays(2024)) == 10


def test_trading_days_per_month():
    def n(y, m):
        d, c = date(y, m, 1), 0
        while d.month == m:
            c += d.weekday() < 5 and not holiday_name(d)
            d += timedelta(days=1)
        return c
    assert n(2024, 3) == 20
    assert n(2024, 7) == 22
    assert n(2024, 12) == 21


# ---------------------------------------------------------------- pipeline
def _write_csv(path, header, rows):
    with open(path, "w") as f:
        if header:
            f.write(header + "\n")
        f.write("\n".join(rows) + "\n")


def _minute_rows(day, tz, start_h, end_h, fmt, sep=",", label_close=False):
    rows = []
    base = datetime.combine(day, dtime(start_h))
    for k in range((end_h - start_h) * 60):
        t = base + timedelta(minutes=k + (1 if label_close else 0))
        p = 100 + k * 0.25
        rows.append(sep.join([t.strftime(fmt), f"{p}", f"{p + 1}", f"{p - 1}", f"{p + 0.25}", "10"]))
    return rows


def test_pipeline_ninja_style(tmp_path):
    # headerless, semicolon, close-labelled bars, Chicago time; includes a duplicate row
    rows = []
    for d in (date(2024, 3, 8), date(2024, 3, 9), date(2024, 3, 11), date(2024, 3, 29)):
        rows += _minute_rows(d, "America/Chicago", 5, 11, "%Y%m%d %H%M%S", sep=";", label_close=True)
    rows.append(rows[10])
    rows.append("this;is;not;a;row;!")
    csv_path = tmp_path / "nq.txt"
    _write_csv(csv_path, None, rows)
    src = Source.from_path(str(csv_path))
    fmt, header, _, _ = sniff(read_head(src))
    assert fmt.delimiter == ";" and not fmt.has_header and fmt.ts_format == "%Y%m%d %H%M%S"
    fmt.source_tz = "America/Chicago"
    fmt.bar_label = "close"
    meta = CacheBuilder(str(tmp_path / "cache")).build("NQ", [src], fmt)
    assert meta["duplicates"] == 1 and meta["bad_rows"] == 1
    store = BarStore(str(tmp_path / "cache" / "NQ"))

    for d in (date(2024, 3, 8), date(2024, 3, 11)):
        bars = store.window(ny_epoch(d, dtime(7)), ny_epoch(d, dtime(11)))
        assert len(bars["ts"]) == 240
        first = datetime.fromtimestamp(int(bars["ts"][0]), NY)
        assert first.time() == dtime(7, 0)

    req = GenerateRequest.from_strings("NQ", "2024-03-08", "2024-03-31")
    s = run_generation(req, store, str(tmp_path / "out"))
    assert [m["date"] for m in s.made] == ["2024-03-08", "2024-03-11"]
    assert [d for d, _ in s.skipped["holiday"]] == ["2024-03-29"]
    assert len(s.skipped["no data"]) == 13
    assert os.path.exists(os.path.join(s.run_dir, "NQ_2024-03-08.png"))
    assert os.path.exists(os.path.join(s.run_dir, "thumbs", "NQ_2024-03-08.png"))


def test_split_date_time_columns(tmp_path):
    rows = [r.replace(" ", ",", 1) for r in
            _minute_rows(date(2024, 7, 1), "UTC", 10, 16, "%m/%d/%Y %H:%M")]
    p = tmp_path / "es.csv"
    _write_csv(p, "Date,Time,Open,High,Low,Close,Volume", rows)
    src = Source.from_path(str(p))
    fmt, *_ = sniff(read_head(src))
    assert fmt.ts_col == "Date" and fmt.time_col == "Time"
    fmt.source_tz = "UTC"
    CacheBuilder(str(tmp_path / "c")).build("ES", [src], fmt)
    store = BarStore(str(tmp_path / "c" / "ES"))
    bars = store.window(ny_epoch(date(2024, 7, 1), dtime(7)), ny_epoch(date(2024, 7, 1), dtime(11)))
    assert len(bars["ts"]) == 240  # 07:00-11:00 EDT = 11:00-15:00 UTC


def test_wrong_format_is_reported(tmp_path):
    p = tmp_path / "bad.csv"
    _write_csv(p, "Timestamp,Open,High,Low,Close", ["15-Mar-2024 07:00,1,2,0,1"] * 50)
    fmt = CsvFormat(ts_col="Timestamp", open_col="Open", high_col="High", low_col="Low",
                    close_col="Close", ts_format="%Y-%m-%d %H:%M:%S")
    with pytest.raises(CsvFormatError):
        CacheBuilder(str(tmp_path / "c")).build("NQ", [Source.from_path(str(p))], fmt)


def test_invalid_request():
    with pytest.raises(ValueError):
        GenerateRequest.from_strings("NQ", "2024-03-10", "2024-03-01")
    with pytest.raises(ValueError):
        GenerateRequest.from_strings("NQ", "2024-13-01", "2024-03-01")
    with pytest.raises(ValueError):
        GenerateRequest.from_strings("NQ", "2024-03-01", "2024-03-05", "11:00", "07:00")
    with pytest.raises(ValueError):
        GenerateRequest.from_strings("NQ", "2024-03-01", "2024-03-05", "7am", "11:00")


# ---------------------------------------------------------------- Databento-style multi-contract file
def test_databento_contracts_and_roll(tmp_path):
    """One file, NQ + ES, two overlapping contract months each, plus spreads.
    Day 1 the old month (Z4) has more volume, day 2 the new one (H5)."""
    hdr = "ts_event,rtype,publisher_id,instrument_id,open,high,low,close,volume,symbol"
    rows = []
    for day, z_vol, h_vol in ((date(2024, 12, 12), 900, 100), (date(2024, 12, 13), 100, 900)):
        for k in range(6 * 60):  # 11:00-17:00 UTC covers 07:00-11:00 EST... and more
            t = datetime.combine(day, dtime(11)) + timedelta(minutes=k)
            ts = t.strftime("%Y-%m-%dT%H:%M:%S.000000000Z")
            for root, base in (("NQ", 21000.0), ("ES", 6000.0)):
                for sym, off, v in ((f"{root}Z4", 0, z_vol), (f"{root}H5", 300, h_vol)):
                    p = base + off + k * 0.25
                    rows.append(f"{ts},33,1,1,{p:.9f},{p + 1:.9f},{p - 1:.9f},{p:.9f},{v},{sym}")
                rows.append(f"{ts},33,1,2,-300.000000000,-299.0,-301.0,-300.0,50,{root}Z4-{root}H5")
    rows.append(rows[0])  # exact duplicate of an NQZ4 row
    p = tmp_path / "glbx.csv"
    _write_csv(p, hdr, rows)
    src = Source.from_path(str(p))
    fmt, *_ = sniff(read_head(src))
    assert (fmt.ts_col, fmt.ts_format, fmt.source_tz, fmt.symbol_col, fmt.volume_col) == \
        ("ts_event", "iso8601", "UTC", "symbol", "volume")
    metas = CacheBuilder(str(tmp_path / "c")).build_many(["NQ", "ES"], [src], fmt)
    assert set(metas) == {"NQ", "ES"}
    assert sorted(metas["NQ"]["contracts"]) == ["NQH5", "NQZ4"]
    assert metas["NQ"]["ignored_rows"] == 2 * 2 * 360  # spreads, both roots, both days
    assert metas["NQ"]["duplicates"] + metas["ES"]["duplicates"] == 1

    nq = BarStore(str(tmp_path / "c" / "NQ"))
    w = lambda d: nq.window(ny_epoch(d, dtime(7)), ny_epoch(d, dtime(11)))  # noqa: E731
    d1, d2 = w(date(2024, 12, 12)), w(date(2024, 12, 13))
    assert d1["symbol"] == "NQZ4" and len(d1["ts"]) == 240 and d1["close"].max() < 21300
    assert d2["symbol"] == "NQH5" and len(d2["ts"]) == 240 and d2["close"].min() >= 21300
    assert datetime.fromtimestamp(int(d1["ts"][0]), NY).time() == dtime(7, 0)

    s = run_generation(GenerateRequest.from_strings("ES", "2024-12-12", "2024-12-13"),
                       BarStore(str(tmp_path / "c" / "ES")), str(tmp_path / "out"))
    assert [(m["date"], m["contract"]) for m in s.made] == [("2024-12-12", "ESZ4"), ("2024-12-13", "ESH5")]


def test_parse_contract():
    from stratradegy.data_loader import parse_contract
    assert parse_contract("NQH4").root == "NQ"
    assert parse_contract("ESZ24").root == "ES"
    assert parse_contract("MNQM5").root == "MNQ"  # micro: different root, not mixed into NQ
    assert parse_contract("NQ.c.0").root == "NQ"
    assert parse_contract("ESZ4-ESH5") is None
    assert parse_contract("UD:1V: BF 0314") is None


def test_zero_filled_hole_is_skipped_and_reported(tmp_path):
    """A damaged file with a NUL block mid-row: torn rows are rejected, gap reported."""
    hdr = b"ts_event,rtype,publisher_id,instrument_id,open,high,low,close,volume,symbol\n"
    def row(d, k, p):
        t = (datetime.combine(d, dtime(12)) + timedelta(minutes=k)).strftime("%Y-%m-%dT%H:%M:%S.000000000Z")
        return f"{t},33,1,1,{p}.000000000,{p + 1}.000000000,{p - 1}.000000000,{p}.000000000,10,NQH7\n".encode()
    a = b"".join(row(date(2017, 1, 4), k, 5000) for k in range(240))
    b = b"".join(row(date(2017, 8, 23), k, 6000) for k in range(240))
    cut = a + row(date(2017, 1, 4), 240, 5000)[:50]           # torn row before the hole
    tail = row(date(2017, 8, 23), -1, 6000)[60:] + b          # torn row after the hole
    (tmp_path / "x.csv").write_bytes(hdr + cut + b"\x00" * (20 * 1024 * 1024) + tail)
    src = Source.from_path(str(tmp_path / "x.csv"))
    fmt, *_ = sniff(read_head(src))
    meta = CacheBuilder(str(tmp_path / "c")).build("NQ", [src], fmt)
    assert meta["rows"] == 480 and meta["bad_rows"] == 2
    assert meta["corrupt_bytes"] == 20 * 1024 * 1024
    assert meta["gaps"] == [["2017-01-04", "2017-08-23"]]
    store = BarStore(str(tmp_path / "c" / "NQ"))
    assert store.cols["high"].max() <= 6001  # no stitched garbage bar


def test_library_mixed_formats(tmp_path):
    """Two files, two formats: Databento (NQ+ES, contracts) for Dec 12 and a
    headerless NinjaTrader-style NQ export (Chicago time, close-stamped) for Dec 13."""
    from stratradegy.data_loader import BuildInput, peek_range
    hdr = "ts_event,rtype,publisher_id,instrument_id,open,high,low,close,volume,symbol"
    rows = []
    for k in range(6 * 60):
        t = (datetime.combine(date(2024, 12, 12), dtime(11)) + timedelta(minutes=k)).strftime(
            "%Y-%m-%dT%H:%M:%S.000000000Z")
        rows.append(f"{t},33,1,1,21000,21001,20999,21000,10,NQZ4")
        rows.append(f"{t},33,1,2,6000,6001,5999,6000,10,ESZ4")
    a = tmp_path / "glbx.csv"
    _write_csv(a, hdr, rows)
    b = tmp_path / "nq_ninja.txt"
    _write_csv(b, None, _minute_rows(date(2024, 12, 13), "America/Chicago", 5, 11, "%Y%m%d %H%M%S",
                                     sep=";", label_close=True))
    sa, sb = Source.from_path(str(a)), Source.from_path(str(b))
    fa, *_ = sniff(read_head(sa))
    fb, *_ = sniff(read_head(sb))
    fb.source_tz, fb.bar_label = "America/Chicago", "close"
    assert peek_range(sa, fa) == {"first": "2024-12-12", "last": "2024-12-12", "roots": ["NQ", "ES"]}
    builder = CacheBuilder(str(tmp_path / "c"))
    inputs = [BuildInput(sa, fa, None), BuildInput(sb, fb, "NQ")]
    metas = builder.build_inputs(["NQ", "ES"], inputs)
    assert metas["NQ"]["first"] == "2024-12-12" and metas["NQ"]["last"] == "2024-12-13"
    assert metas["ES"]["last"] == "2024-12-12"
    assert builder.is_current("NQ", inputs) and not builder.is_current("NQ", inputs[:1])
    nq = BarStore(str(tmp_path / "c" / "NQ"))
    d1 = nq.window(ny_epoch(date(2024, 12, 12), dtime(7)), ny_epoch(date(2024, 12, 12), dtime(11)))
    d2 = nq.window(ny_epoch(date(2024, 12, 13), dtime(7)), ny_epoch(date(2024, 12, 13), dtime(11)))
    assert (len(d1["ts"]), d1["symbol"]) == (240, "NQZ4")
    assert (len(d2["ts"]), d2["symbol"]) == (240, "")
    assert datetime.fromtimestamp(int(d2["ts"][0]), NY).time() == dtime(7, 0)


def test_analysis_and_ai_guards(tmp_path):
    from stratradegy.analysis import analyze_day
    from stratradegy.ai_model import LocalModel, select_facts, unverified_numbers
    rows = []
    for d in [date(2024, 3, 4) + timedelta(days=i) for i in range(10) if (date(2024, 3, 4) + timedelta(days=i)).weekday() < 5]:
        rows += _minute_rows(d, "America/New_York", 6, 12, "%Y-%m-%d %H:%M:%S")
    p = tmp_path / "nq.csv"
    _write_csv(p, "Timestamp,Open,High,Low,Close,Volume", rows)
    src = Source.from_path(str(p))
    fmt, *_ = sniff(read_head(src))
    CacheBuilder(str(tmp_path / "c")).build("NQ", [src], fmt)
    store = BarStore(str(tmp_path / "c" / "NQ"))
    f = analyze_day(store, "NQ", date(2024, 3, 13), dtime(7), dtime(11))
    assert f.values["high_time"] == "10:59" and f.values["or_break"] == "UP"
    assert "trend day" in f.headline()  # synthetic data rises every minute
    ctx = select_facts(f, "What happened at the 9:30 open?")
    assert "Opening range" in ctx and "Fastest" not in ctx
    real = f"{f.values['close']:,.2f}"
    assert unverified_numbers(f"It closed at {real} and peaked at 999.50.", f.text()) == ["999.50"]
    prompt = LocalModel.build_prompt("FACTS", "Q?")
    assert prompt.startswith("<|im_start|>system") and prompt.endswith("<|im_start|>assistant\n")
