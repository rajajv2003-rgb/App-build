"""Backtest rules (docs/BACKTEST_SPEC.md) on hand-built days."""
from datetime import date, datetime, time as dtime, timedelta
from zoneinfo import ZoneInfo

import numpy as np
import pytest

from stratradegy import backtest as bt
from stratradegy.data_loader import BarStore, CacheBuilder, Source, parse_contract, read_head, sniff

NY = ZoneInfo("America/New_York")


def make_day(rth, pre_hi=110.0, pre_lo=100.0):
    """150 flat pre-market candles 07:00-09:29 (PMH=110, PML=100), then `rth`
    candles (o, h, l, c) from 09:30 onward."""
    rows = [(105.0, 106.0, 104.0, 105.0)] * 150
    rows[10] = (105.0, pre_hi, 104.0, 105.0)
    rows[20] = (105.0, 106.0, pre_lo, 105.0)
    rows += list(rth)
    a = np.array(rows, dtype=float)
    minutes = np.arange(420, 420 + len(rows))
    return minutes, a[:, 0], a[:, 1], a[:, 2], a[:, 3]


def run(rth, model=1, rr=2.0):
    return bt.simulate_day(*make_day(rth), model=model, rr=rr)


FLAT = (105.0, 106.0, 104.0, 105.0)

# Long setup: 09:30 sweeps PML (low 99), 09:31-09:33 make a bullish FVG:
# candle1 09:31 high 103, candle2 09:32 low 101 / high 108, candle3 09:33 low 104 > 103.
LONG_SETUP = [
    (102.0, 104.0, 99.0, 103.0),    # 09:30 sweep below PML=100 -> LONG
    (103.0, 103.0, 101.5, 102.5),   # 09:31 candle 1 (high 103)
    (102.5, 108.0, 101.0, 107.5),   # 09:32 candle 2 (low 101 -> SL)
    (106.0, 109.0, 104.0, 108.5),   # 09:33 candle 3 (open 106, low 104 > 103)
]


# ---------------------------------------------------------------- FVG + models
def test_fvg_detection_and_model1_levels():
    r = run(LONG_SETUP + [FLAT] * 5)
    assert r.direction == "Long" and r.sweep_i == 150 and r.fvg == (151, 152, 153)
    assert (r.entry, r.sl) == (106.0, 101.0)          # Model 1: open of candle 3, SL low of candle 2
    assert r.tp == pytest.approx(106 + 2 * 5)


def test_model2_levels():
    r = run(LONG_SETUP + [FLAT] * 5, model=2, rr=1.5)
    assert (r.entry, r.sl) == (104.0, 101.0)          # Model 2: low of candle 3
    assert r.tp == pytest.approx(104 + 1.5 * 3)


def test_short_fvg_with_sweep_as_candle_1():
    rth = [
        (108.0, 111.0, 107.0, 107.5),   # 09:30 sweep above PMH=110 -> SHORT, candle 1 (low 107)
        (107.5, 107.8, 102.0, 102.5),   # 09:31 candle 2 (high 107.8 -> SL)
        (103.0, 106.0, 101.0, 101.5),   # 09:32 candle 3 high 106 < 107 -> bearish FVG
    ] + [FLAT] * 3
    r = run(rth, model=2)
    assert r.direction == "Short" and r.fvg == (150, 151, 152)
    assert (r.entry, r.sl) == (106.0, 107.8)


def test_fvg_finished_before_sweep_is_ignored():
    # bullish FVG at 09:27-09:29 (pre-market), sweep only at 09:31 -> must find a later FVG
    m, o, h, l, c = make_day([FLAT, (102.0, 104.0, 99.0, 103.0)] + LONG_SETUP[1:] + [FLAT] * 4)
    h[147], l[149] = 100.5, 101.0  # 09:27 high 100.5 < 09:29 low 101 -> an FVG before the sweep
    r = bt.simulate_day(m, o, h, l, c, 1, 2.0)
    assert r.sweep_i == 151 and r.fvg == (152, 153, 154)


def test_no_sweep_and_no_fvg():
    assert run([FLAT] * 60).status == bt.NO_SWEEP
    assert run([(102.0, 104.0, 99.0, 103.0)] + [FLAT] * 30).status == bt.NO_FVG


def test_ambiguous_day():
    assert run([(105.0, 111.0, 99.0, 105.0)] + [FLAT] * 5).status == bt.AMBIGUOUS


# ---------------------------------------------------------------- order handling
def test_cancel_when_tp_reached_before_fill():
    # entry 106 (model 1), TP 116: next candle rallies to 117 without dipping to 106
    r = run(LONG_SETUP + [(108.5, 117.0, 107.0, 116.0)] + [FLAT] * 3)
    assert r.status == "cancelled" and r.outcome == bt.CANCEL_TP


def test_cancel_when_not_filled_by_1100():
    up = (110.0, 112.0, 108.0, 111.0)  # never back down to 106, never up to 116
    rth = LONG_SETUP + [up] * (90 - len(LONG_SETUP)) + [(106.0, 107.0, 100.0, 101.0)]  # 11:00 candle ignored
    r = run(rth)
    assert r.status == "cancelled" and r.outcome == bt.CANCEL_TIME


def test_win_loss_and_fill_candle_counts():
    win = run(LONG_SETUP + [(108.0, 108.5, 105.5, 107.0), (107.0, 116.5, 106.5, 116.0)])
    assert (win.outcome, win.fill_i, win.exit_i) == (bt.WIN, 154, 155)
    loss_same_candle = run(LONG_SETUP + [(107.0, 107.5, 100.5, 101.0)])  # fills and stops in one candle
    assert (loss_same_candle.outcome, loss_same_candle.fill_i, loss_same_candle.exit_i) == (bt.LOSE, 154, 154)


def test_both_hit_in_same_candle():
    r = run(LONG_SETUP + [(108.0, 108.5, 105.5, 107.0), (107.0, 117.0, 100.0, 110.0)])
    assert r.status == "filled" and r.outcome == bt.BOTH


def test_open_at_1100():
    rth = LONG_SETUP + [(108.0, 108.5, 105.5, 107.0)] + [(107.0, 108.0, 106.0, 107.0)] * 80
    r = run(rth)
    assert r.status == "filled" and r.outcome == bt.OPEN


def test_zero_risk_is_not_an_order():
    rth = list(LONG_SETUP)
    rth[3] = (101.0, 109.0, 104.0, 108.5)   # model 1 entry = open 101 == SL 101
    assert run(rth + [FLAT] * 3).status == bt.INVALID


# ---------------------------------------------------------------- streaks + summary
def test_streaks_skip_excluded_trades():
    W, L, B, O = bt.WIN, bt.LOSE, bt.BOTH, bt.OPEN
    s = bt.streaks([W, B, W, L, O, L, L, W])
    assert s == {"longest_win": 2, "shortest_win": 1, "longest_loss": 3, "shortest_loss": 3}
    assert bt.streaks([B, O]) == {"longest_win": 0, "shortest_win": 0, "longest_loss": 0, "shortest_loss": 0}


def test_summary_counts():
    mk = lambda o, st="filled": bt.Trade("2026-01-0" + str(len(o) % 9), "Mon", "NQH6", "Long", o, st,  # noqa: E731
                                          1, 0, 3, 1, 2, 0, 0, "", "", "", "", 1, 2)
    trades = [mk(bt.WIN), mk(bt.LOSE), mk(bt.BOTH), mk(bt.OPEN), mk(bt.CANCEL_TP, "cancelled"),
              mk(bt.CANCEL_TIME, "cancelled")]
    s = bt.summarize(trades, [bt.DayLog("x", "Mon", "", bt.AMBIGUOUS)])
    assert (s["orders"], s["filled"], s["cancelled"], s["wins"], s["losses"]) == (6, 4, 2, 1, 1)
    assert s["win_rate"] == 0.5 and s["ambiguous"] == 1


# ---------------------------------------------------------------- data: DST, contract choice, spreads
def _write_glbx(path, rows):
    with open(path, "w") as f:
        f.write("ts_event,rtype,publisher_id,instrument_id,open,high,low,close,volume,symbol\n")
        f.writelines(rows)


def _row(ny_dt, o, h, l, c, v, sym):
    t = ny_dt.replace(tzinfo=NY).astimezone(ZoneInfo("UTC")).strftime("%Y-%m-%dT%H:%M:%S.000000000Z")
    return f"{t},33,1,1,{o},{h},{l},{c},{v},{sym}\n"


def _session(d, sym, vol, price=105.0, minutes=range(6 * 60 + 50, 11 * 60 + 10)):
    rows = []
    for m in minutes:
        t = datetime(d.year, d.month, d.day) + timedelta(minutes=m)
        hi = price + (5 if m == 7 * 60 + 10 else 1)       # 07:10 sets PMH
        hi = price + 50 if m == 6 * 60 + 59 else hi        # 06:59 is outside the range
        rows.append(_row(t, price, hi, price - 1, price, vol, sym))
    return rows


@pytest.mark.parametrize("d", [date(2025, 3, 7), date(2025, 3, 10), date(2025, 10, 31), date(2025, 11, 3)])
def test_dst_day_window_and_pmh(tmp_path, d):
    p = tmp_path / "g.csv"
    _write_glbx(p, _session(d, "NQH5", 10) + ["2025-01-01T00:00:00.000000000Z,33,1,1,1,1,1,1,1,NQH5-NQM5\n"])
    src = Source.from_path(str(p))
    fmt, *_ = sniff(read_head(src))
    CacheBuilder(str(tmp_path / "c")).build_inputs(["NQ", "ES"], [__import__("stratradegy.data_loader", fromlist=["x"]).BuildInput(src, fmt, None)])
    b = bt.day_bars(BarStore(str(tmp_path / "c" / "NQ")), d)
    assert b["minutes"][0] == 420 and b["minutes"][-1] == 659 and len(b["minutes"]) == 240
    r = bt.simulate_day(b["minutes"], b["open"], b["high"], b["low"], b["close"], 1, 2)
    assert r.pmh == 110.0  # 07:10 high counts, the 06:59 spike (155) does not


def test_contract_chosen_by_0700_1100_volume_and_spreads_ignored(tmp_path):
    d = date(2026, 3, 12)
    rows = (_session(d, "NQH6", 50, price=105)                                      # busy inside 07-11
            + _session(d, "NQM6", 10, price=300)                                    # quiet inside 07-11
            + _session(d, "NQM6", 10_000, price=300, minutes=range(12 * 60, 13 * 60))  # busy after 11:00
            + [_row(datetime(2026, 3, 12, 8), 1, 1, 1, 1, 99_999, "NQH6-NQM6")])     # spread: ignored
    p = tmp_path / "g.csv"
    _write_glbx(p, rows)
    src = Source.from_path(str(p))
    fmt, *_ = sniff(read_head(src))
    from stratradegy.data_loader import BuildInput
    CacheBuilder(str(tmp_path / "c")).build_inputs(["NQ", "ES"], [BuildInput(src, fmt, None)])
    store = BarStore(str(tmp_path / "c" / "NQ"))
    b = bt.day_bars(store, d)
    assert b["symbol"] == "NQH6" and b["high"].max() < 200
    res = bt.run_backtest(store, "NQ", d, d, 1, 2.0)
    assert res.days[0].contract == "NQH6"
    assert parse_contract("NQZ6-NQH7") is None and parse_contract("NQZ6").root == "NQ"
    assert parse_contract("ESU6").root == "ES"


def test_run_backtest_validates_inputs(tmp_path):
    with pytest.raises(ValueError):
        bt.run_backtest(None, "NQ", date(2026, 1, 2), date(2026, 1, 1), 1, 2)
    with pytest.raises(ValueError):
        bt.run_backtest(None, "NQ", date(2026, 1, 1), date(2026, 1, 2), 3, 2)
    with pytest.raises(ValueError):
        bt.run_backtest(None, "NQ", date(2026, 1, 1), date(2026, 1, 2), 1, 0)
