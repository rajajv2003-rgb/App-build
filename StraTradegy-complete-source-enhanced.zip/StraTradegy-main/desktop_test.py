"""Desktop test mode: run the loader + chart renderer on your PC, no Kivy needed.

Examples
--------
  # inspect a CSV and see what the app would detect
  python desktop_test.py sniff --csv data/NQ_1min.csv

  # build the cache once (streams the file; safe for multi-GB CSVs)
  python desktop_test.py index --csv data/NQ_1min.csv --instrument NQ --tz America/Chicago

  # render charts for a range
  python desktop_test.py render --instrument NQ --start 2024-03-01 --end 2024-03-31

  # everything in one go with explicit format settings
  python desktop_test.py render --csv data/NQ.csv --instrument NQ --start 2024-03-01 --end 2024-03-31 \\
      --ts-format "%Y-%m-%d %H:%M:%S" --tz America/Chicago --window 07:00 11:00 --theme light
"""

import argparse
import os
import sys
import time

from stratradegy.config import INSTRUMENTS, CsvFormat, RESOLUTIONS
from stratradegy.data_loader import (BarStore, CacheBuilder, CsvFormatError, Source,
                                     describe_error, read_head, sniff, test_parse)
from stratradegy.generator import GenerateRequest, run_generation
from stratradegy.platform_io.desktop_io import DesktopSink

DEFAULT_CACHE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".cache")
DEFAULT_WORK = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")


def _progress(frac, text, *_):
    bar = "#" * int(frac * 30)
    sys.stdout.write(f"\r[{bar:<30}] {frac * 100:5.1f}%  {text[:90]:<90}")
    sys.stdout.flush()


def build_format(args, src: Source) -> CsvFormat:
    fmt, header, rows, notes = sniff(read_head(src))
    overrides = {
        "delimiter": args.delimiter, "ts_col": args.ts_col, "time_col": args.time_col,
        "ts_format": args.ts_format, "source_tz": args.tz, "open_col": args.open_col,
        "high_col": args.high_col, "low_col": args.low_col, "close_col": args.close_col,
        "volume_col": args.volume_col, "bar_label": args.bar_label, "symbol_col": args.symbol_col,
    }
    for k, v in overrides.items():
        if v is not None:
            setattr(fmt, k, v)
    if args.no_header:
        fmt.has_header = False
    return fmt


def cmd_sniff(args):
    src = Source.from_path(args.csv)
    fmt, header, rows, notes = sniff(read_head(src))
    if args.tz:
        fmt.source_tz = args.tz
    print("Columns:", header)
    for r in rows[:5]:
        print("  ", r)
    print("\nDetected:")
    for k, v in fmt.to_dict().items():
        print(f"  {k:12} = {v!r}")
    print("\nNotes:\n  " + "\n  ".join(notes))
    print("\nFirst rows converted to New York time:")
    out, bad, n = test_parse(src, fmt)
    for row in out:
        print("  ", row[0], *[f"{v:.2f}" for v in row[1:5]], row[5])
    if bad:
        print(f"  ({bad} of {n} preview rows failed to parse)")


def cmd_index(args):
    src = Source.from_path(args.csv)
    fmt = build_format(args, src)
    print("Format:", fmt.to_dict())
    builder = CacheBuilder(args.cache)
    t = time.time()
    insts = [args.instrument] if args.instrument else list(INSTRUMENTS)
    if not fmt.symbol_col and not args.instrument:
        raise ValueError("This file has no symbol column - pass --instrument NQ or ES.")
    metas = builder.build_many(insts, [src], fmt, progress=_progress)
    print(f"\nDone in {time.time() - t:.1f}s")
    for inst, meta in metas.items():
        print(f"  {inst}: {meta['rows']:,} bars, {meta['first']} -> {meta['last']}, {meta['bad_rows']} bad rows, "
              f"{meta['ignored_rows']:,} spread/other rows ignored, {meta['duplicates']} duplicates, "
              f"{len(meta['contracts'])} contract months")
        for a, b in meta["gaps"]:
            print(f"     ! no data between {a} and {b}")
        if meta["corrupt_bytes"]:
            print(f"     ! {meta['corrupt_bytes'] / 1e6:.0f} MB of the file is zero-filled (damaged) - re-export it to fill the gaps")


def cmd_render(args):
    if args.csv:
        src = Source.from_path(args.csv)
        fmt = build_format(args, src)
        builder = CacheBuilder(args.cache)
        if not builder.is_current(args.instrument, [src], fmt):
            print("Building cache...")
            insts = list(INSTRUMENTS) if fmt.symbol_col else [args.instrument]
            builder.build_many(insts, [src], fmt, progress=_progress)
            print()
    store = BarStore(os.path.join(args.cache, args.instrument))
    req = GenerateRequest.from_strings(
        args.instrument, args.start, args.end, args.window[0], args.window[1],
        theme=args.theme, resolution=args.resolution, skip_holidays=not args.keep_holidays)
    sink = DesktopSink(args.pictures) if args.pictures else None
    summary = run_generation(req, store, args.work, sink=sink, progress=_progress)
    print("\n" + summary.text())
    print("Local copies:", summary.run_dir)
    if sink:
        print("Gallery copies:", os.path.join(args.pictures, req.public_rel_dir.split("/", 1)[1]))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def fmt_args(p):
        p.add_argument("--delimiter")
        p.add_argument("--no-header", action="store_true")
        p.add_argument("--ts-col")
        p.add_argument("--time-col")
        p.add_argument("--ts-format", help='strptime format, "iso8601" or "epoch_s"/"epoch_ms"')
        p.add_argument("--tz", help="timezone of the CSV timestamps, e.g. America/Chicago or UTC")
        p.add_argument("--open-col")
        p.add_argument("--high-col")
        p.add_argument("--low-col")
        p.add_argument("--close-col")
        p.add_argument("--volume-col")
        p.add_argument("--bar-label", choices=["open", "close"])
        p.add_argument("--symbol-col", help='contract column, e.g. "symbol" (Databento); "" to disable')

    p = sub.add_parser("sniff")
    p.add_argument("--csv", required=True)
    p.add_argument("--tz")
    p.set_defaults(fn=cmd_sniff)

    p = sub.add_parser("index")
    p.add_argument("--csv", required=True)
    p.add_argument("--instrument", choices=["NQ", "ES"],
                   help="required unless the file has a symbol column (then NQ and ES are both indexed)")
    p.add_argument("--cache", default=DEFAULT_CACHE)
    fmt_args(p)
    p.set_defaults(fn=cmd_index)

    p = sub.add_parser("render")
    p.add_argument("--csv")
    p.add_argument("--instrument", choices=["NQ", "ES"], required=True)
    p.add_argument("--start", required=True)
    p.add_argument("--end", required=True)
    p.add_argument("--window", nargs=2, default=["07:00", "11:00"], metavar=("START", "END"))
    p.add_argument("--theme", choices=["dark", "light"], default="dark")
    p.add_argument("--resolution", choices=list(RESOLUTIONS), default="1920x1080")
    p.add_argument("--keep-holidays", action="store_true", help="don't skip US market holidays")
    p.add_argument("--cache", default=DEFAULT_CACHE)
    p.add_argument("--work", default=DEFAULT_WORK, help="where PNGs + thumbnails are written")
    p.add_argument("--pictures", help="also copy into <dir>/FuturesCharts/<inst>/<range>/ (e.g. ~/Pictures)")
    fmt_args(p)
    p.set_defaults(fn=cmd_render)

    args = ap.parse_args(argv)
    try:
        args.fn(args)
    except (CsvFormatError, ValueError, FileNotFoundError) as exc:
        print(f"\nError: {describe_error(exc)}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
