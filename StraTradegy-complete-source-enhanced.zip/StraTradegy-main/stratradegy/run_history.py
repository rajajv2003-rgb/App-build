"""Immutable backtest run snapshots and management-model comparison."""
from __future__ import annotations
import json, os, uuid
from datetime import datetime, timezone
from dataclasses import asdict
from .advanced_analytics import equity_metrics


def _trade_dict(t, instrument=None):
    names = ("date", "instrument", "contract", "direction", "entry", "sl", "tp", "rr", "be_enabled",
             "be_trigger", "be_activated", "final_exit", "final_r", "outcome", "exit_reason", "fill_time",
             "exit_time", "status", "risk_pts", "reward_pts")
    d = {}
    for n in names:
        v = getattr(t, n, None)
        if n == "instrument" and not v: v = instrument
        if isinstance(v, float) and (v != v or v in (float("inf"), float("-inf"))): v = None
        d[n] = v
    return d


def _json_safe(value):
    if isinstance(value, float) and (value != value or value in (float("inf"), float("-inf"))): return None
    if isinstance(value, dict): return {k:_json_safe(v) for k,v in value.items()}
    if isinstance(value, (list, tuple)): return [_json_safe(v) for v in value]
    return value


def save_run(result, root: str) -> str:
    """Write a unique immutable JSON snapshot; never overwrite an earlier run."""
    folder = os.path.join(root, "run_history")
    os.makedirs(folder, exist_ok=True)
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + uuid.uuid4().hex[:8]
    metrics = equity_metrics(result.trades)
    snapshot = {
        "run_id": run_id, "created_utc": datetime.now(timezone.utc).isoformat(),
        "configuration": {"instrument": result.instrument, "model": result.model, "target_rr": result.rr,
            "be_enabled": result.be_trigger is not None, "be_trigger_rr": result.be_trigger,
            "cancel_tp_before_entry": result.cancel_tp_before_entry,
            "start_date": result.start, "end_date": result.end},
        "metrics": _json_safe({k:v for k,v in metrics.items() if k not in ("equity_curve", "drawdown_details")}),
        "trades": [_trade_dict(t, result.instrument) for t in result.trades],
    }
    path = os.path.join(folder, run_id + ".json")
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f: json.dump(snapshot, f, indent=2, allow_nan=False)
    os.replace(tmp, path)
    return path


def load_runs(root: str):
    folder = os.path.join(root, "run_history")
    if not os.path.isdir(folder): return []
    out=[]
    for name in sorted(os.listdir(folder)):
        if not name.endswith(".json"): continue
        try:
            with open(os.path.join(folder,name), encoding="utf-8") as f: out.append(json.load(f))
        except (OSError, ValueError): continue
    return out


def compare_runs(root: str, instrument: str | None = None):
    runs=load_runs(root)
    if instrument: runs=[r for r in runs if r.get("configuration",{}).get("instrument")==instrument]
    keys=("wins", "losses", "breakeven", "win_rate", "net_r", "profit_factor", "expectancy_r", "max_drawdown_r")
    return [{"run_id":r["run_id"], **r["configuration"],
             "total_trades":r.get("metrics",{}).get("trades", 0),
             **{k:r.get("metrics",{}).get(k) for k in keys}} for r in runs]
