"""CSV sniffing, one-time cache build, and fast date-range queries.

Why not Parquet? pyarrow/fastparquet have no python-for-android recipe, so
they cannot be packaged with Buildozer. Instead the CSV is streamed once (8 MB
chunks, never fully in memory) into a column cache of plain ``.npy`` files:

    <cache_dir>/<INSTRUMENT>/ts.npy      int64  UTC epoch seconds (bar open), sorted
                             open.npy high.npy low.npy close.npy  float64
                             volume.npy  float64 (only if a volume column is mapped)
                             contract.npy int16  index into meta["contracts"] (only with a symbol column)
                             meta.json

Queries memory-map these files and binary-search ``ts`` (``np.searchsorted``),
so pulling one day's 7:00-11:00 window out of 5+ million bars takes well under
a millisecond and uses almost no RAM.
"""

from __future__ import annotations

import csv
import io
import json
import os
import re
import shutil
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone

import numpy as np

from .config import INSTRUMENTS, CsvFormat
from .timeparse import TimestampError, detect_format, get_zone, parse_timestamps

CACHE_VERSION = 4
CHUNK_BYTES = 8 * 1024 * 1024
MAX_LINE_BYTES = 1024 * 1024  # a "line" longer than this is corrupt data, not a row
GAP_DAYS = 6  # data gaps longer than this (calendar days) are reported after indexing
_NUL_RUN = re.compile(rb"\x00+")
COLUMNS = ("open", "high", "low", "close")


class CsvFormatError(ValueError):
    """Raised for files that don't match the configured CSV format."""


class Cancelled(Exception):
    pass


# --------------------------------------------------------------------------- #
# sources: a desktop path or an Android content:// URI
# --------------------------------------------------------------------------- #
@dataclass
class Source:
    name: str
    size: int
    path: str = ""  # desktop / file path
    uri: str = ""  # Android SAF content URI
    mtime: float = 0.0

    def open_binary(self):
        if self.path:
            return open(self.path, "rb", buffering=1024 * 1024)
        from .platform_io import android_io

        return android_io.open_uri_binary(self.uri)

    def fingerprint(self) -> dict:
        return {"name": self.name, "size": int(self.size), "mtime": float(self.mtime)}

    @classmethod
    def from_path(cls, path: str) -> "Source":
        st = os.stat(path)
        return cls(name=os.path.basename(path), size=st.st_size, path=path, mtime=st.st_mtime)

    def to_dict(self):
        return {"name": self.name, "size": self.size, "path": self.path, "uri": self.uri, "mtime": self.mtime}

    @classmethod
    def from_dict(cls, d):
        return cls(**{k: d.get(k, v) for k, v in
                      (("name", ""), ("size", 0), ("path", ""), ("uri", ""), ("mtime", 0.0))})


# --------------------------------------------------------------------------- #
# sniffing
# --------------------------------------------------------------------------- #
def read_head(source: Source, max_lines: int = 40) -> list[str]:
    with source.open_binary() as f:
        raw = f.read(256 * 1024)
    text = raw.decode("utf-8-sig", errors="replace")
    lines = text.splitlines()
    if len(raw) == 256 * 1024 and lines:
        lines = lines[:-1]  # last line may be cut
    return [ln for ln in lines if ln.strip()][:max_lines]


def _looks_numeric(s: str) -> bool:
    try:
        float(s)
        return True
    except ValueError:
        return False


def _find(header_l, *names):
    for n in names:
        if n in header_l:
            return header_l.index(n)
    for n in names:  # substring match, e.g. "open price" (not for 1-letter names)
        if len(n) < 3:
            continue
        for i, h in enumerate(header_l):
            if n in h:
                return i
    return None


def sniff(lines: list[str]) -> tuple[CsvFormat, list[str], list[list[str]], list[str]]:
    """Guess the CSV format from the first lines.

    Returns (format, column_labels, preview_rows, notes).
    """
    notes = []
    if not lines:
        raise CsvFormatError("The file is empty.")
    sample = "\n".join(lines[:20])
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        delim = dialect.delimiter
    except csv.Error:
        delim = max(",;\t|", key=lambda d: lines[0].count(d))
        if lines[0].count(delim) == 0:
            delim = " "  # whitespace separated, e.g. "20240315 070000 18000.25 ..."
    rows = list(csv.reader(lines, delimiter=delim)) if delim != " " else [ln.split() for ln in lines]
    rows = [[c.strip() for c in r] for r in rows if r]
    first = rows[0]
    has_header = sum(_looks_numeric(c) for c in first) < max(2, len(first) // 2)
    if has_header:
        header = first
        data = rows[1:]
    else:
        header = [str(i) for i in range(len(first))]
        data = rows
        notes.append("No header row detected - columns are referred to by position (0, 1, 2...).")
    if not data:
        raise CsvFormatError("No data rows found after the header.")

    fmt = CsvFormat(delimiter=delim, has_header=has_header)
    hl = [h.lower().strip().strip('"') for h in header]

    if has_header:
        ts_i = _find(hl, "timestamp", "datetime", "date_time", "time_stamp", "ts_event", "date")
        time_i = _find(hl, "time") if ts_i is not None and hl[ts_i] == "date" else None
        o, h, l, c = (_find(hl, "open", "o"), _find(hl, "high", "h"), _find(hl, "low", "l"), _find(hl, "close", "last", "c"))
        v = _find(hl, "volume", "vol", "v")
    else:
        # headerless: date (and maybe time) first, then OHLC(V)
        ts_i, time_i = 0, None
        r0 = data[0]
        c0, c1 = r0[0], (r0[1] if len(r0) > 1 else "")
        if ":" in c1 or (c0.isdigit() and len(c0) == 8 and c1.isdigit()
                         and len(c1) in (4, 6) and len(r0) >= 6):
            time_i = 1
        start = 2 if time_i is not None else 1
        nums = [i for i in range(start, len(r0)) if _looks_numeric(r0[i])]
        o, h, l, c = (nums + [None] * 4)[:4]
        v = nums[4] if len(nums) > 4 else None

    if ts_i is None:
        raise CsvFormatError(f"Could not find a date/timestamp column in header: {header}")
    fmt.ts_col = header[ts_i]
    fmt.time_col = header[time_i] if time_i is not None else ""
    for attr, idx in (("open_col", o), ("high_col", h), ("low_col", l), ("close_col", c)):
        if idx is None:
            notes.append(f"Could not detect the {attr.split('_')[0]} column - please select it.")
            setattr(fmt, attr, "")
        else:
            setattr(fmt, attr, header[idx])
    fmt.volume_col = header[v] if v is not None else ""
    sym_i = _find(hl, "symbol", "raw_symbol", "contract", "ticker", "instrument") if has_header else None
    if sym_i is not None and sym_i not in (ts_i, time_i, o, h, l, c, v):
        fmt.symbol_col = header[sym_i]
        roots = sorted({m.root for m in (parse_contract(r[sym_i]) for r in data if len(r) > sym_i) if m})
        notes.append(
            f"Contract column '{header[sym_i]}' found (roots in the first rows: {', '.join(roots) or '?'}). "
            "NQ and ES are indexed together in one pass, calendar spreads are ignored, and each chart "
            "uses the most-traded contract month in its window."
        )

    samples = []
    for r in data[:30]:
        try:
            s = r[ts_i]
            if time_i is not None:
                s = f"{s} {r[time_i]}"
            samples.append(s)
        except IndexError:
            pass
    detected, note = detect_format(samples)
    if detected:
        fmt.ts_format = detected
    notes.append(note)
    if detected in ("epoch_s", "epoch_ms", "epoch_us", "epoch_ns") or (
            detected == "iso8601" and samples and re.search(r"(Z|[+-]\d\d:?\d\d)$", samples[0])):
        fmt.source_tz = "UTC"
    else:
        notes.append(
        "Set the source timezone to the timezone your timestamps are written in "
        "(CME/NinjaTrader exports are often America/Chicago; many vendors use UTC or America/New_York)."
        )
    return fmt, header, data[:10], notes


# --------------------------------------------------------------------------- #
# chunk parsing
# --------------------------------------------------------------------------- #
class _Resolver:
    def __init__(self, fmt: CsvFormat, header: list[str] | None):
        self.fmt = fmt

        def idx(ref, required=True):
            if not ref:
                if required:
                    raise CsvFormatError("A required column is not mapped.")
                return None
            if header is not None and ref in header:
                return header.index(ref)
            if ref.isdigit():
                return int(ref)
            if header is not None:
                low = [h.lower() for h in header]
                if ref.lower() in low:
                    return low.index(ref.lower())
            raise CsvFormatError(
                f"Column '{ref}' not found. Header is: {', '.join(header or [])}"
            )

        self.ts = idx(fmt.ts_col)
        self.time = idx(fmt.time_col, required=False)
        self.ohlc = [idx(getattr(fmt, f"{c}_col")) for c in COLUMNS]
        self.vol = idx(fmt.volume_col, required=False)
        self.sym = idx(getattr(fmt, "symbol_col", ""), required=False)
        used = [self.ts, *self.ohlc] + [i for i in (self.time, self.vol, self.sym) if i is not None]
        self.min_fields = max(used) + 1


def _split_lines(lines, delim, quoted):
    if quoted:
        return [[c.strip() for c in r] for r in csv.reader(lines, delimiter=delim)]
    if delim == " ":
        return [ln.split() for ln in lines]
    return [ln.split(delim) for ln in lines]


def _to_float(values: list[str]):
    try:
        arr = np.array(values, dtype=np.float64)
        return arr, np.isfinite(arr)
    except ValueError:
        out = np.full(len(values), np.nan)
        for i, v in enumerate(values):
            try:
                out[i] = float(v)
            except ValueError:
                pass
        return out, np.isfinite(out)


_CONTRACT_RE = re.compile(r"^([A-Z0-9]+?)([FGHJKMNQUVXZ])(\d{1,2})$")
_CONTINUOUS_RE = re.compile(r"^([A-Z0-9]+)\.[cvn]\.\d+$")  # Databento continuous, e.g. NQ.c.0


@dataclass(frozen=True)
class Contract:
    root: str  # "NQ"
    symbol: str  # "NQH4"


def parse_contract(sym: str) -> Contract | None:
    """'NQH4' -> Contract('NQ', 'NQH4'). Spreads ('ESZ4-ESH5') and junk -> None."""
    sym = sym.strip().strip('"')
    m = _CONTRACT_RE.match(sym) or _CONTINUOUS_RE.match(sym)
    return Contract(m.group(1), sym) if m else None


class _SymbolMapper:
    """Maps raw symbols to (instrument index, per-instrument contract code)."""

    def __init__(self, instruments: list[str]):
        self.inst_index = {r: i for i, r in enumerate(instruments)}
        self.contracts = [[] for _ in instruments]  # per instrument: list of symbols
        self.cache: dict[str, tuple[int, int]] = {}
        self.ignored: dict[str, int] = {}  # symbol -> rows (spreads, other roots)

    def _lookup(self, sym: str):
        c = parse_contract(sym)
        if c is None or c.root not in self.inst_index:
            return -1, -1
        i = self.inst_index[c.root]
        self.contracts[i].append(c.symbol)
        return i, len(self.contracts[i]) - 1

    def fixed_code(self, i: int) -> int:
        """Contract code for a file without a contract column (one continuous series)."""
        key = f"\x00{i}"
        if key not in self.cache:
            self.contracts[i].append("")
            self.cache[key] = (i, len(self.contracts[i]) - 1)
        return self.cache[key][1]

    def map(self, syms: list[str]):
        cache = self.cache
        for s in set(syms):
            if s not in cache:
                cache[s] = self._lookup(s)
        n = len(syms)
        inst = np.fromiter((cache[s][0] for s in syms), dtype=np.int16, count=n)
        code = np.fromiter((cache[s][1] for s in syms), dtype=np.int16, count=n)
        if (inst < 0).any():
            for s in syms:
                if cache[s][0] < 0:
                    self.ignored[s] = self.ignored.get(s, 0) + 1
        return inst, code


def parse_rows(rows: list[list[str]], res: _Resolver, mapper: _SymbolMapper | None = None):
    """Parse split CSV rows.

    Returns dict(ts, ohlc (n,4), volume|None, inst|None, code|None, bad, ignored).
    ``ignored`` counts valid rows dropped by the symbol filter (spreads, other roots).
    """
    n0 = len(rows)
    rows = [r for r in rows if len(r) >= res.min_fields]
    bad = n0 - len(rows)
    empty = {"ts": np.empty(0, np.int64), "ohlc": np.empty((0, 4)), "volume": None,
             "inst": None, "code": None, "bad": bad, "ignored": 0}
    if not rows:
        return empty
    fmt = res.fmt
    if res.time is not None:
        t_i, tm_i = res.ts, res.time
        ts_str = [f"{r[t_i].strip()} {r[tm_i].strip()}" for r in rows]
    else:
        t_i = res.ts
        ts_str = [r[t_i] for r in rows]
    ts, ok = parse_timestamps(ts_str, fmt.ts_format, fmt.source_tz)
    cols = []
    for ci in res.ohlc:
        arr, good = _to_float([r[ci] for r in rows])
        cols.append(arr)
        ok &= good
    vol = None
    if res.vol is not None:
        vol, vgood = _to_float([r[res.vol] for r in rows])
        vol = np.where(vgood, vol, 0.0)
    if fmt.bar_label == "close":
        ts = ts - 60
    ohlc = np.column_stack(cols)
    bad += int((~ok).sum())
    inst = code = None
    ignored = 0
    if mapper is not None and res.sym is not None:
        si = res.sym
        inst, code = mapper.map([r[si].strip() for r in rows])
        keep_sym = inst >= 0
        ignored = int((ok & ~keep_sym).sum())
        ok &= keep_sym
    if not ok.all():
        ts, ohlc = ts[ok], ohlc[ok]
        vol = vol[ok] if vol is not None else None
        if inst is not None:
            inst, code = inst[ok], code[ok]
    return {"ts": ts, "ohlc": ohlc, "volume": vol, "inst": inst, "code": code, "bad": bad, "ignored": ignored}


def test_parse(source: Source, fmt: CsvFormat, n: int = 8, instrument: str | None = None):
    """Parse the first rows for the preview.

    Returns (rows, bad, n_rows) with rows = (ny_time_str, o, h, l, c, symbol)."""
    lines = read_head(source, max_lines=max(n, 60) + 1)
    if fmt.has_header:
        header = _split_lines(lines[:1], fmt.delimiter, '"' in lines[0])[0]
        header = [h.strip().strip('"') for h in header]
        body = lines[1:]
    else:
        header, body = None, lines
    res = _Resolver(fmt, header)
    rows = _split_lines(body, fmt.delimiter, any('"' in ln for ln in body))
    get_zone(fmt.source_tz)
    mapper = None
    if res.sym is not None:
        mapper = _SymbolMapper([instrument] if instrument else list(INSTRUMENTS))
    p = parse_rows(rows, res, mapper)
    ny = get_zone("America/New_York")
    out = []
    for i, (t, row) in enumerate(zip(p["ts"].tolist(), p["ohlc"].tolist())):
        sym = mapper.contracts[int(p["inst"][i])][int(p["code"][i])] if mapper else ""
        local = datetime.fromtimestamp(t, tz=timezone.utc).astimezone(ny)
        out.append((local.strftime("%Y-%m-%d %H:%M %Z (%a)"), *row, sym))
        if len(out) >= n:
            break
    return out, p["bad"], len(rows)


# --------------------------------------------------------------------------- #
# cache build
# --------------------------------------------------------------------------- #
@dataclass
class BuildInput:
    """One CSV in the library: its own format and, for files without a contract
    column, the instrument its rows belong to (None = route by contract root)."""

    source: Source
    fmt: CsvFormat
    instrument: str | None = None

    def signature(self) -> dict:
        return {"source": self.source.fingerprint(), "format": self.fmt.to_dict(),
                "instrument": self.instrument}


def peek_range(source: Source, fmt: CsvFormat) -> dict:
    """Cheap per-file summary from the first and last ~256 KB: first/last New York
    date and the instrument roots seen. Used by the file list before indexing."""
    head = read_head(source, max_lines=200)
    with source.open_binary() as f:
        try:
            f.seek(max(0, source.size - 256 * 1024))
        except (OSError, ValueError):
            pass
        tail_raw = f.read(256 * 1024)
    tail = [ln for ln in tail_raw.replace(b"\x00", b"").decode("utf-8", "replace").splitlines()[1:] if ln.strip()]
    if fmt.has_header:
        header = [h.strip().strip('"') for h in _split_lines(head[:1], fmt.delimiter, '"' in head[0])[0]]
        head = head[1:]
    else:
        header = None
    res = _Resolver(fmt, header)
    mapper = _SymbolMapper(list(INSTRUMENTS) + ["MNQ", "MES"]) if res.sym is not None else None
    ny = get_zone("America/New_York")
    out = {"first": "", "last": "", "roots": []}
    p1 = parse_rows(_split_lines(head, fmt.delimiter, False), res, mapper)
    p2 = parse_rows(_split_lines(tail[-200:], fmt.delimiter, False), res, mapper)
    ts = np.concatenate([p1["ts"], p2["ts"]])
    if len(ts):
        day = lambda t: datetime.fromtimestamp(int(t), tz=timezone.utc).astimezone(ny).strftime("%Y-%m-%d")  # noqa: E731
        out["first"], out["last"] = day(ts.min()), day(ts.max())
    if mapper is not None:
        out["roots"] = [r for r, i in mapper.inst_index.items() if mapper.contracts[i]]
    return out


class CacheBuilder:
    def __init__(self, cache_root: str):
        self.cache_root = cache_root

    def inst_dir(self, instrument: str) -> str:
        return os.path.join(self.cache_root, instrument)

    @staticmethod
    def _as_inputs(sources, fmt, instrument):
        if fmt is None:
            return list(sources)
        return [BuildInput(s, fmt, None if fmt.symbol_col else instrument) for s in sources]

    def is_current(self, instrument: str, sources, fmt: CsvFormat | None = None) -> bool:
        meta = load_meta(self.inst_dir(instrument))
        if not meta or meta.get("version") != CACHE_VERSION:
            return False
        want = [i.signature() for i in self._as_inputs(sources, fmt, instrument)]
        return meta.get("inputs") == want

    def build(self, instrument: str, sources: list[Source], fmt: CsvFormat,
              progress=None, cancel: threading.Event | None = None) -> dict:
        """Build one instrument. Returns its meta."""
        metas = self.build_many([instrument], sources, fmt, progress, cancel)
        if instrument not in metas:
            raise CsvFormatError(f"No {instrument} rows were found in the selected file(s).")
        return metas[instrument]

    def build_many(self, instruments: list[str], sources: list[Source], fmt: CsvFormat,
                   progress=None, cancel: threading.Event | None = None) -> dict:
        """All sources share one format (CLI / single import)."""
        inputs = self._as_inputs(sources, fmt, instruments[0])
        return self.build_inputs(instruments if fmt.symbol_col else instruments[:1], inputs, progress, cancel)

    def build_inputs(self, instruments: list[str], inputs: list[BuildInput],
                     progress=None, cancel: threading.Event | None = None) -> dict:
        """Stream every input once into one cache per instrument.

        Files with a contract column are routed by root (spreads / other roots
        skipped); files without one go to their assigned instrument as a single
        continuous series. Every cache stores a contract code per bar so charts can
        pick the most-traded contract in their window.
        Returns {instrument: meta} for instruments that received rows.
        """
        if not inputs:
            raise CsvFormatError("No CSV files selected.")
        for inp in inputs:
            get_zone(inp.fmt.source_tz)  # fail fast on bad tz
            if not inp.fmt.symbol_col and inp.instrument not in instruments:
                instruments = instruments + [inp.instrument] if inp.instrument else instruments
                if not inp.instrument:
                    raise CsvFormatError(f"{inp.source.name}: choose NQ or ES for this file.")
        progress = progress or (lambda f, t: None)
        mapper = _SymbolMapper(instruments)
        has_vol = any(bool(i.fmt.volume_col) for i in inputs)
        names = ["ts", *COLUMNS] + (["volume"] if has_vol else []) + ["contract"]
        tmp, files = {}, {}
        for inst in instruments:
            d = self.inst_dir(inst) + ".building"
            shutil.rmtree(d, ignore_errors=True)
            os.makedirs(d)
            tmp[inst] = d
            files[inst] = {k: open(os.path.join(d, f"{k}.bin"), "wb") for k in names}
        rows = {inst: 0 for inst in instruments}
        total_bytes = max(1, sum(i.source.size for i in inputs))
        done_bytes = 0
        bad_total = ignored_total = nul_bytes = 0
        t0 = time.time()

        def close_all():
            for fh in files.values():
                for x in fh.values():
                    x.close()

        try:
            for n_in, inp in enumerate(inputs):
                src, fmt = inp.source, inp.fmt
                use_sym = bool(fmt.symbol_col) and inp.instrument is None
                if not use_sym:
                    fixed_i = instruments.index(inp.instrument)
                    fixed_code = mapper.fixed_code(fixed_i)
                header = None
                first_chunk = True
                leftover = b""
                checked = False
                with src.open_binary() as f:
                    while True:
                        if cancel is not None and cancel.is_set():
                            raise Cancelled()
                        block = f.read(CHUNK_BYTES)
                        done_bytes += len(block)
                        if b"\x00" in block:
                            # zero-filled holes (damaged download/export): make them line
                            # breaks so the torn rows on either side are rejected, never merged
                            nul_bytes += block.count(b"\x00")
                            block = _NUL_RUN.sub(b"\n", block)
                        if not block:
                            data, leftover = leftover, b""
                        else:
                            data = leftover + block
                            cut = data.rfind(b"\n")
                            if cut < 0:
                                if len(data) > MAX_LINE_BYTES:  # no newline for 1 MB: garbage
                                    bad_total += 1
                                    data = b""
                                leftover = data
                                continue
                            data, leftover = data[:cut + 1], data[cut + 1:]
                        if not data:
                            break
                        text = data.decode("utf-8-sig" if first_chunk else "utf-8", errors="replace")
                        lines = [ln for ln in text.splitlines() if ln.strip()]
                        if first_chunk:
                            first_chunk = False
                            if fmt.has_header and lines:
                                header = [h.strip().strip('"') for h in
                                          _split_lines(lines[:1], fmt.delimiter, '"' in lines[0])[0]]
                                lines = lines[1:]
                            res = _Resolver(fmt, header)
                            quoted = any('"' in ln for ln in lines[:50])
                        split = _split_lines(lines, fmt.delimiter, quoted)
                        p = parse_rows(split, res, mapper if use_sym else None)
                        ts, ohlc, vol = p["ts"], p["ohlc"], p["volume"]
                        if not checked and split:
                            checked = True
                            if p["bad"] > 0.5 * len(split) or (len(ts) == 0 and not p["ignored"]):
                                example = lines[0][:120] if lines else ""
                                raise CsvFormatError(
                                    f"{src.name}: {p['bad']} of the first {len(split)} rows could not be parsed "
                                    f"with its settings (timestamp format '{fmt.ts_format}', "
                                    f"delimiter '{fmt.delimiter}'). First row: {example!r}"
                                )
                        bad_total += p["bad"]
                        ignored_total += p["ignored"]
                        if len(ts):
                            for i, inst in enumerate(instruments):
                                if use_sym:
                                    m = p["inst"] == i
                                    if not m.any():
                                        continue
                                    sel = lambda a, m=m: a[m]  # noqa: E731
                                    codes = sel(p["code"])
                                elif i == fixed_i:
                                    sel = lambda a: a  # noqa: E731
                                    codes = np.full(len(ts), fixed_code, dtype=np.int16)
                                else:
                                    continue
                                fh = files[inst]
                                t_i = sel(ts)
                                fh["ts"].write(t_i.astype(np.int64).tobytes())
                                for j, k in enumerate(COLUMNS):
                                    fh[k].write(np.ascontiguousarray(sel(ohlc[:, j])).tobytes())
                                if has_vol:
                                    v = sel(vol) if vol is not None else np.zeros(len(t_i))
                                    fh["volume"].write(v.astype(np.float64).tobytes())
                                fh["contract"].write(codes.astype(np.int16).tobytes())
                                rows[inst] += len(t_i)
                        el = time.time() - t0
                        frac = done_bytes / total_bytes
                        eta = el / frac * (1 - frac) if frac > 0.02 else 0
                        counts = ", ".join(f"{k} {v:,}" for k, v in rows.items() if v)
                        label = f"file {n_in + 1}/{len(inputs)} " if len(inputs) > 1 else ""
                        progress(min(frac, 0.99) * 0.88,
                                 f"Reading {label}{src.name}: {counts or 0} bars"
                                 + (f", ~{int(eta)}s left" if eta else ""))
                        if not block:
                            break
        except BaseException:
            close_all()
            for d in tmp.values():
                shutil.rmtree(d, ignore_errors=True)
            raise
        close_all()

        if not any(rows.values()):
            for d in tmp.values():
                shutil.rmtree(d, ignore_errors=True)
            raise CsvFormatError(f"No valid rows were found for {', '.join(instruments)} in the selected file(s).")

        metas = {}
        for n_done, inst in enumerate(instruments):
            if rows[inst] == 0:
                shutil.rmtree(tmp[inst], ignore_errors=True)
                continue
            progress(0.88 + 0.1 * n_done / len(instruments), f"{inst}: sorting and removing duplicates...")
            mine = [i for i in inputs if (i.instrument == inst) or (i.instrument is None and i.fmt.symbol_col)]
            metas[inst] = self._finalize(inst, tmp[inst], names, has_vol, mapper.contracts[instruments.index(inst)],
                                         mine, bad_total, ignored_total, t0, nul_bytes)
        summary = "; ".join(f"{k}: {m['rows']:,} bars {m['first']} to {m['last']}" for k, m in metas.items())
        progress(1.0, f"Ready. {summary}.")
        return metas

    def _finalize(self, inst, tmp_dir, names, has_vol, contracts, inputs, bad_total, ignored_total, t0,
                  nul_bytes=0):
        path = lambda k: os.path.join(tmp_dir, f"{k}.bin")  # noqa: E731
        ts = np.fromfile(path("ts"), dtype=np.int64)
        con = np.fromfile(path("contract"), dtype=np.int16)
        order = np.lexsort((con, ts))  # by time, then contract
        ts, con = ts[order], con[order]
        keep = np.empty(len(ts), dtype=bool)
        keep[:-1] = ~((ts[1:] == ts[:-1]) & (con[1:] == con[:-1]))  # keep the last copy
        keep[-1] = True
        dups = int((~keep).sum())
        ts = ts[keep]
        np.save(os.path.join(tmp_dir, "ts.npy"), ts)
        np.save(os.path.join(tmp_dir, "contract.npy"), con[keep])
        del con
        for k in [n for n in names if n not in ("ts", "contract")]:
            arr = np.fromfile(path(k), dtype=np.float64)[order]
            np.save(os.path.join(tmp_dir, f"{k}.npy"), arr[keep])
            del arr
        for k in names:
            os.remove(path(k))

        ny = get_zone("America/New_York")
        to_day = lambda t: datetime.fromtimestamp(int(t), tz=timezone.utc).astimezone(ny).strftime("%Y-%m-%d")  # noqa: E731
        gi = np.nonzero(np.diff(ts) > GAP_DAYS * 86400)[0]
        meta = {
            "version": CACHE_VERSION,
            "instrument": inst,
            "gaps": [[to_day(ts[i]), to_day(ts[i + 1])] for i in gi[:50]],
            "corrupt_bytes": int(nul_bytes),
            "inputs": [i.signature() for i in inputs],
            "format": inputs[0].fmt.to_dict() if inputs else {},
            "sources": [i.source.fingerprint() for i in inputs],
            "rows": int(len(ts)),
            "bad_rows": int(bad_total),
            "ignored_rows": int(ignored_total),
            "duplicates": dups,
            "contracts": [c for c in contracts],
            "first": to_day(ts[0]),
            "last": to_day(ts[-1]),
            "has_volume": has_vol,
            "built": datetime.now().isoformat(timespec="seconds"),
            "build_seconds": round(time.time() - t0, 1),
        }
        with open(os.path.join(tmp_dir, "meta.json"), "w") as f:
            json.dump(meta, f, indent=2)
        final_dir = self.inst_dir(inst)
        shutil.rmtree(final_dir, ignore_errors=True)
        os.replace(tmp_dir, final_dir)
        return meta


def load_meta(inst_dir: str) -> dict | None:
    try:
        with open(os.path.join(inst_dir, "meta.json")) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


# --------------------------------------------------------------------------- #
# queries
# --------------------------------------------------------------------------- #
class BarStore:
    """Read-only, memory-mapped access to an instrument cache."""

    def __init__(self, inst_dir: str):
        self.meta = load_meta(inst_dir)
        if not self.meta:
            raise FileNotFoundError("No data imported for this instrument yet. Import a CSV first.")
        if self.meta.get("version") != CACHE_VERSION:
            raise FileNotFoundError("The data cache is from an older version - please re-import the CSV.")
        self.ts = np.load(os.path.join(inst_dir, "ts.npy"), mmap_mode="r")
        self.cols = {k: np.load(os.path.join(inst_dir, f"{k}.npy"), mmap_mode="r") for k in COLUMNS}
        vp = os.path.join(inst_dir, "volume.npy")
        self.volume = np.load(vp, mmap_mode="r") if os.path.exists(vp) else None
        cp = os.path.join(inst_dir, "contract.npy")
        self.contract = np.load(cp, mmap_mode="r") if os.path.exists(cp) else None
        self.contracts = self.meta.get("contracts", [])

    def window(self, utc_start: int, utc_end: int) -> dict:
        """Bars with open time in [utc_start, utc_end). Arrays are copies.

        With several contract months in the window (roll periods), only the one
        with the highest volume in the window is returned, so a chart never mixes
        contracts. ``out["symbol"]`` names it ("" when the data has no symbols)."""
        i0 = int(np.searchsorted(self.ts, utc_start, side="left"))
        i1 = int(np.searchsorted(self.ts, utc_end, side="left"))
        sel = slice(i0, i1)
        symbol = ""
        if self.contract is not None and i1 > i0:
            con = np.array(self.contract[i0:i1])
            weights = np.array(self.volume[i0:i1]) if self.volume is not None else None
            totals = np.bincount(con, weights=weights)
            best = int(np.argmax(totals))
            symbol = self.contracts[best] if best < len(self.contracts) else ""
            if (con != best).any():
                sel = i0 + np.nonzero(con == best)[0]
        out = {"ts": np.array(self.ts[sel]), "symbol": symbol}
        for k, arr in self.cols.items():
            out[k] = np.array(arr[sel])
        out["volume"] = np.array(self.volume[sel]) if self.volume is not None else None
        return out


def describe_error(exc: Exception) -> str:
    if isinstance(exc, (CsvFormatError, TimestampError, FileNotFoundError)):
        return str(exc)
    if isinstance(exc, UnicodeDecodeError):
        return "The file is not UTF-8/ASCII text. Is it really a CSV?"
    if isinstance(exc, MemoryError):
        return "Ran out of memory while indexing. Close other apps and try again."
    if isinstance(exc, (io.UnsupportedOperation, OSError)):
        return f"Could not read the file: {exc}"
    return f"{type(exc).__name__}: {exc}"
