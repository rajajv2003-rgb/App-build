"""Desktop backtest (same engine as the app), e.g.

    python main.py --cli --csv file.csv --instrument NQ --start 2026-05-11 --end 2026-11-06 --model 1 --rr 2

Indexes the CSV(s) once (reused while the files are unchanged), runs the backtest and
writes trades.csv, day_log.csv and charts.pdf to
<out>/NQES_Backtest/<instrument>_<start>_to_<end>/.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from datetime import date

from . import backtest as bt
from .data_loader import BarStore, BuildInput, CacheBuilder, CsvFormatError, Source, describe_error, read_head, sniff


def _bar(frac, text):
    sys.stdout.write(f"\r[{'#' * int(frac * 30):<30}] {frac * 100:5.1f}%  {text[:70]:<70}")
    sys.stdout.flush()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="main.py --cli", description="StraTradegy backtest (desktop)")
    ap.add_argument("--cli", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--csv", nargs="+", required=True, help="Databento 1-min OHLCV CSV file(s)")
    ap.add_argument("--instrument", choices=["NQ", "ES"], required=True)
    ap.add_argument("--start", required=True, help="YYYY-MM-DD")
    ap.add_argument("--end", required=True, help="YYYY-MM-DD")
    ap.add_argument("--model", type=int, choices=[1, 2], required=True)
    ap.add_argument("--rr", type=float, required=True, help="risk-to-reward, e.g. 2 or 1.5")
    ap.add_argument("--out", default="backtest_out", help="output folder (default ./backtest_out)")
    ap.add_argument("--include-cancelled", action="store_true", help="also add PDF pages for cancelled orders")
    ap.add_argument("--keep-holidays", action="store_true", help="do not skip US market holidays")
    ap.add_argument("--no-pdf", action="store_true")
    ap.add_argument("--cache", default=".cache_cli", help="index folder (reused between runs)")
    a = ap.parse_args(argv)

    try:
        start, end = date.fromisoformat(a.start), date.fromisoformat(a.end)
        inputs = []
        for path in a.csv:
            if not os.path.isfile(path):
                raise FileNotFoundError(f"CSV file not found: {path}")
            src = Source.from_path(path)
            fmt, *_ = sniff(read_head(src))
            inputs.append(BuildInput(src, fmt, None if fmt.symbol_col else a.instrument))
        builder = CacheBuilder(a.cache)
        if not builder.is_current(a.instrument, inputs):
            print("Indexing the CSV (one time)...")
            builder.build_inputs(["NQ", "ES"], inputs, progress=_bar)
            print()
        store = BarStore(os.path.join(a.cache, a.instrument))
        t0 = time.time()
        res = bt.run_backtest(store, a.instrument, start, end, a.model, a.rr,
                              skip_holidays=not a.keep_holidays, progress=_bar)
        print(f"\nBacktest done in {time.time() - t0:.1f}s\n")
        folder = os.path.join(a.out, "NQES_Backtest", res.folder_name)
        bt.write_trades_csv(res, os.path.join(folder, "trades.csv"), include_cancelled=False)
        bt.write_day_log_csv(res, os.path.join(folder, "day_log.csv"))
        for k, v in bt.summary_lines(res.summary):
            print(f"  {k:<32} {v}")
        if not res.trades:
            print("\nNo trades found for these settings.")
        elif not a.no_pdf:
            from .backtest_report import write_pdf

            print()
            path, pages = write_pdf(res, store, os.path.join(folder, "charts.pdf"),
                                    include_cancelled=a.include_cancelled, progress=_bar)
            print(f"\nPDF: {pages} pages")
        print(f"\nSaved to {os.path.abspath(folder)}")
        return 0
    except (CsvFormatError, ValueError, FileNotFoundError, OSError) as exc:
        print(f"\nError: {describe_error(exc)}", file=sys.stderr)
        return 2
