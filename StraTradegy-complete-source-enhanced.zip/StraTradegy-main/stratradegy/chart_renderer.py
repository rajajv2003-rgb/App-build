"""Candlestick chart renderer (matplotlib, Agg, no pyplot -> thread-safe).

Candles are drawn as one PolyCollection (bodies) + one LineCollection (wicks),
which is several times faster than mplfinance and needs no pandas - important
on a phone where every chart costs CPU time.
"""

from __future__ import annotations

import os
from datetime import date, datetime, time as dtime, timedelta

os.environ.setdefault("MPLBACKEND", "Agg")

import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.collections import LineCollection, PolyCollection
from matplotlib.figure import Figure
from matplotlib.ticker import FixedLocator, FuncFormatter, MaxNLocator, NullFormatter
from matplotlib.transforms import blended_transform_factory

from .config import INSTRUMENTS
from .timeparse import get_zone, ny_epoch, parse_hhmm  # noqa: F401 (re-export)

try:
    from PIL import Image
except ImportError:  # pragma: no cover - matplotlib depends on Pillow anyway
    Image = None

NY = "America/New_York"

THEMES = {
    "dark": {
        "bg": "#0e121b", "panel": "#0e121b", "grid": "#1f2737", "spine": "#2a3346",
        "text": "#e6e9f0", "muted": "#8b94a7",
        "up": "#22c55e", "down": "#ef4444",
        "marker": "#5b8cff", "marker_open": "#f5a524", "marker_text": "#0e121b",
    },
    "light": {
        "bg": "#ffffff", "panel": "#ffffff", "grid": "#e8ebf0", "spine": "#c9ced8",
        "text": "#141821", "muted": "#5f6878",
        "up": "#16a34a", "down": "#dc2626",
        "marker": "#2f6bff", "marker_open": "#d97706", "marker_text": "#ffffff",
    },
}


def _fmt_price(v, decimals=2):
    return f"{v:,.{decimals}f}"


def render_day(bars: dict, day: date, instrument: str, start: dtime, end: dtime,
               out_path: str, thumb_path: str | None = None, theme: str = "dark",
               size=(1920, 1080), markers=("07:00", "08:00", "09:00", "09:30")) -> dict:
    """Render one day's window to PNG. ``bars`` holds ts/open/high/low/close arrays."""
    th = THEMES.get(theme, THEMES["dark"])
    W, H = size
    s = W / 1920.0  # font/line scale
    dpi = 100

    w0, w1 = ny_epoch(day, start), ny_epoch(day, end)
    span_min = (w1 - w0) / 60.0
    ts = bars["ts"]
    o, h, l, c = bars["open"], bars["high"], bars["low"], bars["close"]
    n = len(ts)
    if n == 0:
        raise ValueError("no bars")
    x = (ts - w0) / 60.0

    fig = Figure(figsize=(W / dpi, H / dpi), dpi=dpi, facecolor=th["bg"])
    canvas = FigureCanvasAgg(fig)
    left, right, bottom, top = 0.035, 0.925, 0.075, 0.845
    ax = fig.add_axes([left, bottom, right - left, top - bottom], facecolor=th["panel"])

    # ---- candles ---------------------------------------------------------
    lo_p, hi_p = float(np.min(l)), float(np.max(h))
    prange = max(hi_p - lo_p, 1e-9)
    px_per_candle = (right - left) * W / max(span_min, 1)
    body_w = 0.68 / 2
    wick_lw = float(np.clip(px_per_candle * 0.17, 0.6, 1.8)) * 72 / dpi * max(s, 0.75)
    up = c >= o
    colors = np.where(up, th["up"], th["down"])
    b_lo = np.minimum(o, c)
    b_hi = np.maximum(np.maximum(o, c), b_lo + prange * 0.0012)  # dojis stay visible
    verts = np.stack([
        np.column_stack([x - body_w, b_lo]), np.column_stack([x - body_w, b_hi]),
        np.column_stack([x + body_w, b_hi]), np.column_stack([x + body_w, b_lo]),
    ], axis=1)
    wicks = np.stack([np.column_stack([x, l]), np.column_stack([x, h])], axis=1)
    ax.add_collection(LineCollection(wicks, colors=colors, linewidths=wick_lw, zorder=3, capstyle="butt"))
    ax.add_collection(PolyCollection(verts, facecolors=colors, edgecolors=colors,
                                     linewidths=0.4 * s, zorder=4))

    pad = prange * 0.05
    ax.set_ylim(lo_p - pad, hi_p + pad)
    ax.set_xlim(-1.0, span_min)

    # ---- marker lines (behind candles, labelled above the plot) -----------
    trans = blended_transform_factory(ax.transData, ax.transAxes)
    for m in markers:
        mt = parse_hhmm(m)
        mx = (ny_epoch(day, mt) - w0) / 60.0
        if not (start <= mt <= end) or mx < -1 or mx > span_min:
            continue
        col = th["marker_open"] if mt == dtime(9, 30) else th["marker"]
        ax.axvline(mx, color=col, lw=1.6 * s, ls=(0, (6, 4)), alpha=0.85, zorder=1)
        ax.text(mx, 1.012, mt.strftime("%H:%M"), transform=trans, ha="center", va="bottom",
                fontsize=13 * s, fontweight="bold", color=th["marker_text"], zorder=6,
                bbox=dict(boxstyle="round,pad=0.32,rounding_size=0.5", fc=col, ec="none"))

    # ---- axes, ticks ----------------------------------------------------
    hour_ticks, hour_labels, minor = [], [], []
    t = datetime.combine(day, start)
    t = t.replace(minute=0) if t.minute == 0 else (t.replace(minute=0) + timedelta(hours=1))
    end_dt = datetime.combine(day, end)
    while t <= end_dt:
        hour_ticks.append((ny_epoch(day, t.time()) - w0) / 60.0)
        hour_labels.append(t.strftime("%H:%M"))
        t += timedelta(hours=1)
    if len(hour_ticks) < 2:  # short windows: label every 15 minutes instead
        hour_ticks, hour_labels = [], []
        t = datetime.combine(day, start)
        t = t.replace(minute=(t.minute // 15) * 15)
        while t <= end_dt:
            if t >= datetime.combine(day, start):
                hour_ticks.append((ny_epoch(day, t.time()) - w0) / 60.0)
                hour_labels.append(t.strftime("%H:%M"))
            t += timedelta(minutes=15)
    else:
        t = datetime.combine(day, start)
        while t <= end_dt:
            if t.minute % 15 == 0:
                minor.append((ny_epoch(day, t.time()) - w0) / 60.0)
            t += timedelta(minutes=1)
    ax.xaxis.set_major_locator(FixedLocator(hour_ticks))
    ax.set_xticklabels(hour_labels)
    ax.xaxis.set_minor_locator(FixedLocator(minor))
    ax.xaxis.set_minor_formatter(NullFormatter())

    ax.yaxis.tick_right()
    ax.yaxis.set_label_position("right")
    ax.yaxis.set_major_locator(MaxNLocator(nbins=10, steps=[1, 2, 2.5, 5, 10]))
    tick = INSTRUMENTS.get(instrument, {}).get("tick", 0.25)
    dec = 2 if tick < 1 else 0
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: _fmt_price(v, dec)))
    ax.grid(axis="y", color=th["grid"], lw=0.9 * s, zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(axis="both", colors=th["muted"], labelsize=14 * s, length=6 * s, width=1 * s)
    ax.tick_params(axis="x", which="minor", length=3 * s, colors=th["spine"])
    ax.tick_params(axis="x", labelcolor=th["text"])
    for side in ("top", "left"):
        ax.spines[side].set_visible(False)
    for side in ("bottom", "right"):
        ax.spines[side].set_color(th["spine"])
        ax.spines[side].set_linewidth(1 * s)
    ax.set_xlabel("New York time (ET)", color=th["muted"], fontsize=13 * s, labelpad=8 * s)
    ax.set_ylabel("Price", color=th["muted"], fontsize=13 * s, labelpad=12 * s)

    # ---- titles ---------------------------------------------------------
    inst_name = INSTRUMENTS.get(instrument, {}).get("name", "")
    fig.text(left, 0.952, f"{instrument}  ·  {day.strftime('%A')}, {day.strftime('%B')} {day.day}, {day.year}",
             color=th["text"], fontsize=28 * s, fontweight="bold", ha="left", va="center")
    expected = int(round(span_min))
    contract = bars.get("symbol") or ""
    sub = f"{inst_name}{'  ·  ' + contract if contract else ''}  ·  1-minute candles  ·  {start.strftime('%H:%M')}–{end.strftime('%H:%M')} New York time"
    if n < expected * 0.9:
        sub += f"  ·  partial data: {n}/{expected} bars"
    fig.text(left, 0.908, sub, color=th["muted"], fontsize=15 * s, ha="left", va="center")

    op, cl = float(o[0]), float(c[-1])
    chg = cl - op
    stats = (f"O {_fmt_price(op, dec)}   H {_fmt_price(hi_p, dec)}   "
             f"L {_fmt_price(lo_p, dec)}   C {_fmt_price(cl, dec)}")
    fig.text(right, 0.952, stats, color=th["text"], fontsize=16 * s, ha="right", va="center",
             family="DejaVu Sans Mono")
    fig.text(right, 0.908, f"{chg:+,.{dec}f} ({chg / op * 100:+.2f}%)   range {prange:,.{dec}f}",
             color=th["up"] if chg >= 0 else th["down"], fontsize=15 * s, ha="right", va="center",
             family="DejaVu Sans Mono")

    # ---- write ----------------------------------------------------------
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    if Image is not None:
        canvas.draw()
        img = Image.fromarray(np.asarray(canvas.buffer_rgba())[..., :3])
        img.save(out_path, format="PNG", compress_level=6)
        if thumb_path:
            os.makedirs(os.path.dirname(thumb_path), exist_ok=True)
            tw = 560
            img.resize((tw, int(tw * H / W)), Image.BILINEAR if W <= 1920 else Image.BOX).save(
                thumb_path, format="PNG", compress_level=3)
    else:  # pragma: no cover
        fig.savefig(out_path, dpi=dpi, facecolor=th["bg"])
        if thumb_path:
            fig.savefig(thumb_path, dpi=dpi * 560 / W, facecolor=th["bg"])
    fig.clear()
    return {"bars": n, "open": op, "high": hi_p, "low": lo_p, "close": cl}
