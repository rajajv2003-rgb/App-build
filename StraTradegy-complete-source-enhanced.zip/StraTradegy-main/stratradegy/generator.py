"""Turns a date range into one PNG per trading day."""

from __future__ import annotations

import json
import os
import shutil
import threading
import time
import traceback
from dataclasses import dataclass, field
from datetime import date, datetime, time as dtime, timedelta

from .calendar_us import holiday_name, is_weekend
from .timeparse import ny_epoch, parse_hhmm
from .config import DEFAULT_MARKERS, INSTRUMENTS, RESOLUTIONS
from .data_loader import BarStore, Cancelled

PUBLIC_ROOT = "Pictures/FuturesCharts"
MAX_DAYS_WITHOUT_CONFIRM = 400


@dataclass
class GenerateRequest:
    instrument: str
    start_date: date
    end_date: date
    start_time: dtime = dtime(7, 0)
    end_time: dtime = dtime(11, 0)
    theme: str = "dark"
    size: tuple = (1920, 1080)
    skip_holidays: bool = True
    markers: list = field(default_factory=lambda: list(DEFAULT_MARKERS))

    @property
    def run_name(self) -> str:
        return f"{self.start_date.isoformat()}_to_{self.end_date.isoformat()}"

    @property
    def public_rel_dir(self) -> str:
        return f"{PUBLIC_ROOT}/{self.instrument}/{self.run_name}"

    @classmethod
    def from_strings(cls, instrument, start_date, end_date, start_time="07:00", end_time="11:00",
                     theme="dark", resolution="1920x1080", skip_holidays=True, markers=None):
        def d(s, what):
            try:
                return date.fromisoformat(s.strip())
            except (ValueError, AttributeError):
                raise ValueError(f"Invalid {what} '{s}'. Use YYYY-MM-DD.") from None

        req = cls(
            instrument=instrument,
            start_date=d(start_date, "start date"),
            end_date=d(end_date, "end date"),
            start_time=parse_hhmm(start_time),
            end_time=parse_hhmm(end_time),
            theme=theme,
            size=RESOLUTIONS.get(resolution, (1920, 1080)),
            skip_holidays=skip_holidays,
            markers=list(markers or DEFAULT_MARKERS),
        )
        validate(req)
        return req


def validate(req: GenerateRequest):
    if req.instrument not in INSTRUMENTS:
        raise ValueError(f"Unknown instrument '{req.instrument}'.")
    if req.end_date < req.start_date:
        raise ValueError("End date is before start date.")
    if req.end_time <= req.start_time:
        raise ValueError("End time must be after start time (windows past midnight are not supported).")
    if (req.end_date - req.start_date).days > 366 * 20:
        raise ValueError("Date range is longer than 20 years.")


def count_days(req: GenerateRequest) -> int:
    return (req.end_date - req.start_date).days + 1


@dataclass
class Summary:
    run_dir: str
    made: list = field(default_factory=list)  # dicts: date, file, thumb, uri
    skipped: dict = field(default_factory=lambda: {"weekend": [], "holiday": [], "no data": []})
    errors: list = field(default_factory=list)  # (date, message)
    cancelled: bool = False
    seconds: float = 0.0
    data_range: tuple = ("", "")

    def text(self) -> str:
        lines = [f"{len(self.made)} chart(s) created in {self.seconds:.0f}s."]
        sk = self.skipped
        total_sk = sum(len(v) for v in sk.values())
        if total_sk:
            parts = [f"{len(v)} {k}" for k, v in sk.items() if v]
            lines.append(f"{total_sk} day(s) skipped: " + ", ".join(parts) + ".")
        if sk["holiday"]:
            lines.append("Holidays: " + ", ".join(f"{d} ({n})" for d, n in sk["holiday"][:12])
                         + (" ..." if len(sk["holiday"]) > 12 else ""))
        if sk["no data"]:
            nd = [d for d, _ in sk["no data"]]
            lines.append("No data: " + ", ".join(nd[:12]) + (" ..." if len(nd) > 12 else ""))
        if self.errors:
            lines.append(f"{len(self.errors)} error(s): " + "; ".join(f"{d}: {m}" for d, m in self.errors[:3]))
        if self.cancelled:
            lines.append("Cancelled before finishing.")
        if not self.made and not self.cancelled:
            a, b = self.data_range
            lines.append(f"No data in this range. Imported data covers {a} to {b}.")
        return "\n".join(lines)


def run_generation(req: GenerateRequest, store: BarStore, work_root: str, sink=None,
                   progress=None, cancel: threading.Event | None = None) -> Summary:
    """Render charts. ``sink.publish(local_png, req, filename) -> uri|None`` copies to
    the public gallery; ``progress(fraction, text, entry_or_None)`` reports status."""
    validate(req)
    from .chart_renderer import render_day  # matplotlib import is slow on phones: load on demand

    progress = progress or (lambda f, t, e=None: None)
    run_dir = os.path.join(work_root, req.instrument, req.run_name)
    shutil.rmtree(run_dir, ignore_errors=True)
    os.makedirs(os.path.join(run_dir, "thumbs"), exist_ok=True)
    summary = Summary(run_dir=run_dir, data_range=(store.meta.get("first", "?"), store.meta.get("last", "?")))
    t0 = time.time()
    total = count_days(req)

    d = req.start_date
    i = 0
    while d <= req.end_date:
        if cancel is not None and cancel.is_set():
            summary.cancelled = True
            break
        i += 1
        ds = d.isoformat()
        entry = None
        if is_weekend(d):
            summary.skipped["weekend"].append((ds, d.strftime("%A")))
        elif req.skip_holidays and holiday_name(d):
            summary.skipped["holiday"].append((ds, holiday_name(d)))
        else:
            bars = store.window(ny_epoch(d, req.start_time), ny_epoch(d, req.end_time))
            if len(bars["ts"]) == 0:
                summary.skipped["no data"].append((ds, ""))
            else:
                fname = f"{req.instrument}_{ds}.png"
                out = os.path.join(run_dir, fname)
                thumb = os.path.join(run_dir, "thumbs", fname)
                try:
                    info = render_day(bars, d, req.instrument, req.start_time, req.end_time,
                                      out, thumb, theme=req.theme, size=req.size, markers=req.markers)
                    uri = None
                    if sink is not None:
                        try:
                            uri = sink.publish(out, req, fname)
                        except Exception as exc:  # keep going; the local copy exists
                            summary.errors.append((ds, f"gallery save failed: {exc}"))
                    entry = {"date": ds, "weekday": d.strftime("%a"), "file": fname,
                             "thumb": f"thumbs/{fname}", "uri": uri, "bars": info["bars"],
                             "contract": bars.get("symbol", "")}
                    summary.made.append(entry)
                except Exception as exc:
                    traceback.print_exc()
                    summary.errors.append((ds, str(exc)))
        el = time.time() - t0
        n_made = len(summary.made)
        eta = ""
        if n_made >= 2:
            per = el / i
            eta = f" · ~{int(per * (total - i))}s left"
        progress(i / total, f"{ds}: {n_made} chart(s) made, day {i}/{total}{eta}", entry)
        d += timedelta(days=1)

    summary.seconds = time.time() - t0
    manifest = {
        "instrument": req.instrument,
        "start": req.start_date.isoformat(), "end": req.end_date.isoformat(),
        "window": [req.start_time.strftime("%H:%M"), req.end_time.strftime("%H:%M")],
        "theme": req.theme, "size": list(req.size),
        "public_dir": req.public_rel_dir,
        "created": datetime.now().isoformat(timespec="seconds"),
        "charts": summary.made,
        "skipped": summary.skipped, "errors": summary.errors,
        "summary": summary.text(),
    }
    with open(os.path.join(run_dir, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    return summary


def list_runs(work_root: str) -> list[dict]:
    """Previous runs (newest first) for the gallery."""
    runs = []
    if not os.path.isdir(work_root):
        return runs
    for inst in sorted(os.listdir(work_root)):
        idir = os.path.join(work_root, inst)
        if not os.path.isdir(idir):
            continue
        for name in os.listdir(idir):
            mpath = os.path.join(idir, name, "manifest.json")
            try:
                with open(mpath) as f:
                    m = json.load(f)
            except (OSError, ValueError):
                continue
            m["run_dir"] = os.path.join(idir, name)
            m["mtime"] = os.path.getmtime(mpath)
            runs.append(m)
    runs.sort(key=lambda m: m["mtime"], reverse=True)
    return runs


__all__ = ["GenerateRequest", "Summary", "run_generation", "validate", "list_runs",
           "count_days", "Cancelled", "MAX_DAYS_WITHOUT_CONFIRM"]


def plan_days(store: BarStore, instrument: str, start: date, end: date, start_time: dtime, end_time: dtime,
              skip_holidays: bool = True, cancel: threading.Event | None = None) -> list[dict]:
    """Classify every weekday in [start, end] the same way run_generation does.

    Returns dicts: date (iso), kind ('ok' | 'holiday' | 'nodata'), name (holiday),
    chg (window close/open - 1, ok days), symbol, bars. Weekends are omitted.
    Used for the calendar heatmap and the exact PNG count.
    """
    out = []
    d = start
    while d <= end:
        if cancel is not None and cancel.is_set():
            break
        if d.weekday() < 5:
            ds = d.isoformat()
            hol = holiday_name(d) if skip_holidays else None
            if hol:
                out.append({"date": ds, "kind": "holiday", "name": hol})
            else:
                b = store.window(ny_epoch(d, start_time), ny_epoch(d, end_time))
                n = len(b["ts"])
                if n == 0:
                    out.append({"date": ds, "kind": "nodata"})
                else:
                    o, c = float(b["open"][0]), float(b["close"][-1])
                    out.append({"date": ds, "kind": "ok", "chg": (c / o - 1) if o else 0.0,
                                "symbol": b.get("symbol", ""), "bars": n})
        d += timedelta(days=1)
    return out
