"""Deterministic day analysis: the facts the on-device model is allowed to talk about.

A phone-sized language model cannot read a chart and invents numbers when asked
open questions, so every number comes from here. The model only phrases them.
The same facts are shown directly in the app when no model is installed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, time as dtime, timedelta, timezone

import numpy as np

from .calendar_us import holiday_name
from .timeparse import get_zone, ny_epoch

NY = "America/New_York"
OPEN_RTH = dtime(9, 30)
OR_END = dtime(9, 45)


def _hhmm(ts: int) -> str:
    return datetime.fromtimestamp(int(ts), tz=timezone.utc).astimezone(get_zone(NY)).strftime("%H:%M")


def _prev_trading_day(d: date) -> date:
    p = d - timedelta(days=1)
    while p.weekday() >= 5 or holiday_name(p):
        p -= timedelta(days=1)
    return p


@dataclass
class DayFacts:
    day: date
    instrument: str
    contract: str
    start: dtime
    end: dtime
    tick_dec: int = 2
    values: dict = field(default_factory=dict)
    lines: list = field(default_factory=list)

    def headline(self) -> str:
        v = self.values
        if not v:
            return ""
        chg = v["change"]
        s = (f"{self.instrument} {'rose' if chg >= 0 else 'fell'} {abs(chg):,.2f} pts in this window, "
             f"{v.get('kind', '')}")
        if "mood" in v:
            s += f", {v['mood']}"
        return s + "."

    def text(self) -> str:
        head = (f"{self.instrument} {self.day.strftime('%a')} {self.day.isoformat()}"
                + (f" ({self.contract})" if self.contract else "")
                + f", window {self.start.strftime('%H:%M')}-{self.end.strftime('%H:%M')} New York time")
        return head + "\n" + "\n".join(f"- {ln}" for ln in self.lines)


def analyze_day(store, instrument: str, d: date, start: dtime, end: dtime) -> DayFacts | None:
    """Compute plain-language facts for one day's window. None if no bars."""
    w0, w1 = ny_epoch(d, start), ny_epoch(d, end)
    b = store.window(w0, w1)
    if len(b["ts"]) == 0:
        return None
    ts, o, h, l, c = b["ts"], b["open"], b["high"], b["low"], b["close"]
    f = DayFacts(day=d, instrument=instrument, contract=b.get("symbol", ""), start=start, end=end)
    p = lambda x: f"{x:,.2f}"  # noqa: E731
    sp = lambda x: f"{x:+,.2f}"  # noqa: E731
    v = f.values

    op, cl = float(o[0]), float(c[-1])
    ih, il = int(np.argmax(h)), int(np.argmin(l))
    hi, lo = float(h[ih]), float(l[il])
    v.update(open=op, close=cl, high=hi, low=lo, change=cl - op, range=hi - lo,
             high_time=_hhmm(ts[ih]), low_time=_hhmm(ts[il]))
    chg = cl - op
    f.lines.append(f"Result: price went from {p(op)} at {start.strftime('%H:%M')} to {p(cl)} at "
                   f"{end.strftime('%H:%M')}, {'up' if chg >= 0 else 'down'} {abs(chg):,.2f} pts "
                   f"({abs(cl / op - 1) * 100:.2f}%).")
    f.lines.append(f"Highest price {p(hi)} at {v['high_time']}. Lowest price {p(lo)} at {v['low_time']}. "
                   f"Range {p(hi - lo)} pts.")

    # prior session close (last bar 15:00-16:00 ET of the previous trading day)
    pd = _prev_trading_day(d)
    prev = store.window(ny_epoch(pd, dtime(15, 0)), ny_epoch(pd, dtime(16, 0)))
    if len(prev["ts"]) and (not f.contract or prev.get("symbol") == f.contract):
        pc = float(prev["close"][-1])
        v.update(prior_close=pc, gap=op - pc)
        f.lines.append(f"Previous day's close (16:00 on {pd.isoformat()}): {p(pc)}. At "
                       f"{start.strftime('%H:%M')} price was {abs(op - pc):,.2f} pts "
                       f"{'higher' if op >= pc else 'lower'} than that.")

    # overnight session (18:00 previous calendar day -> 09:30)
    on0 = int(datetime.combine(d - timedelta(days=1), dtime(18, 0), tzinfo=get_zone(NY)).timestamp())
    on = store.window(on0, ny_epoch(d, OPEN_RTH))
    if len(on["ts"]) > 30 and (not f.contract or on.get("symbol") == f.contract):
        onh, onl = float(on["high"].max()), float(on["low"].min())
        v.update(overnight_high=onh, overnight_low=onl)
        line = f"Overnight trading (18:00 to 09:30): highest {p(onh)}, lowest {p(onl)}."
        after = ts >= ny_epoch(d, OPEN_RTH)
        if after.any():
            ab = np.nonzero(after & (h > onh))[0]
            bl = np.nonzero(after & (l < onl))[0]
            if len(ab):
                line += f" After 09:30 price went above the overnight high at {_hhmm(ts[ab[0]])}."
            if len(bl):
                line += f" After 09:30 price went below the overnight low at {_hhmm(ts[bl[0]])}."
            if not len(ab) and not len(bl):
                line += " Price stayed inside the overnight range after 09:30."
        f.lines.append(line)

    t930 = ny_epoch(d, OPEN_RTH)
    if start < OPEN_RTH < end:
        pre = ts < t930
        post = ~pre
        if pre.any() and post.any():
            i_open = int(np.argmax(post))
            rth_open = float(o[i_open])
            v.update(rth_open=rth_open, pre_change=rth_open - op, post_change=cl - rth_open)
            mv = rth_open - op
            f.lines.append(f"From {start.strftime('%H:%M')} to 09:30 price {'rose' if mv >= 0 else 'fell'} "
                           f"{abs(mv):,.2f} pts. Price at the 09:30 stock-market open: {p(rth_open)}.")
            mv2 = cl - rth_open
            f.lines.append(f"From 09:30 to {end.strftime('%H:%M')} price {'rose' if mv2 >= 0 else 'fell'} "
                           f"{abs(mv2):,.2f} pts.")
    if start <= OPEN_RTH and end > OR_END:
        orm = (ts >= t930) & (ts < ny_epoch(d, OR_END))
        if orm.sum() >= 5:
            orh, orl = float(h[orm].max()), float(l[orm].min())
            v.update(or_high=orh, or_low=orl)
            later = ts >= ny_epoch(d, OR_END)
            up = np.nonzero(later & (h > orh))[0]
            dn = np.nonzero(later & (l < orl))[0]
            first = None
            if len(up) and (not len(dn) or up[0] < dn[0]):
                first = ("UP", ts[up[0]])
            elif len(dn):
                first = ("DOWN", ts[dn[0]])
            txt = f"Opening range (first 15 minutes, 09:30-09:45): {p(orl)} to {p(orh)}."
            if first:
                v["or_break"] = first[0]
                txt += (f" Price first left it {'upward' if first[0] == 'UP' else 'downward'} "
                        f"at {_hhmm(first[1])}.")
                if len(up) and len(dn):
                    txt += " Both sides were broken later (two-sided)."
            else:
                txt += " Price never left the opening range."
            f.lines.append(txt)

    # character: efficiency ratio of closes
    path = float(np.abs(np.diff(c)).sum()) or 1.0
    er = abs(cl - op) / path
    v["trend_score"] = er
    kind = "a trend day (mostly one direction)" if er > 0.35 else (
        "a mild trend" if er > 0.18 else "a choppy day (back and forth, no clear direction)")
    v["kind"] = kind
    f.lines.append(f"Type of day: {kind}. Trend score {er:.2f} on a 0-1 scale.")

    # range vs previous 20 trading days, same window
    ranges = []
    dd = d
    for _ in range(40):
        dd = _prev_trading_day(dd)
        bb = store.window(ny_epoch(dd, start), ny_epoch(dd, end))
        if len(bb["ts"]):
            ranges.append(float(bb["high"].max() - bb["low"].min()))
        if len(ranges) >= 20:
            break
    if len(ranges) >= 5:
        avg = sum(ranges) / len(ranges)
        rel = (hi - lo) / avg if avg else 0
        v.update(avg_range=avg, rel_range=rel)
        mood = "busier than usual" if rel > 1.4 else ("quieter than usual" if rel < 0.7 else "a normal amount of movement")
        v["mood"] = mood
        f.lines.append(f"Compared with the previous {len(ranges)} days ({p(avg)} pts average range) this day "
                       f"was {mood} ({rel:.1f}x).")

    if len(c) >= 6:
        d5 = c[5:] - c[:-5]
        k = int(np.argmax(np.abs(d5)))
        v.update(big5=float(d5[k]), big5_time=_hhmm(ts[k]))
        f.lines.append(f"Fastest 5-minute move: {'up' if d5[k] >= 0 else 'down'} {abs(float(d5[k])):,.2f} pts "
                       f"starting {_hhmm(ts[k])}.")

    marks = []
    for m in ("08:00", "09:00", "09:30"):
        mt = dtime(int(m[:2]), int(m[3:]))
        if start <= mt < end:
            idx = np.nonzero(ts >= ny_epoch(d, mt))[0]
            if len(idx):
                marks.append(f"{m} {p(float(o[idx[0]]))}")
    if marks:
        f.lines.append("Price at the marker lines: " + ", ".join(marks) + ".")
    return f


def range_summary(days: list[dict]) -> str:
    """One paragraph over the planned range (from generator.plan_days)."""
    ok = [x for x in days if x["kind"] == "ok"]
    if not ok:
        return "No trading days with data in this range."
    up = [x for x in ok if x["chg"] >= 0]
    best = max(ok, key=lambda x: x["chg"])
    worst = min(ok, key=lambda x: x["chg"])
    avg = sum(x["chg"] for x in ok) / len(ok) * 100
    return (f"{len(ok)} trading days: {len(up)} up, {len(ok) - len(up)} down in the window. "
            f"Average window move {avg:+.2f}%. Best {best['date']} ({best['chg'] * 100:+.2f}%), "
            f"worst {worst['date']} ({worst['chg'] * 100:+.2f}%).")
