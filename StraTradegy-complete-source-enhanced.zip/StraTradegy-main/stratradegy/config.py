"""CSV format description and persisted app settings."""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field, fields

INSTRUMENTS = {
    # tick size drives price-axis formatting
    "NQ": {"name": "Nasdaq-100 E-mini", "tick": 0.25},
    "ES": {"name": "S&P 500 E-mini", "tick": 0.25},
}

# Vertical marker lines (New York time). Only those inside the window are drawn.
DEFAULT_MARKERS = ["07:00", "08:00", "09:00", "09:30"]

RESOLUTIONS = {
    "1920x1080": (1920, 1080),
    "2560x1440": (2560, 1440),
    "3840x2160": (3840, 2160),
}

COMMON_TIMEZONES = [
    "America/New_York",
    "America/Chicago",
    "UTC",
    "Europe/London",
    "Europe/Berlin",
    "Asia/Kolkata",
    "Asia/Singapore",
    "Australia/Sydney",
]


@dataclass
class CsvFormat:
    """How to read the user's CSV. Column refs are header names, or 0-based
    indexes (as strings, e.g. "0") when the file has no header."""

    delimiter: str = ","
    has_header: bool = True
    ts_col: str = "timestamp"
    time_col: str = ""  # set when date and time are separate columns
    ts_format: str = "%Y-%m-%d %H:%M:%S"
    source_tz: str = "America/New_York"
    open_col: str = "open"
    high_col: str = "high"
    low_col: str = "low"
    close_col: str = "close"
    volume_col: str = ""
    # Optional contract column (e.g. Databento "symbol": ESH1, NQM4, ESZ4-ESH5).
    # When set, one file may hold several instruments and contract months: rows are
    # split by root (NQ/ES), calendar spreads are dropped, and every chart uses the
    # most-traded contract inside its time window.
    symbol_col: str = ""
    # Many vendors label a 1-minute bar by its *close* time (09:31 = 09:30-09:31).
    # Charts and windows here use bar *open* time, so "close" shifts by -60 s.
    bar_label: str = "open"

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict):
        names = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in (d or {}).items() if k in names})

    def signature(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True)


@dataclass
class AppSettings:
    instrument: str = "NQ"
    start_date: str = ""
    end_date: str = ""
    start_time: str = "07:00"
    end_time: str = "11:00"
    theme: str = "dark"
    resolution: str = "1920x1080"
    skip_holidays: bool = True
    markers: list = field(default_factory=lambda: list(DEFAULT_MARKERS))
    # per instrument: {"sources": [{"uri"/"path", "name", "size"}], "format": {...}}  (legacy)
    data: dict = field(default_factory=dict)
    # CSV library: [{"id", "source": {...}, "format": {...}, "instrument": None|"NQ"|"ES",
    #                "enabled": bool, "peek": {"first", "last", "roots"}}]
    library: list = field(default_factory=list)
    library_built: list = field(default_factory=list)  # signature of the last prepared library
    ai_model: str = ""  # path to a .gguf file
    seen_intro: bool = False

    @classmethod
    def load(cls, path: str) -> "AppSettings":
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except (OSError, ValueError):
            return cls()
        names = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in raw.items() if k in names})

    def save(self, path: str):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(asdict(self), f, indent=2)
        os.replace(tmp, path)

    def instrument_data(self, inst: str) -> dict:
        return self.data.setdefault(inst, {"sources": [], "format": CsvFormat().to_dict()})
