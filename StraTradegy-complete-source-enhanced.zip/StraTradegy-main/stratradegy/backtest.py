"""PMH/PML sweep + FVG limit-order backtest (see docs/BACKTEST_SPEC.md).

All strategy logic is in ``simulate_day`` - edit the rules there. Everything else
(choosing days, the contract, statistics, CSV) is plumbing around it.

Times are New York minutes of the day (420 = 07:00, 570 = 09:30, 660 = 11:00).
Candles are stamped with their open time; the last candle used is 10:59.
"""

from __future__ import annotations

import csv
import os
import threading
from dataclasses import asdict, dataclass, field
from datetime import date, time as dtime, timedelta

import numpy as np

from .calendar_us import holiday_name
from .timeparse import ny_epoch

PRE_START, RTH_OPEN, CUTOFF = 7 * 60, 9 * 60 + 30, 11 * 60

# Outcomes of a filled trade
WIN, LOSE, BOTH, OPEN, BREAKEVEN = "Win", "Lose", "Both Hit (Same Candle)", "Open at 11:00", "Breakeven"
# Reasons an order did not fill
CANCEL_TP, CANCEL_TIME = "Cancelled: TP before fill", "Cancelled: not filled by 11:00"
# Day statuses that produce no order
NO_DATA, HOLIDAY, AMBIGUOUS, NO_SWEEP, NO_FVG, INVALID = (
    "No data", "Holiday", "Ambiguous", "No sweep", "No FVG", "Invalid order (zero risk)")


def hhmm(minute: int) -> str:
    return f"{minute // 60:02d}:{minute % 60:02d}"


@dataclass
class DayResult:
    status: str                    # "filled", "cancelled" or one of the no-order statuses above
    direction: str = ""            # "Long" / "Short"
    pmh: float = float("nan")
    pml: float = float("nan")
    sweep_i: int = -1              # index of the sweep candle
    fvg: tuple = ()                # (candle1, candle2, candle3) indexes
    entry: float = float("nan")
    sl: float = float("nan")
    tp: float = float("nan")
    fill_i: int = -1
    exit_i: int = -1
    outcome: str = ""              # Win / Lose / Breakeven / Both Hit / Open / cancel reason
    be_activated: bool = False
    final_exit: float = float("nan")


def simulate_day(minutes, o, h, l, c, model: int, rr: float, cancel_tp_before_entry: bool = True, be_trigger: float | None = None) -> DayResult:
    """Apply the strategy to ONE day of 1-minute candles (one contract, 07:00-10:59 NY).

    minutes: NY minute-of-day of each candle's open time, ascending.
    model:   1 -> entry = open of candle 3;  2 -> entry = low (long) / high (short) of candle 3.
    rr:      take profit = entry +/- rr * risk.
    """
    minutes = np.asarray(minutes)
    n = len(minutes)

    # 1. Pre-market range: candles 07:00 .. 09:29 ------------------------------------------
    pre = (minutes >= PRE_START) & (minutes < RTH_OPEN)
    rth = np.nonzero((minutes >= RTH_OPEN) & (minutes < CUTOFF))[0]
    if not pre.any() or len(rth) == 0:
        return DayResult(NO_DATA)
    pmh, pml = float(h[pre].max()), float(l[pre].min())
    res = DayResult("", pmh=pmh, pml=pml)

    # 2./3. First sweep from 09:30: above PMH -> short, below PML -> long, both -> ambiguous --
    for k in rth:
        took_high, took_low = h[k] > pmh, l[k] < pml
        if took_high and took_low:
            res.status, res.sweep_i = AMBIGUOUS, int(k)
            return res
        if took_high or took_low:
            res.sweep_i = int(k)
            res.direction = "Short" if took_high else "Long"
            break
    else:
        res.status = NO_SWEEP
        return res
    s = res.sweep_i
    long = res.direction == "Long"

    # 4. First FVG in the trade direction that includes or follows the sweep candle ----------
    #    candle 3 is at/after the sweep, so the sweep can be candle 1, 2 or 3.
    for j3 in range(max(s, 2), n):
        if minutes[j3] >= CUTOFF:
            break
        j1, j2 = j3 - 2, j3 - 1
        bullish = l[j3] > h[j1]
        bearish = h[j3] < l[j1]
        if (long and bullish) or (not long and bearish):
            res.fvg = (j1, j2, j3)
            break
    else:
        res.status = NO_FVG
        return res
    j1, j2, j3 = res.fvg

    # 5. Limit order -------------------------------------------------------------------------
    if model == 1:
        entry = float(o[j3])
    else:
        entry = float(l[j3]) if long else float(h[j3])
    sl = float(l[j2]) if long else float(h[j2])
    risk = (entry - sl) if long else (sl - entry)
    if not risk > 0:
        res.status, res.entry, res.sl = INVALID, entry, sl
        return res
    tp = entry + rr * risk if long else entry - rr * risk
    res.entry, res.sl, res.tp = entry, sl, tp

    # 6.-8. Walk forward. BE trigger and outcomes use initial risk as the R denominator.
    filled = False
    be_active = False
    trigger_price = None if be_trigger is None else (entry + be_trigger * risk if long else entry - be_trigger * risk)
    for k in range(j3 + 1, n):
        if minutes[k] >= CUTOFF:
            break
        if not filled:
            entry_touched = (l[k] <= entry) if long else (h[k] >= entry)
            tp_touched = (h[k] >= tp) if long else (l[k] <= tp)
            # OHLC cannot tell whether the target printed before or after a limit
            # fill when both are touched in the same candle. Never grant a
            # favourable fill/target ordering: cancel under the legacy ON rule,
            # otherwise flag the setup unresolved rather than inventing a win.
            if entry_touched and tp_touched:
                if cancel_tp_before_entry:
                    res.status, res.outcome, res.exit_i = "cancelled", CANCEL_TP, k
                else:
                    res.status, res.outcome, res.exit_i = "ambiguous", "Ambiguous (entry and TP same candle)", k
                return res
            if entry_touched:
                filled, res.fill_i = True, k
            elif cancel_tp_before_entry and tp_touched:
                res.status, res.outcome, res.exit_i = "cancelled", CANCEL_TP, k
                return res
            else:
                continue
        hit_sl = (l[k] <= sl) if long else (h[k] >= sl)
        hit_tp = (h[k] >= tp) if long else (l[k] <= tp)
        hit_trigger = False if trigger_price is None else ((h[k] >= trigger_price) if long else (l[k] <= trigger_price))
        if not be_active:
            if be_trigger is not None and hit_sl and hit_trigger:
                res.status, res.outcome, res.exit_i, res.final_exit = "filled", LOSE, k, sl
                return res
            if be_trigger is not None and hit_trigger:
                res.be_activated = be_active = True
                hit_be = (l[k] <= entry) if long else (h[k] >= entry)
                if hit_tp or hit_be:
                    res.status, res.outcome, res.exit_i, res.final_exit = "filled", BREAKEVEN, k, entry
                    return res
                continue
            if hit_sl or hit_tp:
                res.status, res.exit_i = "filled", k
                res.outcome = BOTH if hit_sl and hit_tp else (LOSE if hit_sl else WIN)
                res.final_exit = sl if hit_sl else tp
                return res
        else:
            hit_be = (l[k] <= entry) if long else (h[k] >= entry)
            if hit_tp and hit_be:
                res.status, res.outcome, res.exit_i, res.final_exit = "filled", BREAKEVEN, k, entry
                return res
            if hit_tp:
                res.status, res.outcome, res.exit_i, res.final_exit = "filled", WIN, k, tp
                return res
            if hit_be:
                res.status, res.outcome, res.exit_i, res.final_exit = "filled", BREAKEVEN, k, entry
                return res
    if not filled:
        res.status, res.outcome = "cancelled", CANCEL_TIME
    else:
        res.status, res.outcome = "filled", OPEN
    return res


# running over a date range
# ------------------------------------------------------------------------------------------
@dataclass
class Trade:
    date: str
    weekday: str
    contract: str
    direction: str
    outcome: str
    status: str
    entry: float
    sl: float
    tp: float
    risk_pts: float
    reward_pts: float
    pmh: float
    pml: float
    sweep_time: str
    fvg_times: str
    fill_time: str
    exit_time: str
    model: int
    rr: float
    be_enabled: bool = False
    be_trigger: float | None = None
    be_activated: bool = False
    final_exit: float = float("nan")
    final_r: float = 0.0
    exit_reason: str = ""
    instrument: str = ""


@dataclass
class DayLog:
    date: str
    weekday: str
    contract: str
    status: str
    note: str = ""


@dataclass
class BacktestResult:
    instrument: str
    start: str
    end: str
    model: int
    rr: float
    cancel_tp_before_entry: bool = True
    be_trigger: float | None = None
    trades: list = field(default_factory=list)   # every order placed (filled + cancelled)
    days: list = field(default_factory=list)     # one DayLog per weekday in range
    summary: dict = field(default_factory=dict)
    cancelled: bool = False

    @property
    def folder_name(self) -> str:
        return f"{self.instrument}_{self.start}_to_{self.end}"


def day_bars(store, d: date):
    """07:00-10:59 NY candles of the day's most-traded contract (chosen by BarStore.window)."""
    w0 = ny_epoch(d, dtime(7, 0))
    b = store.window(w0, ny_epoch(d, dtime(11, 0)))
    if len(b["ts"]) == 0:
        return None
    b["minutes"] = PRE_START + (b["ts"] - w0) // 60
    return b


def streaks(outcomes) -> dict:
    """Longest/shortest win and loss streaks over Win/Lose only (others are skipped)."""
    runs = {WIN: [], LOSE: []}
    cur, length = None, 0
    for o in outcomes:
        if o not in (WIN, LOSE):
            continue  # Both Hit / Open at 11:00 neither break nor extend a streak
        if o == cur:
            length += 1
        else:
            if cur:
                runs[cur].append(length)
            cur, length = o, 1
    if cur:
        runs[cur].append(length)
    pick = lambda xs, f: f(xs) if xs else 0  # noqa: E731
    return {"longest_win": pick(runs[WIN], max), "shortest_win": pick(runs[WIN], min),
            "longest_loss": pick(runs[LOSE], max), "shortest_loss": pick(runs[LOSE], min)}


def summarize(trades, days) -> dict:
    count = lambda pred: sum(1 for t in trades if pred(t))  # noqa: E731
    wins, losses = count(lambda t: t.outcome == WIN), count(lambda t: t.outcome == LOSE)
    s = {
        "orders": len(trades),
        "filled": count(lambda t: t.status == "filled"),
        "cancelled": count(lambda t: t.status == "cancelled"),
        "cancelled_tp": count(lambda t: t.outcome == CANCEL_TP),
        "cancelled_time": count(lambda t: t.outcome == CANCEL_TIME),
        "wins": wins,
        "losses": losses,
        "breakeven": count(lambda t: t.outcome == BREAKEVEN),
        "be_activated": count(lambda t: t.be_activated),
        "both_hit": count(lambda t: t.outcome == BOTH),
        "open_1100": count(lambda t: t.outcome == OPEN),
        "ambiguous": sum(1 for d in days if d.status == AMBIGUOUS),
        "no_sweep": sum(1 for d in days if d.status == NO_SWEEP),
        "no_fvg": sum(1 for d in days if d.status == NO_FVG),
        "invalid": sum(1 for d in days if d.status == INVALID),
        "no_data": sum(1 for d in days if d.status == NO_DATA),
        "holidays": sum(1 for d in days if d.status == HOLIDAY),
        "win_rate": (wins / (wins + losses)) if (wins + losses) else None,
    }
    s.update(streaks([t.outcome for t in sorted(trades, key=lambda t: t.date) if t.status == "filled"]))
    return s


def run_backtest(store, instrument: str, start: date, end: date, model: int, rr: float,
                 skip_holidays: bool = True, progress=None, cancel: threading.Event | None = None,
                 keep_bars: bool = False, cancel_tp_before_entry: bool = True,
                 be_trigger: float | None = None) -> BacktestResult:
    if model not in (1, 2):
        raise ValueError("Model must be 1 or 2.")
    if not rr > 0:
        raise ValueError("Risk-to-reward must be a number above 0, for example 2 or 1.5.")
    if end < start:
        raise ValueError("The end date is before the start date.")
    if be_trigger is not None and not be_trigger > 0:
        raise ValueError("Breakeven trigger must be above 0R.")
    progress = progress or (lambda f, t: None)
    out = BacktestResult(instrument, start.isoformat(), end.isoformat(), model, rr, cancel_tp_before_entry, be_trigger)
    out.bars = {} if keep_bars else None
    total = (end - start).days + 1
    d, i = start, 0
    while d <= end:
        if cancel is not None and cancel.is_set():
            out.cancelled = True
            break
        i += 1
        ds, wd = d.isoformat(), d.strftime("%a")
        if d.weekday() < 5:
            hol = holiday_name(d) if skip_holidays else None
            if hol:
                out.days.append(DayLog(ds, wd, "", HOLIDAY, hol))
            else:
                b = day_bars(store, d)
                if b is None:
                    out.days.append(DayLog(ds, wd, "", NO_DATA))
                else:
                    r = simulate_day(b["minutes"], b["open"], b["high"], b["low"], b["close"], model, rr, cancel_tp_before_entry, be_trigger)
                    con = b.get("symbol", "")
                    note = ""
                    if r.status in ("filled", "cancelled"):
                        m = b["minutes"]
                        risk = abs(r.entry - r.sl)
                        t = Trade(ds, wd, con, r.direction, r.outcome, r.status, r.entry, r.sl, r.tp,
                                  round(risk, 4), round(risk * rr, 4), r.pmh, r.pml, hhmm(int(m[r.sweep_i])),
                                  "-".join(hhmm(int(m[j])) for j in r.fvg),
                                  hhmm(int(m[r.fill_i])) if r.fill_i >= 0 else "",
                                  hhmm(int(m[r.exit_i])) if r.exit_i >= 0 else "", model, rr,
                                  be_trigger is not None, be_trigger, r.be_activated, r.final_exit,
                                  rr if r.outcome == WIN else -1.0 if r.outcome == LOSE else 0.0,
                                  "TP" if r.outcome == WIN else "SL" if r.outcome == LOSE else "BE" if r.outcome == BREAKEVEN else r.outcome,
                                  instrument)
                        out.trades.append(t)
                        note = r.outcome
                        if keep_bars:
                            out.bars[ds] = (b, r)
                    elif r.sweep_i >= 0:
                        note = f"sweep {r.direction or 'both sides'} at {hhmm(int(b['minutes'][r.sweep_i]))}"
                    out.days.append(DayLog(ds, wd, con, r.status if r.status not in ("filled", "cancelled")
                                           else "Order placed", note))
        progress(i / total, f"{ds}: {len(out.trades)} orders so far")
        d += timedelta(days=1)
    out.summary = summarize(out.trades, out.days)
    return out


# ------------------------------------------------------------------------------------------
# CSV
# ------------------------------------------------------------------------------------------
TRADE_COLUMNS = ["Date", "Instrument", "Day of week", "Contract", "Direction", "Outcome", "Entry-to-SL points",
                 "Entry-to-TP points", "Entry", "Initial stop loss", "Original take profit", "PMH", "PML",
                 "Sweep time", "FVG candles", "Fill time", "Exit time", "Model", "Original RR",
                 "BE enabled", "BE trigger R", "BE activated", "Final exit price", "Final R", "Exit reason", "Trade duration (minutes)"]


def _short_outcome(o: str) -> str:
    return {BOTH: "Both Hit"}.get(o, o)


def write_trades_csv(result: BacktestResult, path: str, include_cancelled: bool = False) -> str:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(TRADE_COLUMNS)
        for t in result.trades:
            if t.status != "filled" and not include_cancelled:
                continue
            duration = ""
            if t.fill_time and t.exit_time:
                try:
                    fh, fm = (int(x) for x in t.fill_time.split(":")); eh, em = (int(x) for x in t.exit_time.split(":"))
                    duration = max(0, (eh * 60 + em) - (fh * 60 + fm))
                except (ValueError, AttributeError):
                    duration = ""
            w.writerow([t.date, result.instrument, t.weekday, t.contract, t.direction, _short_outcome(t.outcome),
                        f"{t.risk_pts:.2f}", f"{t.reward_pts:.2f}", f"{t.entry:.2f}", f"{t.sl:.2f}",
                        f"{t.tp:.2f}", f"{t.pmh:.2f}", f"{t.pml:.2f}", t.sweep_time, t.fvg_times,
                        t.fill_time, t.exit_time, t.model, t.rr, t.be_enabled, t.be_trigger,
                        t.be_activated, t.final_exit, t.final_r, t.exit_reason, duration])
    return path


def write_day_log_csv(result: BacktestResult, path: str) -> str:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Date", "Day of week", "Contract used", "Status", "Note"])
        for d in result.days:
            w.writerow([d.date, d.weekday, d.contract, d.status, d.note])
    return path


def summary_lines(s: dict) -> list[tuple[str, str]]:
    wr = f"{s['win_rate'] * 100:.1f}%" if s["win_rate"] is not None else "–"
    dash = lambda v: str(v) if v else "–"  # noqa: E731
    return [
        ("Limit orders", str(s["orders"])), ("Filled", str(s["filled"])),
        ("Not filled / cancelled", str(s["cancelled"])),
        ("   TP reached before fill", str(s["cancelled_tp"])),
        ("   Not filled by 11:00", str(s["cancelled_time"])),
        ("Take profits", str(s["wins"])), ("Stop losses", str(s["losses"])),
        ("Breakeven exits", str(s.get("breakeven", 0))), ("BE activated", str(s.get("be_activated", 0))),
        ("Both Hit (same candle)", str(s["both_hit"])), ("Open at 11:00", str(s["open_1100"])),
        ("Win rate (TP / (TP+SL))", wr),
        ("Longest / shortest win streak", f"{dash(s['longest_win'])} / {dash(s['shortest_win'])}"),
        ("Longest / shortest loss streak", f"{dash(s['longest_loss'])} / {dash(s['shortest_loss'])}"),
        ("Ambiguous days", str(s["ambiguous"])), ("Days with no sweep", str(s["no_sweep"])),
        ("Days with no FVG", str(s["no_fvg"])), ("Zero-risk orders skipped", str(s["invalid"])),
        ("Days without data", str(s["no_data"])), ("Holidays skipped", str(s["holidays"])),
    ]


RULES_TEXT = """[b]Times are New York time. Candles are stamped with their opening minute.[/b]

[b]1. Pre-market range.[/b] PMH = highest high and PML = lowest low of the candles 07:00 to 09:29.

[b]2. First sweep from 09:30.[/b] The first candle that trades above PMH (high > PMH) means look SHORT. The first that trades below PML (low < PML) means look LONG. Only the first sweep counts.

[b]3. Ambiguous.[/b] If one candle takes both PMH and PML, the day is skipped.

[b]4. First FVG in the trade direction[/b] (3 candles): bullish if candle 3 low > candle 1 high (long), bearish if candle 3 high < candle 1 low (short). The sweep candle can be candle 1, 2 or 3; an FVG that finished before the sweep never counts. Confirmed when candle 3 closes.

[b]5. Limit order[/b] from the candle after candle 3 (max one per day).
  Model 1: entry = open of candle 3.
  Model 2: entry = low of candle 3 (long) / high of candle 3 (short).
  Stop loss = low of candle 2 (long) / high of candle 2 (short).
  Take profit = entry ± RR × (distance from entry to stop loss).

[b]6. Cancelled[/b] if price reaches the take profit before the order fills, or if it is not filled by 11:00 (last candle 10:59).

[b]7. Fill:[/b] long when a candle's low reaches the entry, short when a candle's high reaches it. In the fill candle the fill comes first, then stop loss / take profit are checked in that same candle.

[b]8. Result:[/b] only stop loss touched = Lose. Only take profit touched = Win. Both in the same 1-minute candle = Both Hit (not a win or a loss). Neither by 11:00 = Open at 11:00 (not a win or a loss).

[b]Contract:[/b] each day uses one contract: the one with the most volume 07:00–11:00. Calendar spreads are ignored.

[b]Skipped days:[/b] weekends, US market holidays (setting), days without data, and orders where entry equals the stop loss.

[b]Win rate[/b] = take profits / (take profits + stop losses). Streaks count only Win and Lose trades in date order; Both Hit and Open at 11:00 are skipped."""
