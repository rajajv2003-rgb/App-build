"""Kivy app: home -> import -> progress -> gallery -> viewer.

Layout adapts: one column on phones / portrait, two columns on a landscape tablet.
"""

from __future__ import annotations

import os
import threading
import traceback
from datetime import date, timedelta

from kivy.app import App
from kivy.clock import Clock, mainthread
from kivy.core.window import Window
from kivy.lang import Builder
from kivy.metrics import dp, sp
from kivy.properties import BooleanProperty, ColorProperty, ListProperty, NumericProperty, StringProperty
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.factory import Factory
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import Screen, ScreenManager, SlideTransition
from kivy.uix.widget import Widget

from .. import __version__
from ..calendar_us import holiday_name
from ..config import COMMON_TIMEZONES, INSTRUMENTS, AppSettings, CsvFormat
from ..data_loader import (BarStore, BuildInput, CacheBuilder, Cancelled, Source, describe_error, load_meta,
                           peek_range, read_head, sniff, test_parse)
from ..generator import (MAX_DAYS_WITHOUT_CONFIRM, GenerateRequest, count_days, list_runs,
                         plan_days, run_generation)
from ..timeparse import ny_epoch, parse_hhmm
from ..platform_io import app_storage_dir, is_android
from ..timeparse import CANDIDATE_FORMATS
from .widgets import (MONO, C, Card, DatePickerSheet, DayHeatmap, GhostButton, PrimaryButton,  # noqa: F401
                      Sheet, StatTile, TimePickerSheet, ZoomView, message)

ANDROID = is_android()
DELIMS = {",": ",", ";": ";", "Tab": "\t", "|": "|", "Space": " "}
DELIM_NAMES = {v: k for k, v in DELIMS.items()}
NONE = "(none)"


def nice_date(iso: str) -> str:
    try:
        d = date.fromisoformat(iso)
    except ValueError:
        return iso
    return f"{d.strftime('%b')} {d.day}, {d.year}"


def short_date(d: date) -> str:
    return f"{d.strftime('%b')} {d.day}, {d.year}"


KV = r"""
#:import C stratradegy.ui.widgets.C
#:import dp kivy.metrics.dp

<AppBar@BoxLayout>:
    size_hint_y: None
    height: dp(52)
    padding: dp(12), dp(8)
    spacing: dp(12)
    canvas.before:
        Color:
            rgba: C.bg
        Rectangle:
            pos: self.pos
            size: self.size
        Color:
            rgba: C.border
        Line:
            points: [self.x, self.y, self.right, self.y]

<Title@Label>:
    font_name: MONO
    font_size: sp(13)
    bold: True
    color: C.text
    size_hint_x: None
    width: self.texture_size[0]

<Muted@Label>:
    font_name: MONO
    color: C.muted
    font_size: sp(13)
    size_hint_y: None
    height: dp(20)
    text_size: self.width, None
    halign: "left"
    shorten: True
    shorten_from: "right"
    markup: True

<PillButton>:
    color: C.text
    font_size: sp(14)
    size_hint: None, None
    height: dp(36)
    width: self.texture_size[0] + dp(28)
    canvas.before:
        Color:
            rgba: C.surface3 if self.state == "down" else C.surface2
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [self.height / 2]
        Color:
            rgba: C.border
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, self.height / 2)

<Dot>:
    size_hint: None, None
    size: dp(10), dp(10)
    canvas:
        Color:
            rgba: self.tint
        Ellipse:
            pos: self.pos
            size: self.size

<ProgressTrack@Widget>:
    value: 0
    size_hint_y: None
    height: dp(10)
    canvas:
        Color:
            rgba: C.surface3
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(5)]
        Color:
            rgba: C.accent
        RoundedRectangle:
            pos: self.pos
            size: max(self.height, self.width * self.value), self.height
            radius: [dp(5)]

<FormRow@BoxLayout>:
    label: ""
    size_hint_y: None
    height: dp(48)
    spacing: dp(12)
    Label:
        text: root.label
        size_hint_x: 0.42
        text_size: self.size
        halign: "left"
        valign: "middle"
        font_size: sp(14)
        color: C.muted

<CardButton>:
    canvas.before:
        Color:
            rgba: C.surface3 if self.state == "down" else C.clear
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(18)]

<ThumbCell>:
    orientation: "vertical"
    padding: dp(8)
    spacing: dp(6)
    canvas.before:
        Color:
            rgba: C.surface3 if self.state == "down" else C.surface
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(6)]
        Color:
            rgba: C.border
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(6))
    AsyncImage:
        source: root.thumb
        fit_mode: "contain"
        nocache: True
    BoxLayout:
        size_hint_y: None
        height: dp(26)
        padding: dp(4), 0
        Label:
            text: root.label
            markup: True
            font_name: MONO
            font_size: sp(12)
            color: C.text
            text_size: self.size
            halign: "left"
            valign: "middle"
        Label:
            text: root.contract
            font_size: sp(12)
            bold: True
            color: C.muted
            size_hint_x: None
            width: self.texture_size[0] + dp(16) if self.text else 0
            canvas.before:
                Color:
                    rgba: C.surface2 if self.text else C.clear
                RoundedRectangle:
                    pos: self.x, self.center_y - dp(11)
                    size: self.width, dp(22)
                    radius: [dp(11)]

<PresetChip>:
    color: C.accent if self.selected else C.text
    font_size: sp(13)
    size_hint: None, None
    height: dp(34)
    width: self.texture_size[0] + dp(24)
    canvas.before:
        Color:
            rgba: C.accent_soft if self.selected else (C.hover if self.state == "down" else C.raised)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(17)]
        Color:
            rgba: C.accent if self.selected else C.line2
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(17))

<Help@Label>:
    font_size: sp(14)
    color: C.muted
    markup: True
    size_hint_y: None
    text_size: self.width, None
    height: self.texture_size[1]
    halign: "left"

<Num@Label>:
    font_name: MONO
    font_size: sp(12)
    color: C.muted
    markup: True
    size_hint_y: None
    height: dp(18)
    text_size: self.width, None
    halign: "left"
    shorten: True
    shorten_from: "right"

<StepCard>:
    orientation: "vertical"
    size_hint_y: None
    height: self.minimum_height
    padding: dp(18), dp(16), dp(18), dp(18)
    spacing: dp(10)
    canvas.before:
        Color:
            rgba: C.panel
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]
        Color:
            rgba: C.line
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(10))
    BoxLayout:
        size_hint_y: None
        height: dp(28)
        spacing: dp(10)
        Label:
            text: "✓" if root.done else root.num
            font_name: MONO
            bold: True
            font_size: sp(13)
            color: C.accent_ink if (root.done or root.active) else C.text
            size_hint: None, None
            size: (dp(26), dp(26)) if (root.num or root.done) else (0, dp(26))
            opacity: 1 if (root.num or root.done) else 0
            pos_hint: {"center_y": .5}
            canvas.before:
                Color:
                    rgba: C.up if root.done else (C.accent if root.active else C.hover)
                Ellipse:
                    pos: self.pos
                    size: self.size
        Label:
            text: root.title
            font_size: sp(17)
            bold: True
            color: C.text
            text_size: self.size
            halign: "left"
            valign: "middle"
    Help:
        text: root.help
        opacity: 1 if root.help else 0
        height: self.texture_size[1] if root.help else 0

<BigField>:
    orientation: "vertical"
    size_hint_y: None
    height: dp(62)
    padding: dp(14), dp(8)
    canvas.before:
        Color:
            rgba: C.hover if self.state == "down" else C.raised
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(8)]
        Color:
            rgba: C.line2
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(8))
    Label:
        text: root.caption
        font_size: sp(12)
        color: C.muted
        text_size: self.size
        halign: "left"
        valign: "bottom"
    BoxLayout:
        Label:
            text: root.value
            font_size: sp(17)
            bold: True
            color: C.text
            markup: True
            text_size: self.size
            halign: "left"
            valign: "middle"
            shorten: True
        Label:
            text: "▾"
            font_name: MONO
            font_size: sp(14)
            color: C.accent
            size_hint_x: None
            width: dp(14)

<MarketTile>:
    orientation: "vertical"
    size_hint_y: None
    height: dp(84)
    padding: dp(14), dp(10)
    opacity: 1 if self.available else .45
    canvas.before:
        Color:
            rgba: C.accent_soft if self.selected else (C.hover if self.state == "down" else C.raised)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(8)]
        Color:
            rgba: C.accent if self.selected else C.line2
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(8))
            width: dp(1.4) if self.selected else dp(1)
    Label:
        text: root.code
        font_name: MONO
        bold: True
        font_size: sp(22)
        color: C.accent if root.selected else C.text
        text_size: self.size
        halign: "left"
        valign: "middle"
    Label:
        text: root.name
        font_size: sp(13)
        color: C.text
        size_hint_y: None
        height: dp(18)
        text_size: self.size
        halign: "left"
    Label:
        text: root.info
        font_size: sp(12)
        color: C.muted
        size_hint_y: None
        height: dp(16)
        text_size: self.size
        halign: "left"
        shorten: True

<Steps@BoxLayout>:
    orientation: "vertical"
    size_hint_y: None
    height: self.minimum_height
    padding: dp(14), dp(14), dp(14), dp(20)
    spacing: dp(14)

    StepCard:
        num: "1"
        title: "Your data" if app.data_state == "ready" else "Add your data files"
        help: "" if app.data_state == "ready" else "Add one or more 1-minute CSV files with NQ and/or ES prices. You can mix files (for example one per year). Everything stays on this device."
        done: app.data_state == "ready"
        active: app.data_state != "ready"
        Help:
            text: app.data_status
            font_size: sp(14)
        TextButton:
            text: "Hide files" if app.show_files else "Manage files"
            font_size: sp(14)
            height: dp(36) if app.data_state == "ready" else 0
            opacity: 1 if app.data_state == "ready" else 0
            disabled: app.data_state != "ready"
            on_release: app.show_files = not app.show_files
        LibraryList:
            size_hint_y: None
            opacity: 1 if (app.show_files or app.data_state != "ready") else 0
            disabled: not (app.show_files or app.data_state != "ready")
            height: self.minimum_height if (app.show_files or app.data_state != "ready") else 0
        BoxLayout:
            size_hint_y: None
            height: dp(46) if (app.show_files or app.data_state != "ready") else 0
            opacity: 1 if (app.show_files or app.data_state != "ready") else 0
            disabled: not (app.show_files or app.data_state != "ready")
            spacing: dp(10)
            PrimaryButton:
                text: "+  Add CSV files"
                height: dp(46)
                font_size: sp(15)
                bg: C.accent if app.data_state == "empty" else C.raised
                bg_down: C.accent_down if app.data_state == "empty" else C.hover
                fg: C.accent_ink if app.data_state == "empty" else C.text
                outline: C.clear if app.data_state == "empty" else C.line2
                on_release: app.pick_csv()
            PrimaryButton:
                text: "Prepare data"
                height: dp(46)
                font_size: sp(15)
                opacity: 1 if app.data_state == "dirty" else 0
                disabled: app.data_state != "dirty"
                size_hint_x: 1 if app.data_state == "dirty" else 0.001
                on_release: app.prepare_data()
        Help:
            text: app.data_warning
            color: C.accent
            opacity: 1 if app.data_warning else 0
            height: self.texture_size[1] if app.data_warning else 0

    StepCard:
        num: "2"
        title: "Choose the market"
        done: app.has_data
        GridLayout:
            cols: 2
            spacing: dp(10)
            size_hint_y: None
            height: dp(84)
            MarketTile:
                code: "NQ"
                name: "Nasdaq-100 futures"
                info: app.nq_info
                available: bool(app.nq_info) and not app.nq_info.startswith("no")
                selected: app.instrument == "NQ"
                on_release: app.set_instrument("NQ")
            MarketTile:
                code: "ES"
                name: "S&P 500 futures"
                info: app.es_info
                available: bool(app.es_info) and not app.es_info.startswith("no")
                selected: app.instrument == "ES"
                on_release: app.set_instrument("ES")

    StepCard:
        num: "3"
        title: "Choose the days"
        help: "One chart is made for every trading day in this range. Weekends and US market holidays are skipped for you."
        done: app.has_data
        GridLayout:
            cols: 2 if self.width > dp(330) else 1
            spacing: dp(10)
            size_hint_y: None
            height: self.minimum_height
            row_default_height: dp(62)
            row_force_default: True
            BigField:
                caption: "Start date"
                value: app.start_label
                on_release: app.pick_date("start")
            BigField:
                caption: "End date"
                value: app.end_label
                on_release: app.pick_date("end")
        StackLayout:
            size_hint_y: None
            height: self.minimum_height
            spacing: dp(8)
            PresetChip:
                text: "Last week"
                selected: app.range_preset == "1W"
                on_release: app.quick_range(7)
            PresetChip:
                text: "Last month"
                selected: app.range_preset == "1M"
                on_release: app.quick_range(31)
            PresetChip:
                text: "Last 3 months"
                selected: app.range_preset == "3M"
                on_release: app.quick_range(92)
            PresetChip:
                text: "This year"
                selected: app.range_preset == "YTD"
                on_release: app.quick_range("ytd")
            PresetChip:
                text: "All data"
                selected: app.range_preset == "ALL"
                on_release: app.quick_range("all")

    StepCard:
        num: "4"
        title: "Choose the time of day"
        help: "In New York time. The default 7:00 to 11:00 shows the morning before and after the 9:30 stock-market open. Dashed lines mark 7:00, 8:00, 9:00 and 9:30."
        done: app.has_data and app.start_min < app.end_min
        GridLayout:
            cols: 2
            spacing: dp(10)
            size_hint_y: None
            height: dp(62)
            BigField:
                caption: "From"
                value: app.start_time
                on_release: app.pick_time("start")
            BigField:
                caption: "To"
                value: app.end_time
                on_release: app.pick_time("end")
        WindowStrip:
            start_min: app.start_min
            end_min: app.end_min
            height: dp(40)
        TextButton:
            text: "Use the default 7:00 to 11:00"
            font_name: "Roboto"
            font_size: sp(13)
            opacity: 0 if (app.start_time == "07:00" and app.end_time == "11:00") else 1
            disabled: app.start_time == "07:00" and app.end_time == "11:00"
            height: dp(32) if not self.disabled else 0
            on_release: app.reset_window()

    StepCard:
        num: "5"
        title: "Make the charts"
        active: app.can_render
        Help:
            text: app.make_text
            color: C.text
            font_size: sp(14)
        PrimaryButton:
            text: app.generate_label
            disabled: not app.can_render
            on_release: app.generate()
        TextButton:
            text: ("Hide options" if app.show_options else "More options (colors, picture size, holidays)")
            font_name: "Roboto"
            font_size: sp(13)
            on_release: app.show_options = not app.show_options
        BoxLayout:
            orientation: "vertical"
            size_hint_y: None
            height: self.minimum_height if app.show_options else 0
            opacity: 1 if app.show_options else 0
            disabled: not app.show_options
            spacing: dp(10)
            Help:
                text: "Chart colors"
                color: C.text
            Segmented:
                SegButton:
                    text: "Dark background"
                    font_name: "Roboto"
                    group: "theme"
                    state: "down" if app.theme == "dark" else "normal"
                    on_release: app.set_setting("theme", "dark")
                SegButton:
                    text: "Light background"
                    font_name: "Roboto"
                    group: "theme"
                    state: "down" if app.theme == "light" else "normal"
                    on_release: app.set_setting("theme", "light")
            Help:
                text: "Picture size"
                color: C.text
            Segmented:
                SegButton:
                    text: "Standard (1080p)"
                    font_name: "Roboto"
                    group: "res"
                    state: "down" if app.resolution == "1920x1080" else "normal"
                    on_release: app.set_setting("resolution", "1920x1080")
                SegButton:
                    text: "Sharp (1440p)"
                    font_name: "Roboto"
                    group: "res"
                    state: "down" if app.resolution == "2560x1440" else "normal"
                    on_release: app.set_setting("resolution", "2560x1440")
                SegButton:
                    text: "Very sharp (4K)"
                    font_name: "Roboto"
                    group: "res"
                    state: "down" if app.resolution == "3840x2160" else "normal"
                    on_release: app.set_setting("resolution", "3840x2160")
            BoxLayout:
                size_hint_y: None
                height: dp(44)
                spacing: dp(10)
                Help:
                    text: "Skip US market holidays\n[size=12sp][color=8e9096]Futures trade on some holidays (e.g. MLK Day) but the stock market is closed.[/color][/size]"
                    color: C.text
                    pos_hint: {"center_y": .5}
                PillSwitch:
                    active: app.skip_holidays
                    pos_hint: {"center_y": .5}
                    on_active: app.set_setting("skip_holidays", self.active)

<Insight@BoxLayout>:
    orientation: "vertical"
    size_hint_y: None
    height: self.minimum_height
    padding: dp(14), dp(14), dp(14), dp(20)
    spacing: dp(14)

    StepCard:
        title: "Preview"
        help: app.preview_help
        RelativeLayout:
            size_hint_y: None
            height: self.width * 9 / 16
            canvas.before:
                Color:
                    rgba: C.bg
                Rectangle:
                    pos: 0, 0
                    size: self.size
            Image:
                source: app.preview_src
                fit_mode: "contain"
                nocache: True
                opacity: 1 if app.preview_src else 0
            Label:
                text: app.preview_note
                font_size: sp(14)
                color: C.faint
                opacity: 0 if app.preview_src else 1
        Help:
            text: "[b]Your days at a glance.[/b] Each square is one trading day: [color=22c55e]green[/color] = price went up during your time window, [color=ef4444]red[/color] = down, [color=f2a93b]outlined[/color] = market holiday, grey = no data. Brighter = bigger move. Tap a square to preview that day."
        ScrollView:
            id: hm_scroll
            do_scroll_y: False
            size_hint_y: None
            height: hm.height
            bar_width: dp(2)
            DayHeatmap:
                id: hm
                days: app.plan_days
                selected: app.selected_day
                avail_width: hm_scroll.width
                select_cb: app.select_day
        Help:
            text: app.plan_caption
            font_size: sp(13)

    StepCard:
        title: "Explain this day"
        help: "What happened on the selected day, worked out from your data."
        Label:
            text: app.facts_headline
            font_size: sp(15)
            bold: True
            color: C.text
            size_hint_y: None
            text_size: self.width, None
            height: self.texture_size[1]
            halign: "left"
        TextButton:
            text: "Hide details" if app.show_facts else "Show all details"
            font_name: "Roboto"
            font_size: sp(13)
            on_release: app.show_facts = not app.show_facts
        Body:
            text: app.facts_text if app.show_facts else ""
            color: C.muted
            height: self.texture_size[1] if app.show_facts else 0

        Widget:
            size_hint_y: None
            height: dp(1)
            canvas:
                Color:
                    rgba: C.line
                Rectangle:
                    pos: self.pos
                    size: self.size
        Label:
            text: "Ask the AI  [size=12sp][color=8e9096]runs offline on this device[/color][/size]"
            markup: True
            font_size: sp(15)
            bold: True
            color: C.text
            size_hint_y: None
            height: dp(24)
            text_size: self.size
            halign: "left"
            valign: "middle"

        BoxLayout:
            orientation: "vertical"
            size_hint_y: None
            height: self.minimum_height if not app.ai_ready else 0
            opacity: 1 if not app.ai_ready else 0
            disabled: app.ai_ready
            spacing: dp(8)
            Help:
                text: "To ask questions in your own words, download the AI model once. Use Wi-Fi. After that it works without internet."
            PrimaryButton:
                text: "Download AI model  (491 MB)"
                font_size: sp(16)
                height: dp(54)
                on_release: app.download_ai("qwen2.5-0.5b")
            GhostButton:
                text: "Better answers instead  (1.1 GB, slower)"
                font_size: sp(14)
                height: dp(46)
                on_release: app.download_ai("qwen2.5-1.5b")
            TextButton:
                text: "I already have a .gguf model file"
                font_name: "Roboto"
                font_size: sp(13)
                on_release: app.choose_ai_file()

        BoxLayout:
            orientation: "vertical"
            size_hint_y: None
            height: self.minimum_height if app.ai_ready else 0
            opacity: 1 if app.ai_ready else 0
            disabled: not app.ai_ready
            spacing: dp(8)
            StackLayout:
                size_hint_y: None
                height: self.minimum_height
                spacing: dp(6)
                PresetChip:
                    text: "Summarize this day"
                    on_release: app.ask_ai(self.text)
                PresetChip:
                    text: "What happened at 9:30?"
                    on_release: app.ask_ai(self.text)
                PresetChip:
                    text: "Trend day or choppy?"
                    on_release: app.ask_ai(self.text)
                PresetChip:
                    text: "What is the opening range?"
                    on_release: app.ask_ai(self.text)
            BoxLayout:
                size_hint_y: None
                height: dp(44)
                spacing: dp(8)
                DInput:
                    id: q
                    hint_text: "Ask anything about this day…"
                    font_name: "Roboto"
                    on_text_validate: app.ask_ai(self.text); self.text = ""
                PrimaryButton:
                    text: "Ask"
                    size_hint_x: None
                    width: dp(76)
                    height: dp(44)
                    on_release: app.ask_ai(q.text); q.text = ""
        Label:
            text: app.ai_answer
            font_size: sp(14)
            color: C.text
            markup: True
            size_hint_y: None
            text_size: self.width, None
            height: self.texture_size[1] if app.ai_answer else 0
            halign: "left"
            canvas.before:
                Color:
                    rgba: C.raised if app.ai_answer else C.clear
                RoundedRectangle:
                    pos: self.x - dp(10), self.y - dp(8)
                    size: self.width + dp(20), self.height + dp(16)
                    radius: [dp(8)]
        Help:
            text: app.ai_note
            font_size: sp(12)

<HomeTopBar@BoxLayout>:
    size_hint_y: None
    height: dp(56)
    padding: dp(14), dp(8)
    spacing: dp(12)
    canvas.before:
        Color:
            rgba: C.bg
        Rectangle:
            pos: self.pos
            size: self.size
        Color:
            rgba: C.line
        Rectangle:
            pos: self.pos
            size: self.width, 1
    Logo:
        pos_hint: {"center_y": .5}
    Label:
        text: "StraTradegy"
        font_size: sp(18)
        bold: True
        color: C.text
        size_hint_x: None
        width: self.texture_size[0] if root.width > dp(430) else 0
        opacity: 1 if root.width > dp(430) else 0
    Widget:
    GhostButton:
        text: "?"
        size_hint_x: None
        width: dp(38)
        height: dp(38)
        pos_hint: {"center_y": .5}
        on_release: app.show_help()
    GhostButton:
        text: "Backtest"
        size_hint_x: None
        width: dp(92)
        height: dp(38)
        pos_hint: {"center_y": .5}
        on_release: app.go("backtest")
    GhostButton:
        text: "My charts"
        font_name: "Roboto"
        size_hint_x: None
        width: dp(104)
        height: dp(38)
        pos_hint: {"center_y": .5}
        on_release: app.open_gallery()

<HomeScreen>:
    canvas.before:
        Color:
            rgba: C.bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: "vertical"
        HomeTopBar:
        BoxLayout:
            id: body

<WelcomeScreen>:
    canvas.before:
        Color:
            rgba: C.bg
        Rectangle:
            pos: self.pos
            size: self.size
    ScrollView:
        do_scroll_x: False
        BoxLayout:
            orientation: "vertical"
            size_hint_y: None
            height: max(self.minimum_height, root.height)
            padding: max(dp(22), (self.width - dp(560)) / 2), dp(36), max(dp(22), (self.width - dp(560)) / 2), dp(28)
            spacing: dp(18)
            Widget:
                size_hint_y: 0.3
            Logo:
                size: dp(44), dp(44)
            Label:
                text: "StraTradegy"
                font_size: sp(30)
                bold: True
                color: C.text
                size_hint_y: None
                height: dp(40)
                text_size: self.size
                halign: "left"
            Label:
                text: "Turn your NQ and ES 1-minute price files into one clear chart picture for every trading day."
                font_size: sp(18)
                color: C.text
                size_hint_y: None
                text_size: self.width, None
                height: self.texture_size[1]
                halign: "left"
            WelcomeStep:
                num: "1"
                text: "Pick your CSV file(s) on this phone, for example from Downloads."
            WelcomeStep:
                num: "2"
                text: "Choose the days and the time of day (7:00 to 11:00 New York time by default)."
            WelcomeStep:
                num: "3"
                text: "Get one chart per day in your gallery, and ask the built-in AI what happened that day."
            Widget:
                size_hint_y: None
                height: dp(6)
            PrimaryButton:
                text: "Choose my CSV file"
                height: dp(58)
                font_size: sp(17)
                on_release: app.pick_csv()
            GhostButton:
                text: "Try it first with demo data"
                height: dp(52)
                font_size: sp(16)
                on_release: app.start_demo()
            Label:
                text: "Your files stay on this phone. A big file (1 to 2 GB) takes a minute or two to read the first time; after that everything is instant."
                font_size: sp(14)
                color: C.muted
                size_hint_y: None
                text_size: self.width, None
                height: self.texture_size[1]
                halign: "left"
            Widget:

<WelcomeStep@BoxLayout>:
    num: ""
    text: ""
    size_hint_y: None
    height: max(dp(36), lbl.texture_size[1])
    spacing: dp(14)
    Label:
        text: root.num
        font_name: MONO
        bold: True
        font_size: sp(15)
        color: C.accent_ink
        size_hint: None, None
        size: dp(32), dp(32)
        pos_hint: {"top": 1}
        canvas.before:
            Color:
                rgba: C.accent
            Ellipse:
                pos: self.pos
                size: self.size
    Label:
        id: lbl
        text: root.text
        font_size: sp(16)
        color: C.text
        text_size: self.width, None
        halign: "left"
        valign: "top"

<ImportScreen>:
    canvas.before:
        Color:
            rgba: C.bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: "vertical"
        AppBar:
            GhostButton:
                text: "‹  Back"
                size_hint_x: None
                width: dp(100)
                height: dp(42)
                pos_hint: {"center_y": .5}
                on_release: app.go("home")
            Title:
                text: "FILE FORMAT"
            Widget:
        ScrollView:
            do_scroll_x: False
            bar_width: dp(4)
            BoxLayout:
                orientation: "vertical"
                size_hint_y: None
                height: self.minimum_height
                padding: max(dp(16), (self.width - dp(960)) / 2), dp(16), max(dp(16), (self.width - dp(960)) / 2), dp(28)
                spacing: dp(16)
                Card:
                    Caption:
                        text: "FILE"
                    Label:
                        text: root.file_title
                        font_size: sp(17)
                        bold: True
                        color: C.text
                        size_hint_y: None
                        height: dp(26)
                        text_size: self.size
                        halign: "left"
                        shorten: True
                        shorten_from: "center"
                    Muted:
                        text: root.file_sub
                Card:
                    Caption:
                        text: "DETECTED"
                    BoxLayout:
                        id: detected
                        orientation: "vertical"
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(8)
                    Body:
                        text: root.notes_text
                        color: C.muted
                        font_size: sp(13)
                Card:
                    Caption:
                        text: "PREVIEW  ·  CONVERTED TO NEW YORK TIME"
                    GridLayout:
                        id: table
                        cols: 6
                        size_hint_y: None
                        height: self.minimum_height
                        row_default_height: dp(30)
                        row_force_default: True
                    Body:
                        text: root.test_text
                        font_size: sp(13)
                        color: C.muted
                Card:
                    BoxLayout:
                        size_hint_y: None
                        height: dp(36)
                        Caption:
                            text: "ADVANCED COLUMN MAPPING"
                            pos_hint: {"center_y": .5}
                        TextButton:
                            text: "Hide" if root.show_adv else "Edit"
                            height: dp(36)
                            on_release: root.show_adv = not root.show_adv
                    BoxLayout:
                        orientation: "vertical"
                        size_hint_y: None
                        height: self.minimum_height if root.show_adv else 0
                        opacity: 1 if root.show_adv else 0
                        disabled: not root.show_adv
                        spacing: dp(8)
                        FormRow:
                            label: "Delimiter"
                            DSpinner:
                                id: delim
                                values: [",", ";", "Tab", "|", "Space"]
                        FormRow:
                            label: "First row is a header"
                            AnchorLayout:
                                anchor_x: "left"
                                PillSwitch:
                                    id: header
                        FormRow:
                            label: "Timestamp / date column"
                            DSpinner:
                                id: ts_col
                                values: root.columns
                        FormRow:
                            label: "Separate time column"
                            DSpinner:
                                id: time_col
                                values: [root.none_label] + root.columns
                        FormRow:
                            label: "Timestamp format"
                            DInput:
                                id: ts_format
                            DSpinner:
                                text: "…"
                                size_hint_x: None
                                width: dp(52)
                                values: root.format_choices
                                on_text: (setattr(ts_format, "text", self.text), setattr(self, "text", "…")) if self.text != "…" else None
                        FormRow:
                            label: "Timestamps are in"
                            DInput:
                                id: tz
                            DSpinner:
                                text: "…"
                                size_hint_x: None
                                width: dp(52)
                                values: root.tz_choices
                                on_text: (setattr(tz, "text", self.text), setattr(self, "text", "…")) if self.text != "…" else None
                        FormRow:
                            label: "Bar time marks"
                            DSpinner:
                                id: bar_label
                                values: ["open", "close"]
                        FormRow:
                            label: "Open / High"
                            DSpinner:
                                id: open_col
                                values: root.columns
                            DSpinner:
                                id: high_col
                                values: root.columns
                        FormRow:
                            label: "Low / Close"
                            DSpinner:
                                id: low_col
                                values: root.columns
                            DSpinner:
                                id: close_col
                                values: root.columns
                        FormRow:
                            label: "Volume"
                            DSpinner:
                                id: volume_col
                                values: [root.none_label] + root.columns
                        FormRow:
                            label: "Contract / symbol"
                            DSpinner:
                                id: symbol_col
                                values: [root.none_label] + root.columns
                        GhostButton:
                            text: "Re-check preview"
                            on_release: root.run_test()
                PrimaryButton:
                    text: root.build_label
                    on_release: root.build_index()

<ProgressScreen>:
    canvas.before:
        Color:
            rgba: C.bg
        Rectangle:
            pos: self.pos
            size: self.size
    ScrollView:
        do_scroll_x: False
        BoxLayout:
            orientation: "vertical"
            size_hint_y: None
            height: max(self.minimum_height, root.height)
            padding: max(dp(20), (self.width - dp(820)) / 2), dp(28)
            spacing: dp(16)
            Label:
                text: root.title_text
                font_size: sp(22)
                bold: True
                color: C.text
                size_hint_y: None
                text_size: self.width, None
                height: self.texture_size[1]
                halign: "left"
            Label:
                text: root.subtitle
                font_size: sp(14)
                color: C.muted
                size_hint_y: None
                text_size: self.width, None
                height: self.texture_size[1]
                halign: "left"
            BoxLayout:
                size_hint_y: None
                height: dp(64) if not root.finished else 0
                opacity: 0 if root.finished else 1
                Label:
                    text: "{:.0f}%".format(root.fraction * 100)
                    font_name: MONO
                    font_size: sp(44)
                    bold: True
                    color: C.text
                    text_size: self.size
                    halign: "left"
                    valign: "middle"
            ProgressTrack:
                value: root.fraction
            Label:
                text: root.status_text if not root.finished else ""
                font_size: sp(14)
                color: C.muted
                size_hint_y: None
                text_size: self.width, None
                height: self.texture_size[1] if not root.finished else 0
                halign: "left"
            GridLayout:
                id: stats
                cols: 3
                spacing: dp(10)
                size_hint_y: None
                height: dp(84) if root.finished and self.children else 0
                opacity: 1 if root.finished else 0
            Label:
                text: root.summary_text if root.finished else ""
                markup: True
                font_size: sp(16)
                line_height: 1.3
                color: C.text
                size_hint_y: None
                text_size: self.width, None
                height: self.texture_size[1]
                halign: "left"
            Card:
                padding: dp(8)
                opacity: 1 if root.preview else 0
                height: self.minimum_height if root.preview else 0
                AsyncImage:
                    source: root.preview
                    fit_mode: "contain"
                    nocache: True
                    size_hint_y: None
                    height: self.width * 9 / 16
            Widget:
            PrimaryButton:
                text: root.continue_text or ("See my charts" if root.gallery_ready else "Continue")
                height: dp(56) if root.finished else 0
                opacity: 1 if root.finished else 0
                disabled: not root.finished
                on_release: app.go(root.continue_target) if root.continue_target else (app.open_gallery() if root.gallery_ready else app.go("home"))
            GhostButton:
                text: "Cancel" if not root.finished else "Back to the start screen"
                height: dp(52) if (not root.finished or root.gallery_ready) else 0
                opacity: 1 if (not root.finished or root.gallery_ready) else 0
                disabled: root.finished and not root.gallery_ready
                on_release: app.cancel_job() if not root.finished else app.go("home")

<GalleryScreen>:
    canvas.before:
        Color:
            rgba: C.bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: "vertical"
        AppBar:
            GhostButton:
                text: "‹  Back"
                size_hint_x: None
                width: dp(100)
                height: dp(42)
                pos_hint: {"center_y": .5}
                on_release: app.go("home")
            Title:
                text: "GALLERY" if root.width > dp(600) else ""
            Widget:
                size_hint_x: 1 if root.width > dp(600) else 0
            DSpinner:
                text: root.run_label
                values: root.run_labels
                size_hint_x: None if root.width > dp(600) else 1
                width: min(dp(380), root.width * 0.5)
                height: dp(44)
                pos_hint: {"center_y": .5}
                on_text: root.select_run_label(self.text)
        Muted:
            text: root.info_text
            height: dp(36)
            padding: dp(18), 0
            valign: "middle"
            text_size: self.size
        RecycleView:
            viewclass: "ThumbCell"
            data: root.cells
            bar_width: dp(4)
            RecycleGridLayout:
                cols: max(1, int((root.width - dp(24)) / dp(340)))
                default_size: None, ((root.width - dp(24)) / max(1, int((root.width - dp(24)) / dp(340))) - dp(28)) * 9 / 16 + dp(56)
                default_size_hint: 1, None
                size_hint_y: None
                height: self.minimum_height
                spacing: dp(12)
                padding: dp(12)

<ViewerScreen>:
    canvas.before:
        Color:
            rgba: 0, 0, 0, 1
        Rectangle:
            pos: self.pos
            size: self.size
    FloatLayout:
        ZoomView:
            id: zoom
            source: root.source
            size_hint: 1, None
            height: root.height - dp(128)
            y: dp(64)
        BoxLayout:
            size_hint: 1, None
            height: dp(64)
            pos_hint: {"top": 1}
            padding: dp(12), dp(10)
            spacing: dp(10)
            canvas.before:
                Color:
                    rgba: 0, 0, 0, .85
                Rectangle:
                    pos: self.pos
                    size: self.size
            GhostButton:
                text: "‹  Gallery"
                size_hint_x: None
                width: dp(116)
                height: dp(44)
                on_release: app.go("gallery")
            Label:
                text: root.title_text
                markup: True
                font_size: sp(16)
                bold: True
                color: C.text
            PrimaryButton:
                text: "Share"
                size_hint_x: None
                width: dp(100)
                height: dp(44)
                font_size: sp(15)
                radius: dp(14)
                on_release: root.share()
        BoxLayout:
            size_hint: 1, None
            height: dp(64)
            padding: dp(12), dp(10)
            spacing: dp(10)
            canvas.before:
                Color:
                    rgba: 0, 0, 0, .85
                Rectangle:
                    pos: self.pos
                    size: self.size
            GhostButton:
                text: "‹  Prev"
                size_hint_x: None
                width: dp(110)
                height: dp(44)
                on_release: root.step(-1)
            Label:
                text: root.counter_text
                color: C.muted
                font_size: sp(13)
            GhostButton:
                text: "Next  ›"
                size_hint_x: None
                width: dp(110)
                height: dp(44)
                on_release: root.step(1)
"""


# --------------------------------------------------------------------------- #
# small widgets
# --------------------------------------------------------------------------- #
class PillButton(ButtonBehavior, Label):
    pass


class Dot(Widget):
    tint = ColorProperty(C.up)


class CardButton(ButtonBehavior, Card):
    pass


class ThumbCell(ButtonBehavior, BoxLayout):
    thumb = StringProperty("")
    label = StringProperty("")
    contract = StringProperty("")
    index = NumericProperty(0)

    def on_release(self):
        App.get_running_app().open_viewer(self.index)


def _cell(text, color=None, bold=False, align="left", mono=True):
    lb = Label(text=text, color=color or C.text, bold=bold, font_size=sp(12), halign=align, valign="middle",
               font_name=MONO, shorten=True)
    lb.bind(size=lambda l, s: setattr(l, "text_size", s))
    return lb


# --------------------------------------------------------------------------- #
# screens
# --------------------------------------------------------------------------- #
class PresetChip(ButtonBehavior, Label):
    selected = BooleanProperty(False)


class StepCard(BoxLayout):
    num = StringProperty("")
    title = StringProperty("")
    help = StringProperty("")
    done = BooleanProperty(False)
    active = BooleanProperty(False)


class BigField(ButtonBehavior, BoxLayout):
    caption = StringProperty("")
    value = StringProperty("")


class MarketTile(ButtonBehavior, BoxLayout):
    code = StringProperty("")
    name = StringProperty("")
    info = StringProperty("")
    available = BooleanProperty(True)
    selected = BooleanProperty(False)


class LibraryList(BoxLayout):
    """The CSV files in the library, rebuilt whenever app.library_version changes."""

    def __init__(self, **kw):
        super().__init__(orientation="vertical", spacing=dp(8), **kw)
        self.bind(minimum_height=self.setter("height"))
        app = App.get_running_app()
        app.bind(library_version=lambda *_: self.rebuild())
        Clock.schedule_once(lambda dt: self.rebuild(), 0)

    def rebuild(self):
        from .widgets import PillSwitch, SegButton, Segmented, TextButton

        app = App.get_running_app()
        self.clear_widgets()
        for e in app.cfg.library:
            card = BoxLayout(orientation="vertical", size_hint_y=None, padding=(dp(12), dp(10)), spacing=dp(6))
            card.bind(minimum_height=card.setter("height"))
            with card.canvas.before:
                from kivy.graphics import Color, Line, RoundedRectangle

                Color(*C.raised)
                bg = RoundedRectangle(radius=[dp(8)])
                Color(*C.line2)
                ln = Line(width=1)

            def _upd(w, *_a, bg=bg, ln=ln):
                bg.pos, bg.size = w.pos, w.size
                ln.rounded_rectangle = (w.x + .5, w.y + .5, w.width - 1, w.height - 1, dp(8))

            card.bind(pos=_upd, size=_upd)
            top = BoxLayout(size_hint_y=None, height=dp(30), spacing=dp(10))
            sw = PillSwitch(active=e.get("enabled", True), pos_hint={"center_y": .5})
            sw.bind(active=lambda w, v, eid=e["id"]: app.lib_toggle(eid, v))
            top.add_widget(sw)
            name = Label(text=e["source"]["name"], font_size=sp(14), bold=True, color=C.text if e.get("enabled", True)
                         else C.faint, halign="left", valign="middle", shorten=True, shorten_from="center")
            name.bind(size=lambda l, sz: setattr(l, "text_size", sz))
            top.add_widget(name)
            card.add_widget(top)
            info = Label(text=app.lib_describe(e), font_name=MONO, font_size=sp(11), color=C.muted, markup=True,
                         size_hint_y=None, halign="left", valign="top")
            info.bind(width=lambda l, w: setattr(l, "text_size", (w, None)),
                      texture_size=lambda l, ts: setattr(l, "height", ts[1]))
            card.add_widget(info)
            acts = BoxLayout(size_hint_y=None, height=dp(30), spacing=dp(4))
            acts.add_widget(TextButton(text="Check format", height=dp(30), font_size=sp(13),
                                       on_release=lambda *_a, eid=e["id"]: app.lib_open_settings(eid)))
            acts.add_widget(TextButton(text="Remove", height=dp(30), font_size=sp(13), color=C.muted,
                                       on_release=lambda *_a, eid=e["id"]: app.lib_remove(eid)))
            acts.add_widget(Widget())
            card.add_widget(acts)
            if not e["format"].get("symbol_col"):
                row = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(10))
                lb = Label(text="This file contains:", font_size=sp(13), color=C.text, size_hint_x=None, width=dp(130),
                           halign="left", valign="middle")
                lb.bind(size=lambda l, sz: setattr(l, "text_size", sz))
                row.add_widget(lb)
                seg = Segmented(height=dp(36))
                for inst in INSTRUMENTS:
                    b = SegButton(text=inst, group=f"lib{e['id']}", state="down" if e.get("instrument") == inst else "normal")
                    b.bind(on_release=lambda *_a, eid=e["id"], i=inst: app.lib_set_instrument(eid, i))
                    seg.add_widget(b)
                row.add_widget(seg)
                card.add_widget(row)
            self.add_widget(card)


class HomeScreen(Screen):
    """Tablet landscape: steps on the left, preview + AI on the right.
    Phone / portrait: everything in one scrolling column."""

    _wide = None

    def on_pre_enter(self, *_):
        for w in self.walk():
            if isinstance(w, ScrollView) and w.do_scroll_y:
                w.scroll_y = 1

    def on_kv_post(self, *_):
        self.bind(width=self._relayout)
        Clock.schedule_once(self._relayout, 0)

    def _relayout(self, *_):
        wide = self.width > dp(900)
        if wide == self._wide:
            return
        self._wide = wide
        body = self.ids.body
        body.clear_widgets()
        if wide:
            body.orientation = "horizontal"
            left = ScrollView(do_scroll_x=False, bar_width=dp(3), size_hint_x=0.44)
            left.add_widget(Factory.Steps())
            right = ScrollView(do_scroll_x=False, bar_width=dp(3))
            right.add_widget(Factory.Insight())
            body.add_widget(left)
            body.add_widget(right)
        else:
            body.orientation = "vertical"
            sv = ScrollView(do_scroll_x=False, bar_width=dp(3))
            col = BoxLayout(orientation="vertical", size_hint_y=None)
            col.bind(minimum_height=col.setter("height"))
            col.add_widget(Factory.Steps())
            col.add_widget(Factory.Insight())
            sv.add_widget(col)
            body.add_widget(sv)


class WelcomeScreen(Screen):
    pass


class ImportScreen(Screen):
    columns = ListProperty([])
    file_title = StringProperty("")
    file_sub = StringProperty("")
    notes_text = StringProperty("")
    test_text = StringProperty("")
    build_label = StringProperty("Build index")
    show_adv = BooleanProperty(False)
    none_label = StringProperty(NONE)
    format_choices = ListProperty(["iso8601", "epoch_s", "epoch_ms"] + CANDIDATE_FORMATS)
    tz_choices = ListProperty(COMMON_TIMEZONES)
    sources = []

    def load(self, sources: list[Source], saved_fmt: CsvFormat | None):
        self.sources = sources
        self.show_adv = False
        total = sum(s.size for s in sources)
        self.file_title = sources[0].name if len(sources) == 1 else f"{len(sources)} files"
        self.file_sub = (f"{total / 1e9:.2f} GB" if total > 1e9 else f"{total / 1e6:,.0f} MB") + \
            ("  ·  " + ", ".join(s.name for s in sources[1:4]) if len(sources) > 1 else
             (f"  ·  {os.path.dirname(sources[0].path)}" if sources[0].path else ""))
        lines = read_head(sources[0], max_lines=8)
        fmt, header, _rows, notes = sniff(lines)
        sniffed = fmt
        if saved_fmt is not None:
            if fmt.source_tz != "UTC":
                fmt.source_tz = saved_fmt.source_tz
            fmt.bar_label = saved_fmt.bar_label
            if saved_fmt.ts_col in header and saved_fmt.delimiter == fmt.delimiter:
                fmt = saved_fmt
                if not fmt.symbol_col and sniffed.symbol_col:
                    fmt.symbol_col = sniffed.symbol_col
        self.columns = header
        self.notes_text = "\n".join(n for n in notes
                                    if not n.startswith(("Detected format", "Contract column", "ISO-8601")))
        self.set_fields(fmt)
        self.run_test()

    def set_fields(self, f: CsvFormat):
        ids = self.ids
        ids.delim.text = DELIM_NAMES.get(f.delimiter, f.delimiter)
        ids.header.active = f.has_header
        ids.ts_col.text = f.ts_col
        ids.time_col.text = f.time_col or NONE
        ids.ts_format.text = f.ts_format
        ids.tz.text = f.source_tz
        ids.bar_label.text = f.bar_label
        for k in ("open", "high", "low", "close"):
            ids[f"{k}_col"].text = getattr(f, f"{k}_col") or ""
        ids.volume_col.text = f.volume_col or NONE
        ids.symbol_col.text = f.symbol_col or NONE

    def get_fields(self) -> CsvFormat:
        ids = self.ids
        val = lambda w: "" if w.text in (NONE, "") else w.text.strip()  # noqa: E731
        return CsvFormat(
            delimiter=DELIMS.get(ids.delim.text, ids.delim.text), has_header=ids.header.active,
            ts_col=val(ids.ts_col), time_col=val(ids.time_col), ts_format=ids.ts_format.text.strip(),
            source_tz=ids.tz.text.strip(), bar_label=ids.bar_label.text,
            open_col=val(ids.open_col), high_col=val(ids.high_col), low_col=val(ids.low_col),
            close_col=val(ids.close_col), volume_col=val(ids.volume_col), symbol_col=val(ids.symbol_col))

    def _fill_detected(self, f: CsvFormat, contracts: set):
        g = self.ids.detected
        g.clear_widgets()
        ts_desc = {"iso8601": "ISO-8601", "epoch_s": "Unix seconds", "epoch_ms": "Unix milliseconds"}.get(
            f.ts_format, f.ts_format)
        rows = [
            ("Timestamps", f"{f.ts_col}{' + ' + f.time_col if f.time_col else ''}  ·  {ts_desc}"),
            ("Timezone", "UTC (stated in the timestamps)" if f.source_tz == "UTC" else f.source_tz),
            ("Prices", f"{f.open_col} / {f.high_col} / {f.low_col} / {f.close_col}"
                       + (f"  ·  volume: {f.volume_col}" if f.volume_col else "")),
        ]
        if f.symbol_col:
            roots = sorted({c[:2] for c in contracts if c}) or ["?"]
            rows.append(("Contracts", f"'{f.symbol_col}' column  ·  {' + '.join(roots)} in this file"))
            rows.append(("Rolls", "most-traded month per chart  ·  spreads ignored"))
        for k, v in rows:
            row = BoxLayout(size_hint_y=None, spacing=dp(12))
            key = Label(text=k, color=C.faint, font_name=MONO, font_size=sp(12), size_hint_x=None,
                        width=dp(104), halign="left", valign="top")
            key.bind(size=lambda l, sz: setattr(l, "text_size", sz))
            val = Label(text=v, color=C.text, font_name=MONO, font_size=sp(12), halign="left", valign="top")
            val.bind(width=lambda l, w: setattr(l, "text_size", (w, None)),
                     texture_size=lambda l, ts, r=row: setattr(r, "height", max(dp(20), ts[1])))
            row.add_widget(key)
            row.add_widget(val)
            g.add_widget(row)

    def run_test(self):
        t = self.ids.table
        t.clear_widgets()
        f = self.get_fields()
        self.build_label = "Save these settings"
        try:
            rows, bad, n = test_parse(self.sources[0], f, n=8)
        except Exception as exc:
            self.test_text = f"[color=ef4444]{describe_error(exc)}[/color]"
            self._fill_detected(f, set())
            self.show_adv = True
            return
        self._fill_detected(f, {r[5] for r in rows})
        if not rows:
            self.test_text = "[color=ef4444]No rows could be parsed with these settings - check the mapping.[/color]"
            self.show_adv = True
            return
        narrow = self.width < dp(640)  # phones: time, close, contract only
        t.cols_minimum = {0: dp(130)} if narrow else {0: dp(190)}
        heads = ("New York time", "Close", "Contract") if narrow else \
            ("New York time", "Open", "High", "Low", "Close", "Contract")
        t.cols = len(heads)
        for h in heads:
            t.add_widget(_cell(h, C.muted, bold=True, align="left" if h == "New York time" else "right", mono=False))
        for r in rows:
            ts, _, wd = r[0].partition(" (")
            t.add_widget(_cell(f"{wd.rstrip(')')} {ts[5:16] if narrow else ts[:16]}", C.text))
            for v in ((r[4],) if narrow else r[1:5]):
                t.add_widget(_cell(f"{v:,.2f}", C.text, align="right"))
            t.add_widget(_cell(r[5] or "-", C.muted, align="right"))
        self.test_text = (f"[color=f5a524]{bad} of {n} rows failed to parse.[/color]  " if bad else "") + \
            "Sanity check: CME futures reopen Sunday 18:00 New York time."

    def build_index(self):
        App.get_running_app().save_entry_format(self.get_fields())


class ProgressScreen(Screen):
    title_text = StringProperty("")
    subtitle = StringProperty("")
    status_text = StringProperty("")
    summary_text = StringProperty("")
    fraction = NumericProperty(0)
    finished = BooleanProperty(False)
    gallery_ready = BooleanProperty(False)
    preview = StringProperty("")
    continue_text = StringProperty("")
    continue_target = StringProperty("")

    def start(self, title, subtitle=""):
        self.continue_text, self.continue_target = "", ""
        self.title_text, self.subtitle = title, subtitle
        self.status_text, self.summary_text = "Starting…", ""
        self.fraction, self.finished, self.gallery_ready, self.preview = 0, False, False, ""
        self.ids.stats.clear_widgets()

    def set_stats(self, stats):
        g = self.ids.stats
        g.clear_widgets()
        g.cols = max(1, len(stats))
        for value, caption, tint in stats:
            g.add_widget(StatTile(value=value, caption=caption, tint=tint))


class GalleryScreen(Screen):
    cells = ListProperty([])
    run_labels = ListProperty([])
    run_label = StringProperty("")
    info_text = StringProperty("")
    runs = []
    current = None

    @staticmethod
    def _label(m):
        return f"{m['instrument']} {m['start']} → {m['end']} ({len(m['charts'])})"

    def refresh(self, select_dir=None):
        self.runs = list_runs(App.get_running_app().work_root)
        self.run_labels = [self._label(m) for m in self.runs]
        if not self.runs:
            self.run_label, self.cells, self.current = "No runs yet", [], None
            self.info_text = "Charts you generate show up here."
            return
        pick = next((m for m in self.runs if m["run_dir"] == select_dir), self.runs[0])
        self.show(pick)

    def select_run_label(self, text):
        for m in self.runs:
            if self._label(m) == text and m is not self.current:
                self.show(m)

    def show(self, m):
        self.current = m
        self.run_label = self._label(m)
        d = m["run_dir"]
        self.cells = [{"thumb": os.path.join(d, c["thumb"]),
                       "label": f"[b]{c['date']}[/b]  [color=8b94a8]{c['weekday']}[/color]",
                       "contract": c.get("contract", ""), "index": i}
                      for i, c in enumerate(m["charts"])]
        self.info_text = (f"{len(m['charts'])} charts  ·  {m['window'][0]}–{m['window'][1]} ET  ·  "
                          f"{m['public_dir']}")


class ViewerScreen(Screen):
    source = StringProperty("")
    title_text = StringProperty("")
    counter_text = StringProperty("")
    index = NumericProperty(0)
    run = None

    def on_kv_post(self, *_):
        self.ids.zoom.swipe_cb = self.step

    def show(self, run, index):
        self.run = run
        self.index = max(0, min(index, len(run["charts"]) - 1))
        c = run["charts"][self.index]
        self.source = os.path.join(run["run_dir"], c["file"])
        con = f"  [color=8b94a8]{c['contract']}[/color]" if c.get("contract") else ""
        self.title_text = f"{run['instrument']}  ·  {c['weekday']} {c['date']}{con}"
        self.counter_text = f"{self.index + 1} / {len(run['charts'])}   ·   pinch or double-tap to zoom"

    def step(self, delta):
        if self.run:
            self.show(self.run, (self.index + delta) % len(self.run["charts"]))

    def share(self):
        c = self.run["charts"][self.index]
        if ANDROID:
            from ..platform_io import android_io

            uri = c.get("uri")
            if not uri:
                req = GenerateRequest.from_strings(self.run["instrument"], self.run["start"], self.run["end"])
                uri = android_io.MediaStoreSink().publish(self.source, req, c["file"])
                c["uri"] = uri
            android_io.share_image(uri, f"{self.run['instrument']} {c['date']}")
        else:
            from ..platform_io.desktop_io import share_image

            share_image(c.get("uri") or self.source)


# --------------------------------------------------------------------------- #
# app
# --------------------------------------------------------------------------- #
class StraTradegyApp(App):
    title = "StraTradegy"
    version = StringProperty(__version__)
    instrument = StringProperty("NQ")
    has_data = BooleanProperty(False)
    has_sources = BooleanProperty(False)
    data_title = StringProperty("")
    data_sub = StringProperty("")
    data_warning = StringProperty("")
    start_date = StringProperty("")
    end_date = StringProperty("")
    start_label = StringProperty("")
    end_label = StringProperty("")
    range_preset = StringProperty("")
    start_time = StringProperty("07:00")
    end_time = StringProperty("11:00")
    start_min = NumericProperty(420)
    end_min = NumericProperty(660)
    marker_text = StringProperty("")
    theme = StringProperty("dark")
    resolution = StringProperty("1920x1080")
    skip_holidays = BooleanProperty(True)
    output_hint = StringProperty("")
    render_summary = StringProperty("")
    generate_label = StringProperty("RENDER")
    can_render = BooleanProperty(False)
    # planner + live preview
    plan_days = ListProperty([])
    plan_caption = StringProperty("")
    png_count = NumericProperty(-1)  # -1 while planning
    selected_day = StringProperty("")
    preview_src = StringProperty("")
    preview_title = StringProperty("")
    preview_meta = StringProperty("")
    preview_note = StringProperty("")
    preview_help = StringProperty("")
    # guided flow
    data_state = StringProperty("empty")  # empty | dirty | ready
    data_status = StringProperty("")
    nq_info = StringProperty("")
    es_info = StringProperty("")
    make_text = StringProperty("")
    show_options = BooleanProperty(False)
    show_files = BooleanProperty(False)
    library_version = NumericProperty(0)
    # explain / AI
    facts_headline = StringProperty("")
    facts_text = StringProperty("")
    show_facts = BooleanProperty(False)
    ai_ready = BooleanProperty(False)
    ai_answer = StringProperty("")
    ai_note = StringProperty("")

    def build(self):
        Window.clearcolor = C.bg
        Window.softinput_mode = "below_target"
        root_dir = app_storage_dir()
        self.settings_path = os.path.join(root_dir, "settings.json")
        self.cache_root = os.path.join(root_dir, "cache")
        self.work_root = os.path.join(root_dir, "charts")
        self.preview_dir = os.path.join(root_dir, "preview")
        os.makedirs(self.preview_dir, exist_ok=True)
        self.cfg = AppSettings.load(self.settings_path)
        self.cancel_event = threading.Event()
        self.busy = False
        self._last_run_dir = None
        self._stores = {}
        self._plan_token = 0
        self._preview_token = 0
        self._render_lock = threading.Lock()
        self._facts = None
        self._ai = None
        self._ai_busy = False
        self._migrate_library()
        self._check_ai()
        self._plan_trigger = Clock.create_trigger(self._run_plan, 0.15)
        self._preview_trigger = Clock.create_trigger(self._run_preview, 0.12)
        Builder.load_string(KV)
        self._apply_cfg()
        self.bind(start_date=self._derive, end_date=self._derive, instrument=self._derive,
                  start_time=self._derive, end_time=self._derive, skip_holidays=self._derive,
                  resolution=self._derive, theme=self._derive)
        self.bind(start_date=self._plan_trigger, end_date=self._plan_trigger, instrument=self._plan_trigger,
                  start_time=self._plan_trigger, end_time=self._plan_trigger, skip_holidays=self._plan_trigger)
        self.bind(selected_day=self._preview_trigger, theme=self._preview_trigger)
        self._derive()
        self._plan_trigger()
        self.sm = ScreenManager(transition=SlideTransition(duration=0.18))
        from .backtest_ui import BacktestResultScreen, BacktestScreen, load_kv

        load_kv()
        for cls, name in ((HomeScreen, "home"), (WelcomeScreen, "welcome"), (ImportScreen, "import"),
                          (ProgressScreen, "progress"), (GalleryScreen, "gallery"), (ViewerScreen, "viewer"),
                          (BacktestScreen, "backtest"), (BacktestResultScreen, "bt_results")):
            self.sm.add_widget(cls(name=name))
        if not self.cfg.library:
            self.sm.current = "welcome"
        Window.bind(on_keyboard=self._on_key)
        Clock.schedule_once(lambda dt: self._startup_checks(), 0.3)
        self.root_box = BoxLayout(orientation="vertical")
        self.root_box.add_widget(self.sm)
        if ANDROID:  # Android 15 draws apps behind the status / gesture bars
            Clock.schedule_once(self._apply_insets, 0.6)
            Window.bind(size=lambda *_: Clock.schedule_once(self._apply_insets, 0.3))
        return self.root_box

    def _apply_insets(self, *_):
        from ..platform_io.android_io import system_bar_insets

        top, bottom = system_bar_insets(int(Window.height))
        self.root_box.padding = [0, top, 0, bottom]

    # ---------------- settings / derived state
    def _apply_cfg(self):
        c = self.cfg
        self.instrument = c.instrument if c.instrument in INSTRUMENTS else "NQ"
        self.start_time, self.end_time = c.start_time, c.end_time
        self.theme, self.resolution, self.skip_holidays = c.theme, c.resolution, c.skip_holidays
        self.refresh_status()
        if not c.start_date or not c.end_date:
            self.quick_range(31, save=False)
        else:
            self.start_date, self.end_date = c.start_date, c.end_date

    def save_cfg(self):
        c = self.cfg
        c.instrument, c.start_date, c.end_date = self.instrument, self.start_date, self.end_date
        c.start_time, c.end_time = self.start_time, self.end_time
        c.theme, c.resolution, c.skip_holidays = self.theme, self.resolution, self.skip_holidays
        try:
            c.save(self.settings_path)
        except OSError:
            traceback.print_exc()

    def _derive(self, *_):
        """Recompute every label that depends on the current selections."""
        self.start_label, self.end_label = nice_date(self.start_date), nice_date(self.end_date)
        try:
            sh, sm_ = (int(x) for x in self.start_time.split(":"))
            eh, em = (int(x) for x in self.end_time.split(":"))
            self.start_min, self.end_min = sh * 60 + sm_, eh * 60 + em
        except ValueError:
            pass
        inside = [m for m in self.cfg.markers
                  if self.start_min <= int(m[:2]) * 60 + int(m[3:]) <= self.end_min]
        self.marker_text = ("lines " + " ".join(inside)) if inside else "no marker lines inside this window"
        self.output_hint = f"→ Pictures/FuturesCharts/{self.instrument}/{self.start_date}_to_{self.end_date}/"
        w, h = self.resolution.split("x")
        self.render_summary = f"{w}×{h} · {self.theme} · {self.start_time}–{self.end_time} ET · 1-min"
        self.range_preset = self._preset()
        n = self.png_count
        try:
            a, b = date.fromisoformat(self.start_date), date.fromisoformat(self.end_date)
            span = f"{short_date(a)} to {short_date(b)}"
        except ValueError:
            span = ""
        self.make_text = (f"You'll get [b]{n:,} chart picture{'s' if n != 1 else ''}[/b], one for each trading day "
                          f"from {span}, showing {self.start_time} to {self.end_time} New York time. "
                          f"They are saved to [b]{self.output_hint[2:]}[/b] and show up in your gallery."
                          if self.has_data and n > 0 else
                          "Finish the steps above and the chart count appears here.")
        if self.data_state == "empty":
            self.generate_label, self.can_render = "Add a CSV file first (step 1)", False
        elif self.data_state == "dirty":
            self.generate_label, self.can_render = "Tap Prepare data first (step 1)", False
        elif not self.has_data:
            self.generate_label, self.can_render = f"No {self.instrument} data in your files", False
        elif self.start_min >= self.end_min:
            self.generate_label, self.can_render = "End time must be after start time", False
        elif n < 0:
            self.generate_label, self.can_render = "Counting days…", False
        elif n == 0:
            self.generate_label, self.can_render = "No trading days in this range", False
        else:
            self.generate_label, self.can_render = f"Make {n:,} chart{'s' if n != 1 else ''}", True

    def _preset(self) -> str:
        rng = self.data_range()
        try:
            a, b = date.fromisoformat(self.start_date), date.fromisoformat(self.end_date)
        except ValueError:
            return ""
        if not rng or b != rng[1]:
            return ""
        if a == rng[0]:
            return "ALL"
        if a == date(b.year, 1, 1):
            return "YTD"
        return {7: "1W", 31: "1M", 92: "3M", 365: "1Y"}.get((b - a).days + 1, "")

    def set_setting(self, key, value):
        if getattr(self, key) != value:
            setattr(self, key, value)
            self.save_cfg()

    def set_instrument(self, inst):
        self.instrument = inst
        self.refresh_status()
        self._derive()
        self.save_cfg()

    def meta(self, inst=None):
        return load_meta(os.path.join(self.cache_root, inst or self.instrument))

    def data_range(self):
        m = self.meta()
        if not m:
            return None
        return date.fromisoformat(m["first"]), date.fromisoformat(m["last"])

    def _store(self):
        inst = self.instrument
        if inst not in self._stores:
            try:
                self._stores[inst] = BarStore(os.path.join(self.cache_root, inst))
            except (FileNotFoundError, OSError, ValueError):
                return None
        return self._stores[inst]

    def refresh_status(self):
        enabled = [e for e in self.cfg.library if e.get("enabled", True)]
        if not enabled:
            state = "empty"
        elif self._lib_signature() != self.cfg.library_built:
            state = "dirty"
        else:
            state = "ready"
        self.data_state = state
        infos = {}
        for inst in INSTRUMENTS:
            m = self.meta(inst) if state == "ready" else None
            infos[inst] = ((f"data {m['first'][:4]}–{m['last'][:4]}" if m['first'][:4] != m['last'][:4]
                            else "data from " + date.fromisoformat(m['first']).strftime("%b ") + str(date.fromisoformat(m['first']).day)) if m
                           else ("no data in your files" if state == "ready" else ""))
        self.nq_info, self.es_info = infos["NQ"], infos["ES"]
        m = self.meta() if state == "ready" else None
        self.has_data = bool(m)
        self.has_sources = bool(enabled)
        if state == "empty":
            self.data_status = "No files yet. Tap [b]Add CSV files[/b] and pick your 1-minute data."
        elif state == "dirty":
            self.data_status = ("Your file list changed. Tap [b]Prepare data[/b] so the app can read it "
                                "(one time; big files take a minute or two).")
        else:
            nice = lambda n: f"{n / 1e6:.1f} million" if n >= 1e6 else f"{n:,}"  # noqa: E731
            parts = [f"{i} {nice(self.meta(i)['rows'])} bars" for i in INSTRUMENTS if self.meta(i)]
            self.data_status = "[color=22c55e]Ready.[/color] " + ", ".join(parts) + "."
        if m and m.get("gaps"):
            parts = [f"{short_date(date.fromisoformat(x) + timedelta(days=1))} - "
                     f"{short_date(date.fromisoformat(y) - timedelta(days=1))}" for x, y in m["gaps"][:3]]
            why = " because that part of the file is damaged (zero-filled)" if m.get("corrupt_bytes") else ""
            self.data_warning = (f"Heads up: there is no {self.instrument} data for " + "; ".join(parts) + why
                                 + ". Charts for those days will be skipped. A fresh export fixes it.")
        else:
            self.data_warning = ""
        self.data_title = ""
        self.data_sub = ""

    # ---------------- CSV library
    def _migrate_library(self):
        if self.cfg.library or not self.cfg.data:
            return
        import uuid

        seen = set()
        for inst, d in self.cfg.data.items():
            for sd in d.get("sources", []):
                key = sd.get("path") or sd.get("uri")
                if key in seen:
                    continue
                seen.add(key)
                fmt = d.get("format", {})
                self.cfg.library.append({"id": uuid.uuid4().hex[:8], "source": sd, "format": fmt,
                                         "instrument": None if fmt.get("symbol_col") else inst,
                                         "enabled": True, "peek": {}})

    def _lib_inputs(self):
        return [BuildInput(Source.from_dict(e["source"]), CsvFormat.from_dict(e["format"]), e.get("instrument"))
                for e in self.cfg.library if e.get("enabled", True)]

    def _lib_signature(self):
        return [i.signature() for i in self._lib_inputs()]

    def lib_describe(self, e) -> str:
        f, pk = e["format"], e.get("peek") or {}
        size = e["source"].get("size", 0)
        size_txt = f"{size / 1e9:.2f} GB" if size > 1e9 else f"{size / 1e6:,.0f} MB"
        if f.get("symbol_col"):
            what = " + ".join(r for r in pk.get("roots", []) if r in INSTRUMENTS) or "contracts"
        else:
            what = e.get("instrument") or "?"
        rng = f"{pk['first']} → {pk['last']}" if pk.get("first") else "dates unknown"
        tz = "UTC" if f.get("source_tz") == "UTC" else f.get("source_tz", "")
        warn = "" if pk.get("first") else "  [color=f2a93b]tap Check format[/color]"
        return f"{what} · {rng} · {size_txt} · times in {tz}{warn}"

    def lib_add(self, sources):
        import uuid

        added, problems = 0, []
        known = {e["source"].get("path") or e["source"].get("uri") for e in self.cfg.library}
        for src in sources:
            key = src.path or src.uri
            if key in known:
                continue
            try:
                fmt, header, _rows, _notes = sniff(read_head(src))
                inst = None
                if not fmt.symbol_col:
                    up = src.name.upper()
                    inst = "ES" if ("ES" in up and "NQ" not in up) else ("NQ" if "NQ" in up else self.instrument)
                try:
                    pk = peek_range(src, fmt)
                except Exception:
                    pk = {}
                self.cfg.library.append({"id": uuid.uuid4().hex[:8], "source": src.to_dict(), "format": fmt.to_dict(),
                                         "instrument": inst, "enabled": True, "peek": pk})
                added += 1
            except Exception as exc:
                problems.append(f"{src.name}: {describe_error(exc)}")
        self._lib_changed()
        if problems:
            message("Some files could not be read", "\n\n".join(problems))
        elif added and self.data_state == "dirty":
            self.prepare_data()  # read the new files straight away - no extra button to find

    def _lib_changed(self):
        self.save_cfg()
        self.library_version += 1
        self.refresh_status()
        self._derive()

    def _entry(self, eid):
        return next((e for e in self.cfg.library if e["id"] == eid), None)

    def lib_remove(self, eid):
        e = self._entry(eid)
        if not e:
            return

        def do():
            self.cfg.library.remove(e)
            self._lib_changed()

        message("Remove file?", f"Remove [b]{e['source']['name']}[/b] from the list? The file itself is not deleted.",
                on_ok=do, ok_text="Remove", cancel_text="Keep")

    def lib_toggle(self, eid, value):
        e = self._entry(eid)
        if e and e.get("enabled", True) != value:
            e["enabled"] = value
            self._lib_changed()

    def lib_set_instrument(self, eid, inst):
        e = self._entry(eid)
        if e and e.get("instrument") != inst:
            e["instrument"] = inst
            self._lib_changed()

    def lib_open_settings(self, eid):
        e = self._entry(eid)
        if not e:
            return
        self._editing = eid
        try:
            self.sm.get_screen("import").load([Source.from_dict(e["source"])], CsvFormat.from_dict(e["format"]))
        except Exception as exc:
            message("Can't read this file", describe_error(exc))
            return
        self.go("import")

    def save_entry_format(self, fmt):
        e = self._entry(getattr(self, "_editing", None))
        if e:
            e["format"] = fmt.to_dict()
            if fmt.symbol_col:
                e["instrument"] = None
            elif not e.get("instrument"):
                e["instrument"] = self.instrument
            try:
                e["peek"] = peek_range(Source.from_dict(e["source"]), fmt)
            except Exception:
                e["peek"] = {}
        self._lib_changed()
        self.go("home")

    def start_demo(self):
        from ..demo import write_demo_csv

        prog = self.sm.get_screen("progress")
        prog.start("Making demo data", "made-up NQ and ES prices for the last 3 months")
        self.go("progress")

        def work():
            try:
                path = write_demo_csv(os.path.join(app_storage_dir(), "demo"))
                Clock.schedule_once(lambda dt: self._after_demo(path), 0)
            except Exception as exc:
                traceback.print_exc()
                self._finish(f"[color=ef4444]Could not make demo data:[/color] {exc}")

        threading.Thread(target=work, daemon=True).start()

    def _after_demo(self, path):
        self.lib_add([Source.from_path(path)])

    def show_help(self):
        message("How it works",
                "[b]1. Add your data[/b]: tap Add CSV files and pick one or more 1-minute CSV files. "
                "Then tap Prepare data once.\n\n"
                "[b]2. Pick NQ or ES[/b], the days, and the time of day (New York time).\n\n"
                "[b]3. Tap Make charts.[/b] You get one picture per trading day in your gallery, "
                "and can open them under My charts.\n\n"
                "Tap any square in the calendar to preview that day, and use [b]Explain this day[/b] to "
                "read what happened or ask the offline AI a question.", ok_text="Got it")
        self.cfg.seen_intro = True
        self.save_cfg()

    # ---------------- AI (on-device)
    def _model_dir(self):
        return os.path.join(app_storage_dir(), "models")

    def _check_ai(self):
        from ..ai_model import MODELS

        path = self.cfg.ai_model
        if not path or not os.path.exists(path):
            path = ""
            for m in sorted(MODELS.values(), key=lambda x: -x["size"]):
                cand = os.path.join(self._model_dir(), m["file"])
                if os.path.exists(cand) and os.path.getsize(cand) == m["size"]:
                    path = cand
                    break
            self.cfg.ai_model = path
        self.ai_ready = bool(path)
        if path and (self._ai is None or self._ai.path != path):
            from ..ai_model import LocalModel

            self._ai = LocalModel(path)
        if not path:
            self.ai_note = ""

    def ask_ai(self, question):
        question = (question or "").strip()
        if not question or self._ai_busy:
            return
        if not self._facts:
            self.ai_answer, self.ai_note = "", "Pick a day in the calendar first."
            return
        self._check_ai()
        if not self._ai:
            return
        from ..ai_model import select_facts, unverified_numbers

        self._ai_busy = True
        facts = self._facts
        ctx = select_facts(facts, question)
        self.ai_answer = f"[color=8e9096]{question}[/color]\n…"
        name = os.path.basename(self._ai.path).split("-instruct")[0]
        self.ai_note = "Loading the AI model (first time takes a few seconds)…" if not self._ai.loaded else ""

        @mainthread
        def stream(text):
            self.ai_answer = f"[color=8e9096]{question}[/color]\n{text}"
            self.ai_note = ""

        @mainthread
        def done(text, err=None):
            self._ai_busy = False
            if err:
                self.ai_answer, self.ai_note = "", f"[color=ef4444]{err}[/color]"
                return
            bad = unverified_numbers(text, facts.text())
            self.ai_answer = f"[color=8e9096]{question}[/color]\n{text}"
            note = f"Answered offline by {name}. Small models can mix things up; the details above are always exact."
            if bad:
                note = (f"[color=f2a93b]Check this answer: {', '.join(bad[:3])} "
                        f"{'is' if len(bad) == 1 else 'are'} not in the data.[/color] " + note)
            self.ai_note = note

        def work():
            try:
                done(self._ai.ask(ctx, question, on_token=stream))
            except Exception as exc:
                traceback.print_exc()
                done("", str(exc))

        threading.Thread(target=work, daemon=True).start()

    def download_ai(self, key):
        from ..ai_model import MODELS, download_model

        m = MODELS[key]

        def go():
            prog = self.sm.get_screen("progress")
            prog.start("Downloading the AI model", f"{m['label']} · from huggingface.co/Qwen · one time")
            self._begin_job()

            def work():
                try:
                    path = download_model(key, self._model_dir(), progress=lambda f, t: self._progress(f, t),
                                          cancel=self.cancel_event)
                    self.cfg.ai_model = path
                    self.save_cfg()
                    self._finish("The AI model is installed. Go back and use [b]Ask the AI[/b] under "
                                 "Explain this day. It works offline from now on.", ok=True,
                                 stats=[(f"{m['size'] / 1e6:,.0f} MB", "model", C.text)])
                except Exception as exc:
                    traceback.print_exc()
                    self._finish(f"[color=ef4444]Download stopped:[/color] {exc}\n\nTap the download button "
                                 "again to resume where it stopped.")
                Clock.schedule_once(lambda dt: self._check_ai(), 0)

            threading.Thread(target=work, daemon=True).start()

        message("Download AI model?", f"This downloads [b]{m['label']}[/b] from Hugging Face (the official Qwen "
                f"repository, Apache-2.0 licence). Use Wi-Fi. After that, the AI works without internet.",
                on_ok=go, ok_text="Download", cancel_text="Cancel")

    def choose_ai_file(self):
        def got(picked):
            if not picked:
                return
            src = Source.from_dict(picked[0])
            if not src.name.lower().endswith(".gguf"):
                message("Not a model file", "Please pick a .gguf file (for example qwen2.5-1.5b-instruct-q4_k_m.gguf).")
                return
            if src.path:
                self.cfg.ai_model = src.path
                self.save_cfg()
                self._check_ai()
                return
            dest = os.path.join(self._model_dir(), src.name)  # Android: copy out of the picker

            def work():
                os.makedirs(self._model_dir(), exist_ok=True)
                with src.open_binary() as fi, open(dest, "wb") as fo:
                    while True:
                        buf = fi.read(1 << 22)
                        if not buf:
                            break
                        fo.write(buf)
                self.cfg.ai_model = dest
                self.save_cfg()
                Clock.schedule_once(lambda dt: self._check_ai(), 0)

            threading.Thread(target=work, daemon=True).start()

        if ANDROID:
            from ..platform_io import android_io

            android_io.pick_csv_files(got, multiple=False)
        else:
            self._desktop_chooser(got, filters=["*.gguf"], title="Choose a .gguf model file", multi=False)

    # ---------------- planner (heatmap + exact count) and live preview
    def _run_plan(self, *_):
        store = self._store() if self.data_state == "ready" else None
        self._plan_token += 1
        tok = self._plan_token
        try:
            a, b = date.fromisoformat(self.start_date), date.fromisoformat(self.end_date)
            st, et = parse_hhmm(self.start_time), parse_hhmm(self.end_time)
        except ValueError:
            return
        if store is None or et <= st:
            self.plan_days, self.png_count = [], 0 if store is None else -1
            self.plan_caption = ""
            self.selected_day = ""
            self.preview_src = ""
            self.preview_note = ("Add and prepare your data to see a preview here" if store is None
                                 else "End time must be after start time")
            self.preview_help, self.facts_headline, self.facts_text, self._facts = "", "", "", None
            self._derive()
            return
        self.png_count = -1
        self.plan_caption = "PLANNING …"
        self._derive()
        inst, skip = self.instrument, self.skip_holidays

        def work():
            try:
                days = plan_days(store, inst, a, b, st, et, skip)
            except Exception:
                traceback.print_exc()
                days = []
            self._plan_done(tok, days)

        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _plan_done(self, tok, days):
        if tok != self._plan_token:
            return
        self.plan_days = days
        ok = [d for d in days if d["kind"] == "ok"]
        up = sum(1 for d in ok if d["chg"] >= 0)
        nod = sum(1 for d in days if d["kind"] == "nodata")
        hol = sum(1 for d in days if d["kind"] == "holiday")
        self.png_count = len(ok)
        self.plan_caption = (f"{len(ok)} trading days · {up} up · {len(ok) - up} down"
                             + (f" · {hol} holiday" if hol else "") + (f" · {nod} without data" if nod else ""))
        valid = {d["date"] for d in ok}
        if self.selected_day not in valid:
            self.selected_day = ok[-1]["date"] if ok else ""
            if not ok:
                self.preview_src = ""
                self.preview_note = "No trading days with data in this range"
        else:
            self._preview_trigger()
        self._derive()

    def select_day(self, iso):
        self.selected_day = iso

    def _run_preview(self, *_):
        store, day = self._store(), self.selected_day
        if store is None or not day or self.busy:
            return
        self._preview_token += 1
        tok = self._preview_token
        inst, theme, markers = self.instrument, self.theme, list(self.cfg.markers)
        try:
            st, et = parse_hhmm(self.start_time), parse_hhmm(self.end_time)
        except ValueError:
            return
        path = os.path.join(self.preview_dir, f"preview_{tok % 3}.png")

        def work():
            with self._render_lock:
                if tok != self._preview_token:
                    return
                try:
                    from ..chart_renderer import render_day

                    d = date.fromisoformat(day)
                    bars = store.window(ny_epoch(d, st), ny_epoch(d, et))
                    if len(bars["ts"]) == 0:
                        return
                    info = render_day(bars, d, inst, st, et, path, None, theme=theme, size=(1280, 720),
                                      markers=markers)
                    info["symbol"] = bars.get("symbol", "")
                    from ..analysis import analyze_day

                    info["facts"] = analyze_day(store, inst, d, st, et)
                except Exception:
                    traceback.print_exc()
                    return
            self._preview_done(tok, path, d, info)

        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _preview_done(self, tok, path, d, info):
        if tok != self._preview_token:
            return
        self.preview_src = path
        chg = info["close"] / info["open"] - 1 if info["open"] else 0
        col = "22c55e" if chg >= 0 else "ef4444"
        self.preview_title = f"{self.instrument}  {d.strftime('%a').upper()} {d.isoformat()}"
        self.preview_meta = (f"{info.get('symbol', '')}   [color={col}]{chg * 100:+.2f}%[/color]   "
                             f"{info['bars']} bars")
        self.preview_help = (f"{self.instrument} on {d.strftime('%A')}, {short_date(d)}"
                             + (f" (contract {info['symbol']})" if info.get("symbol") else "")
                             + ". This is exactly how the saved picture will look.")
        f = info.get("facts")
        self._facts = f
        if f:
            self.facts_headline = f.headline()
            self.facts_text = "\n".join(f"• {ln}" for ln in f.lines)
        if self.ai_answer:
            self.ai_answer, self.ai_note = "", ""

    def _startup_checks(self):
        try:
            from ..timeparse import get_zone

            get_zone("America/New_York")
        except Exception as exc:
            message("Timezone data missing", describe_error(exc))
            return
        self.cfg.seen_intro = True

    # ---------------- navigation
    def go(self, name):
        if self.busy and name != "progress":
            return
        cur = self.sm.screen_names.index(self.sm.current)
        nxt = self.sm.screen_names.index(name)
        self.sm.transition.direction = "left" if nxt > cur else "right"
        self.sm.current = name
        if name == "home":
            self.refresh_status()
            self._derive()

    def _on_key(self, window, key, *args):
        if key == 27:  # Android back / Esc
            back = {"import": "home", "gallery": "home", "viewer": "gallery", "backtest": "home",
                    "bt_results": "backtest"}
            cur = self.sm.current
            if cur in ("home", "welcome"):
                return False
            if cur == "progress":
                if not self.busy:
                    self.go("home")
                return True
            self.go(back.get(cur, "home"))
            return True
        return False

    def on_pause(self):
        return True

    # ---------------- pickers
    def pick_date(self, which):
        cur = date.fromisoformat(self.start_date if which == "start" else self.end_date)

        def done(d):
            if which == "start":
                self.start_date = d.isoformat()
                if self.end_date < self.start_date:
                    self.end_date = self.start_date
            else:
                self.end_date = d.isoformat()
                if self.start_date > self.end_date:
                    self.start_date = self.end_date
            self.save_cfg()

        DatePickerSheet(cur, done, data_range=self.data_range(), holiday_fn=holiday_name,
                        title="FROM DATE" if which == "start" else "TO DATE").open()

    def quick_range(self, days, save=True):
        rng = self.data_range()
        end = rng[1] if rng else date.today()
        if days == "all":
            start = rng[0] if rng else end
        elif days == "ytd":
            start = date(end.year, 1, 1)
        else:
            start = end - timedelta(days=days - 1)
        if rng and start < rng[0]:
            start = rng[0]
        self.start_date, self.end_date = start.isoformat(), end.isoformat()
        if save:
            self.save_cfg()

    def pick_time(self, which):
        cur = self.start_time if which == "start" else self.end_time

        def done(t):
            setattr(self, f"{which}_time", t)
            self.save_cfg()

        TimePickerSheet(cur, done, title=f"WINDOW {'START' if which == 'start' else 'END'} · NEW YORK").open()

    def reset_window(self):
        self.start_time, self.end_time = "07:00", "11:00"
        self.save_cfg()

    # ---------------- import
    def pick_csv(self):
        if ANDROID:
            from ..platform_io import android_io

            android_io.pick_csv_files(self._on_picked)
        else:
            self._desktop_chooser()

    def _desktop_chooser(self, cb=None, filters=None, title="CHOOSE CSV FILES (CTRL/SHIFT-CLICK FOR SEVERAL)",
                         multi=True):
        from kivy.uix.filechooser import FileChooserListView

        sh = Sheet(title=title, max_width=dp(900))
        start = os.path.expanduser("~/Downloads")
        fc = FileChooserListView(path=start if os.path.isdir(start) else os.path.expanduser("~"),
                                 multiselect=multi, filters=filters or ["*.csv", "*.CSV", "*.txt", "*.TXT"])
        sh.card.add_widget(fc)
        row = BoxLayout(size_hint_y=None, height=dp(50), spacing=dp(10))
        row.add_widget(GhostButton(text="Cancel", height=dp(50), on_release=lambda *_: sh.dismiss()))

        def ok(*_):
            sh.dismiss()
            (cb or self._on_picked)([Source.from_path(p).to_dict() for p in fc.selection if os.path.isfile(p)])

        row.add_widget(PrimaryButton(text="Use selected", height=dp(50), on_release=ok))
        sh.card.add_widget(row)
        sh.fit_height(Window.height * 0.85)
        sh.open()

    def _on_picked(self, picked):
        if picked:
            self.lib_add([Source.from_dict(p) for p in picked])

    def prepare_data(self):
        inputs = self._lib_inputs()
        if not inputs:
            return
        prog = self.sm.get_screen("progress")
        size = sum(i.source.size for i in inputs)
        size_txt = f"{size / 1e9:.1f} GB" if size >= 1e9 else f"{max(1, round(size / 1e6))} MB"
        prog.start("Reading your data", f"{len(inputs)} file{'s' if len(inputs) != 1 else ''}, {size_txt}. "
                   "This only happens once.")
        self._begin_job()
        sig = self._lib_signature()

        def work():
            try:
                metas = CacheBuilder(self.cache_root).build_inputs(list(INSTRUMENTS), inputs,
                                                                   progress=lambda f, t: self._progress(f, t),
                                                                   cancel=self.cancel_event)
                self.cfg.library_built = sig
                self.save_cfg()
                fmt_n = lambda n: f"{n / 1e6:.1f}M" if n >= 1e6 else f"{n / 1e3:.0f}k"  # noqa: E731
                stats = [(fmt_n(m['rows']), f"{inst} minutes of data", C.text) for inst, m in metas.items()]
                meta = next(iter(metas.values()))
                stats.append((f"{meta['build_seconds']:.0f}s", "time", C.text))
                lines = [f"[b]{inst}[/b]: {short_date(date.fromisoformat(m['first']))} to "
                         f"{short_date(date.fromisoformat(m['last']))}" for inst, m in metas.items()]
                if meta.get("gaps"):
                    lines.append("[color=f2a93b]Missing: " + "; ".join(f"{a} to {b}" for a, b in meta["gaps"][:4])
                                 + (" (damaged part of the file)" if meta.get("corrupt_bytes") else "") + "[/color]")
                lines.append("Your data is ready. Tap Continue to choose the days and make your charts.")
                self._finish("\n".join(lines), ok=True, stats=stats)
            except Cancelled:
                self._finish("Stopped. Nothing was changed.")
            except Exception as exc:
                traceback.print_exc()
                self._finish(f"[color=ef4444][b]Could not read the files[/b][/color]\n{describe_error(exc)}\n\n"
                             "Go back and tap [b]format[/b] next to the file to check its settings.")

        threading.Thread(target=work, daemon=True).start()

    def open_import(self, sources):
        d = self.cfg.instrument_data(self.instrument)
        saved_fmt = CsvFormat.from_dict(d.get("format")) if d.get("sources") else None
        if sources is None:
            sources = [Source.from_dict(s) for s in d.get("sources", [])]
            if ANDROID:
                from ..platform_io import android_io

                for s in sources:
                    try:
                        s.name, s.size = android_io.refresh_meta(s.uri)
                    except Exception:
                        pass
        if not sources:
            return
        try:
            self.sm.get_screen("import").load(sources, saved_fmt)
        except Exception as exc:
            traceback.print_exc()
            message("Can't read this file", describe_error(exc))
            return
        self.go("import")

    def start_index(self, sources, fmt):
        if not fmt.ts_col or not all([fmt.open_col, fmt.high_col, fmt.low_col, fmt.close_col]):
            message("Missing columns", "Select the timestamp, open, high, low and close columns first.")
            return
        insts = [self.instrument] + [i for i in INSTRUMENTS if i != self.instrument] \
            if fmt.symbol_col else [self.instrument]
        size = sum(s.size for s in sources)
        what = sources[0].name if len(sources) == 1 else f"{len(sources)} files"
        prog = self.sm.get_screen("progress")
        prog.start(f"Indexing {' + '.join(insts)}", f"{what}  ·  {size / 1e9:.2f} GB  ·  one-time step")
        self._begin_job()

        def work():
            try:
                metas = CacheBuilder(self.cache_root).build_many(
                    insts, sources, fmt, progress=lambda f, t: self._progress(f, t), cancel=self.cancel_event)
                for inst in metas:
                    d = self.cfg.instrument_data(inst)
                    d["sources"] = [s.to_dict() for s in sources]
                    d["format"] = fmt.to_dict()
                self.save_cfg()
                meta = next(iter(metas.values()))
                stats = [(f"{m['rows'] / 1e6:.1f}M", f"{inst} bars", C.text) for inst, m in metas.items()]
                stats.append((f"{meta['build_seconds']:.0f}s", "time", C.text))
                lines = [f"[b]{inst}[/b]  {m['first']} – {m['last']}"
                         + (f"  ·  {len(m['contracts'])} contract months" if m["contracts"] else "")
                         for inst, m in metas.items()]
                lines.append(f"{meta['bad_rows']:,} unparseable rows skipped"
                             + (f", {meta['ignored_rows']:,} spread rows ignored" if meta["ignored_rows"] else "")
                             + ".")
                if meta.get("gaps"):
                    lines.append("[color=f5a524]Missing data: "
                                 + "; ".join(f"{a} – {b}" for a, b in meta["gaps"][:4])
                                 + (" (the file is zero-filled there)" if meta.get("corrupt_bytes") else "")
                                 + ".[/color]")
                if self.instrument not in metas:
                    lines.insert(0, f"[color=f5a524]No {self.instrument} rows found in this file.[/color]")
                self._finish("\n".join(lines), ok=True, quick_range=True, stats=stats)
            except Cancelled:
                self._finish("Indexing cancelled. The previous index (if any) is unchanged.")
            except Exception as exc:
                traceback.print_exc()
                self._finish(f"[color=ef4444][b]Import failed[/b][/color]\n{describe_error(exc)}\n\n"
                             "Go back and open 'Advanced column mapping' to adjust the format.")

        threading.Thread(target=work, daemon=True).start()

    # ---------------- generate
    def generate(self):
        try:
            req = GenerateRequest.from_strings(
                self.instrument, self.start_date, self.end_date, self.start_time, self.end_time,
                theme=self.theme, resolution=self.resolution, skip_holidays=self.skip_holidays,
                markers=self.cfg.markers)
            store = BarStore(os.path.join(self.cache_root, self.instrument))
        except (ValueError, FileNotFoundError) as exc:
            message("Can't generate", describe_error(exc))
            return
        rng = self.data_range()
        if rng and (req.end_date < rng[0] or req.start_date > rng[1]):
            message("No data in range",
                    f"Your {self.instrument} data covers {rng[0]} to {rng[1]}, which doesn't overlap "
                    f"{req.start_date} – {req.end_date}.")
            return
        if count_days(req) > MAX_DAYS_WITHOUT_CONFIRM:
            est = self.png_count if self.png_count >= 0 else count_days(req) * 5 // 7
            message("Large range", f"This creates [b]{est:,}[/b] PNGs (~{est * 0.3:,.0f} MB). "
                    "It can take a while on a tablet. Continue?",
                    on_ok=lambda: self._run_generate(req, store), ok_text="Generate", cancel_text="Cancel")
            return
        self._run_generate(req, store)

    def _run_generate(self, req, store):
        prog = self.sm.get_screen("progress")
        prog.start(f"Generating {req.instrument} charts",
                   f"{short_date(req.start_date)} – {short_date(req.end_date)}  ·  "
                   f"{req.start_time.strftime('%H:%M')}–{req.end_time.strftime('%H:%M')} ET")
        self._begin_job()
        if ANDROID:
            from ..platform_io.android_io import MediaStoreSink

            sink = MediaStoreSink()
        else:
            from ..platform_io.desktop_io import DesktopSink

            sink = DesktopSink()

        def on_progress(frac, text, entry=None):
            preview = os.path.join(self.work_root, req.instrument, req.run_name, entry["file"]) if entry else None
            self._progress(frac, text, preview)

        def work():
            try:
                s = run_generation(req, store, self.work_root, sink=sink, progress=on_progress,
                                   cancel=self.cancel_event)
                sk = s.skipped
                stats = [(f"{len(s.made)}", "charts", C.up if s.made else C.text),
                         (f"{sum(len(v) for v in sk.values())}", "days skipped", C.text),
                         (f"{s.seconds:.0f}s", "time", C.text)]
                lines = []
                parts = [f"{len(v)} {k}" for k, v in sk.items() if v]
                if parts:
                    lines.append("Skipped: " + ", ".join(parts) + ".")
                if sk["holiday"]:
                    lines.append("Holidays: " + ", ".join(f"{d} {n}" for d, n in sk["holiday"][:6]))
                if s.errors:
                    lines.append(f"[color=ef4444]{len(s.errors)} error(s): {s.errors[0][0]}: {s.errors[0][1]}[/color]")
                if not s.made and not s.cancelled:
                    lines.append(f"No data in this range. {self.instrument} data covers "
                                 f"{s.data_range[0]} to {s.data_range[1]}.")
                if s.cancelled:
                    lines.append("Cancelled.")
                where = req.public_rel_dir if ANDROID else os.path.join("~", req.public_rel_dir)
                if s.made:
                    lines.append(f"Saved to [b]{where}/[/b]")
                self._finish("\n".join(lines), ok=bool(s.made), gallery_dir=s.run_dir if s.made else None,
                             stats=stats)
            except Exception as exc:
                traceback.print_exc()
                self._finish(f"[color=ef4444][b]Failed[/b][/color]\n{describe_error(exc)}")

        threading.Thread(target=work, daemon=True).start()

    # ---------------- job plumbing (worker thread -> UI thread)
    def _begin_job(self):
        self.cancel_event.clear()
        self.busy = True
        self.go("progress")
        if ANDROID:
            from ..platform_io.android_io import keep_screen_on

            keep_screen_on(True)

    @mainthread
    def _progress(self, frac, text, preview=None):
        p = self.sm.get_screen("progress")
        p.fraction = frac
        p.status_text = text
        if preview:
            p.preview = preview

    @mainthread
    def _finish(self, text, ok=False, gallery_dir=None, quick_range=False, stats=None):
        self.busy = False
        p = self.sm.get_screen("progress")
        p.finished = True
        p.fraction = 1 if ok else p.fraction
        p.status_text = "Done" if ok else "Stopped"
        p.summary_text = text
        p.gallery_ready = bool(gallery_dir)
        p.set_stats(stats or [])
        self._last_run_dir = gallery_dir
        self._stores.clear()
        self.refresh_status()
        self._plan_trigger()
        if quick_range:
            self.quick_range(31)
        self._derive()
        if ANDROID:
            from ..platform_io.android_io import keep_screen_on

            keep_screen_on(False)

    def cancel_job(self):
        self.cancel_event.set()
        self.sm.get_screen("progress").status_text = "Cancelling…"

    # ---------------- gallery
    def open_gallery(self):
        g = self.sm.get_screen("gallery")
        g.refresh(select_dir=self._last_run_dir)
        self._last_run_dir = None
        self.go("gallery")

    def open_viewer(self, index):
        g = self.sm.get_screen("gallery")
        if g.current:
            self.sm.get_screen("viewer").show(g.current, index)
            self.go("viewer")
