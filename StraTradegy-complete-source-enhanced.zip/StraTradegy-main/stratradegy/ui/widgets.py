"""Design system + reusable widgets.

Visual language: a quiet trading-terminal look. Near-black neutral panels split
by hairlines (no floating cards), monospace numerals (DejaVu Sans Mono - the
same family the charts use, shipped inside matplotlib, so nothing extra to
bundle), small radii, and one accent: amber, the colour of the 09:30 line.
Green/red are reserved for market data.
"""

from __future__ import annotations

import calendar
import importlib.util
import os
from datetime import date

from kivy.animation import Animation
from kivy.clock import Clock
from kivy.core.text import LabelBase
from kivy.graphics import Color, Line, Rectangle, RoundedRectangle
from kivy.graphics.transformation import Matrix
from kivy.lang import Builder, global_idmap
from kivy.metrics import dp, sp
from kivy.properties import (BooleanProperty, ColorProperty, ListProperty, NumericProperty,
                             ObjectProperty, StringProperty)
from kivy.uix.behaviors import ButtonBehavior, ToggleButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.modalview import ModalView
from kivy.uix.scatter import Scatter
from kivy.uix.spinner import Spinner
from kivy.uix.stencilview import StencilView
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget


def hexc(h, a=1.0):
    h = h.lstrip("#")
    return [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)] + [a]


class _Palette:
    def __init__(self, **colors):
        self.__dict__.update(colors)


C = _Palette(
    bg=hexc("0b0c0e"),
    panel=hexc("111215"),
    raised=hexc("17191d"),
    hover=hexc("1e2025"),
    line=hexc("23252a"),
    line2=hexc("2e3137"),
    text=hexc("e7e5e1"),
    muted=hexc("8e9096"),
    faint=hexc("5b5e65"),
    accent=hexc("f2a93b"),
    accent_down=hexc("d4902a"),
    accent_ink=hexc("17130b"),
    accent_soft=hexc("f2a93b", 0.14),
    up=hexc("22c55e"),
    down=hexc("ef4444"),
    clear=[0, 0, 0, 0],
)
C.surface, C.surface2, C.surface3, C.border = C.panel, C.raised, C.hover, C.line


def _register_fonts() -> str:
    """Use matplotlib's DejaVu Sans Mono (found without importing matplotlib)."""
    try:
        spec = importlib.util.find_spec("matplotlib")
        if spec and spec.origin:
            d = os.path.join(os.path.dirname(spec.origin), "mpl-data", "fonts", "ttf")
            reg, bold = os.path.join(d, "DejaVuSansMono.ttf"), os.path.join(d, "DejaVuSansMono-Bold.ttf")
            if os.path.exists(reg):
                LabelBase.register("Mono", reg, fn_bold=bold if os.path.exists(bold) else None)
                return "Mono"
    except Exception:
        pass
    return "RobotoMono-Regular"


MONO = _register_fonts()

KV = r"""
<SpinnerOption>:
    background_normal: ""
    background_down: ""
    background_color: C.raised if self.state == "normal" else C.hover
    color: C.text
    font_name: MONO
    font_size: sp(14)
    height: dp(44)

<DSpinner>:
    background_normal: ""
    background_down: ""
    background_color: C.clear
    color: C.text
    font_name: MONO
    font_size: sp(14)
    size_hint_y: None
    height: dp(44)
    canvas.before:
        Color:
            rgba: C.raised if self.state == "normal" else C.hover
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(5)]
        Color:
            rgba: C.line2
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(5))
    canvas.after:
        Color:
            rgba: C.faint
        Line:
            points: [self.right - dp(20), self.center_y + dp(2), self.right - dp(16), self.center_y - dp(2), self.right - dp(12), self.center_y + dp(2)]
            width: dp(1.1)

<DInput>:
    multiline: False
    font_name: MONO
    font_size: sp(14)
    background_normal: ""
    background_active: ""
    background_color: C.clear
    foreground_color: C.text
    cursor_color: C.accent
    hint_text_color: C.faint
    size_hint_y: None
    height: dp(44)
    padding: dp(12), (self.height - self.line_height) / 2
    canvas.before:
        Color:
            rgba: C.raised
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(5)]
        Color:
            rgba: C.accent if self.focus else C.line2
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(5))

<RButton>:
    color: (self.fg if not self.disabled else C.faint)
    font_name: "Roboto"
    font_size: sp(14)
    size_hint_y: None
    height: dp(44)
    halign: "center"
    valign: "middle"
    canvas.before:
        Color:
            rgba: (self.bg_down if self.state == "down" else self.bg) if not self.disabled else C.raised
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [self.radius]
        Color:
            rgba: self.outline
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, self.radius)
            width: dp(1)

<PrimaryButton>:
    bg: C.accent
    bg_down: C.accent_down
    fg: C.accent_ink
    bold: True
    font_size: sp(15)
    height: dp(52)

<GhostButton>:
    bg: C.hover
    bg_down: C.line2
    outline: C.line2

<TextButton>:
    color: C.accent
    font_name: "Roboto"
    font_size: sp(13)
    size_hint: None, None
    height: dp(36)
    width: self.texture_size[0] + dp(20)
    canvas.before:
        Color:
            rgba: C.hover if self.state == "down" else C.clear
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(4)]

<Chip>:
    color: C.accent if self.state == "down" else C.muted
    font_name: MONO
    font_size: sp(13)
    size_hint: None, None
    height: dp(32)
    width: self.texture_size[0] + dp(22)
    canvas.before:
        Color:
            rgba: C.accent_soft if self.state == "down" else C.clear
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(4)]
        Color:
            rgba: C.accent if self.state == "down" else C.line2
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(4))

<Segmented>:
    size_hint_y: None
    height: dp(40)
    padding: dp(3)
    spacing: dp(3)
    canvas.before:
        Color:
            rgba: C.bg
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(6)]
        Color:
            rgba: C.line2
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(6))

<SegButton>:
    color: C.text if self.state == "down" else C.muted
    font_name: "Roboto"
    font_size: sp(13)
    markup: True
    halign: "center"
    valign: "middle"
    text_size: self.size
    canvas.before:
        Color:
            rgba: C.hover if self.state == "down" else C.clear
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(4)]
        Color:
            rgba: C.accent if self.state == "down" else C.clear
        Rectangle:
            pos: self.x + dp(8), self.y + dp(3)
            size: self.width - dp(16), dp(2)

<Card>:
    orientation: "vertical"
    size_hint_y: None
    height: self.minimum_height
    padding: dp(16)
    spacing: dp(10)
    canvas.before:
        Color:
            rgba: C.panel
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(8)]
        Color:
            rgba: C.line
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(8))

<Section>:
    orientation: "vertical"
    size_hint_y: None
    height: self.minimum_height
    padding: dp(16), dp(12), dp(16), dp(14)
    spacing: dp(8)
    canvas.before:
        Color:
            rgba: C.line
        Rectangle:
            pos: self.x, self.top - 1
            size: self.width, 1

<Caption>:
    font_name: MONO
    font_size: sp(11)
    color: C.faint
    size_hint_y: None
    height: dp(16)
    text_size: self.size
    halign: "left"
    valign: "middle"

<Body>:
    size_hint_y: None
    text_size: self.width, None
    height: self.texture_size[1]
    halign: "left"
    markup: True
    font_name: MONO
    font_size: sp(12)
    line_height: 1.25
    color: C.text

<FieldRow>:
    size_hint_y: None
    height: dp(40)
    padding: dp(12), 0
    spacing: dp(8)
    canvas.before:
        Color:
            rgba: C.hover if self.state == "down" else C.raised
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(5)]
        Color:
            rgba: C.line2
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(5))
    Label:
        text: root.caption
        font_name: MONO
        font_size: sp(11)
        color: C.faint
        size_hint_x: None
        width: dp(34) if root.caption else 0
        opacity: 1 if root.caption else 0
        text_size: self.size
        halign: "left"
        valign: "middle"
    Label:
        text: root.value
        font_name: MONO
        font_size: sp(15)
        color: C.text
        markup: True
        text_size: self.size
        halign: "left"
        valign: "middle"
        shorten: True
    Label:
        text: "▾"
        font_name: MONO
        font_size: sp(13)
        color: C.faint
        size_hint_x: None
        width: dp(14)

<StatTile>:
    orientation: "vertical"
    padding: dp(12), dp(8)
    canvas.before:
        Color:
            rgba: C.panel
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(6)]
        Color:
            rgba: C.line
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(6))
    Label:
        text: root.value
        font_name: MONO
        font_size: sp(24)
        bold: True
        color: root.tint
        text_size: self.size
        halign: "left"
        valign: "bottom"
    Label:
        text: root.caption
        font_name: MONO
        font_size: sp(11)
        color: C.faint
        size_hint_y: None
        height: dp(18)
        text_size: self.size
        halign: "left"

<SheetCard@BoxLayout>:
    orientation: "vertical"
    padding: dp(18)
    spacing: dp(12)
    canvas.before:
        Color:
            rgba: C.panel
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]
        Color:
            rgba: C.line2
        Line:
            rounded_rectangle: (self.x + .5, self.y + .5, self.width - 1, self.height - 1, dp(10))
"""


# --------------------------------------------------------------------------- #
# primitives
# --------------------------------------------------------------------------- #
class RButton(ButtonBehavior, Label):
    bg = ColorProperty(C.raised)
    bg_down = ColorProperty(C.hover)
    fg = ColorProperty(C.text)
    outline = ColorProperty(C.clear)
    radius = NumericProperty(dp(5))


class PrimaryButton(RButton):
    pass


class GhostButton(RButton):
    pass


class TextButton(ButtonBehavior, Label):
    pass


class Chip(ToggleButtonBehavior, Label):
    value = ObjectProperty(None, allownone=True)


class Segmented(BoxLayout):
    pass


class SegButton(ToggleButtonBehavior, Label):
    allow_no_selection = BooleanProperty(False)


class Card(BoxLayout):
    pass


class Section(BoxLayout):
    pass


class Caption(Label):
    pass


class Body(Label):
    pass


class FieldRow(ButtonBehavior, BoxLayout):
    caption = StringProperty("")
    value = StringProperty("")


class StatTile(BoxLayout):
    caption = StringProperty("")
    value = StringProperty("")
    tint = ColorProperty(C.text)


class DSpinner(Spinner):
    pass


class DInput(TextInput):
    pass


class PillSwitch(ButtonBehavior, Widget):
    """Small toggle switch, amber when on."""

    active = BooleanProperty(False)
    _t = NumericProperty(0)

    def __init__(self, **kw):
        kw.setdefault("size_hint", (None, None))
        kw.setdefault("size", (dp(42), dp(24)))
        super().__init__(**kw)
        self._t = 1 if self.active else 0
        self.bind(pos=self._draw, size=self._draw, _t=self._draw)
        self._draw()

    def on_active(self, *_):
        Animation.cancel_all(self, "_t")
        Animation(_t=1 if self.active else 0, d=0.14, t="out_quad").start(self)

    def on_release(self):
        self.active = not self.active

    def _draw(self, *_):
        self.canvas.clear()
        t = self._t
        off, on = C.line2, C.accent
        col = [off[i] + (on[i] - off[i]) * t for i in range(4)]
        pad = dp(3)
        with self.canvas:
            Color(*col)
            RoundedRectangle(pos=self.pos, size=self.size, radius=[self.height / 2])
            Color(*(C.accent_ink if t > 0.5 else C.text))
            k = self.height - 2 * pad
            kx = self.x + pad + t * (self.width - 2 * pad - k)
            RoundedRectangle(pos=(kx, self.y + pad), size=(k, k), radius=[k / 2])


class Logo(Widget):
    """Three tiny candles (red, green, green)."""

    def __init__(self, **kw):
        kw.setdefault("size_hint", (None, None))
        kw.setdefault("size", (dp(22), dp(22)))
        super().__init__(**kw)
        self.bind(pos=self._draw, size=self._draw)

    def _draw(self, *_):
        self.canvas.clear()
        w, h = self.size
        x0, y0 = self.pos
        bars = [(0.18, 0.30, 0.62, 0.12, 0.80, C.down), (0.5, 0.42, 0.82, 0.30, 0.95, C.up),
                (0.82, 0.20, 0.50, 0.05, 0.62, C.up)]
        with self.canvas:
            for cx, b0, b1, w0, w1, col in bars:
                Color(*col)
                Line(points=[x0 + cx * w, y0 + w0 * h, x0 + cx * w, y0 + w1 * h], width=dp(0.8))
                Rectangle(pos=(x0 + cx * w - w * 0.09, y0 + b0 * h), size=(w * 0.18, (b1 - b0) * h))


class WindowStrip(Widget):
    """04:00-17:00 New York ruler: the window as an amber span, marker ticks
    labelled, hour scale underneath. Values are minutes since midnight."""

    start_min = NumericProperty(7 * 60)
    end_min = NumericProperty(11 * 60)
    markers = ListProperty([7 * 60, 8 * 60, 9 * 60, 9 * 60 + 30])

    def __init__(self, **kw):
        kw.setdefault("size_hint_y", None)
        kw.setdefault("height", dp(46))
        super().__init__(**kw)
        self._labels = []
        self.bind(pos=self._draw, size=self._draw, start_min=self._draw, end_min=self._draw,
                  markers=self._draw)

    def _draw(self, *_):
        for lb in self._labels:
            self.remove_widget(lb)
        self._labels = []
        self.canvas.clear()
        lo = max(0, min(4 * 60, self.start_min - 60) // 60 * 60)
        hi = min(24 * 60, -(-max(17 * 60, self.end_min + 60) // 60) * 60)
        x0, w = self.x + dp(2), self.width - dp(4)
        fx = lambda m: x0 + (m - lo) / (hi - lo) * w  # noqa: E731
        base = self.y + dp(18)
        with self.canvas:
            Color(*C.line2)
            Rectangle(pos=(x0, base), size=(w, 1))
            step = 60 if (hi - lo) <= 14 * 60 else 120
            for m in range(lo, hi + 1, step):
                Rectangle(pos=(fx(m), base - dp(3)), size=(1, dp(3)))
            a, b = fx(self.start_min), fx(self.end_min)
            Color(*C.accent_soft)
            Rectangle(pos=(a, base + 1), size=(max(b - a, 1), dp(18)))
            Color(*C.accent)
            Rectangle(pos=(a, base + 1), size=(max(b - a, 1), dp(2)))
            for m in self.markers:
                if self.start_min <= m <= self.end_min:
                    Color(*(C.accent if m == 570 else C.text))
                    Rectangle(pos=(fx(m), base + 1), size=(1, dp(22)))
        for m in range(lo, hi + 1, 60 if (hi - lo) <= 14 * 60 else 120):
            lb = Label(text=f"{m // 60:02d}", font_name=MONO, font_size=sp(10), color=C.faint,
                       size_hint=(None, None), size=(dp(20), dp(14)), center_x=fx(m), y=self.y)
            self.add_widget(lb)
            self._labels.append(lb)


class DayHeatmap(Widget):
    """Calendar heatmap of the selected range: one column per week, Mon-Fri rows.

    ok days are green/red by window return (intensity = size of the move),
    holidays are outlined amber, days without data are hatched grey. Tap an ok
    day to select it (``select_cb(iso_date)``).
    """

    days = ListProperty([])
    selected = StringProperty("")
    avail_width = NumericProperty(dp(300))
    select_cb = ObjectProperty(None, allownone=True)

    LABEL_W = dp(18)
    TOP_H = dp(16)

    def __init__(self, **kw):
        kw.setdefault("size_hint", (None, None))
        super().__init__(**kw)
        self._labels = []
        self._cells = {}
        self._redraw = Clock.create_trigger(self._draw, 0)  # never draw re-entrantly
        self.bind(days=self._redraw, selected=self._redraw, avail_width=self._redraw, pos=self._redraw,
                  size=self._redraw)

    def _geometry(self):
        first = date.fromisoformat(self.days[0]["date"])
        monday0 = first.toordinal() - first.weekday()
        last = date.fromisoformat(self.days[-1]["date"])
        ncols = (last.toordinal() - monday0) // 7 + 1
        gap = dp(3)
        cell = (self.avail_width - self.LABEL_W) / max(ncols, 1) - gap
        cell = max(dp(9), min(dp(22), cell))
        return monday0, cell, gap, ncols

    def _draw(self, *_):
        for lb in self._labels:
            self.remove_widget(lb)
        self._labels, self._cells = [], {}
        self.canvas.clear()
        if not self.days:
            self.size = (self.avail_width, dp(10))
            return
        monday0, cell, gap, ncols = self._geometry()
        size = (max(self.avail_width, self.LABEL_W + ncols * (cell + gap)), self.TOP_H + 5 * (cell + gap))
        if tuple(self.size) != size:
            self.size = size  # pos/size change re-triggers a clean redraw next frame
            return
        top = self.top - self.TOP_H
        mx = max((abs(d.get("chg", 0)) for d in self.days if d["kind"] == "ok"), default=0) or 1
        months_seen = set()
        with self.canvas:
            for d in self.days:
                dd = date.fromisoformat(d["date"])
                col = (dd.toordinal() - monday0) // 7
                row = dd.weekday()
                x = self.x + self.LABEL_W + col * (cell + gap)
                y = top - (row + 1) * (cell + gap) + gap
                self._cells[d["date"]] = (x, y, cell, d)
                kind = d["kind"]
                if kind == "ok":
                    base = C.up if d["chg"] >= 0 else C.down
                    a = 0.28 + 0.72 * min(1.0, abs(d["chg"]) / mx) ** 0.7
                    Color(base[0], base[1], base[2], a)
                    Rectangle(pos=(x, y), size=(cell, cell))
                elif kind == "holiday":
                    Color(*C.accent)
                    Line(rectangle=(x + 0.5, y + 0.5, cell - 1, cell - 1), width=dp(0.7))
                else:  # nodata
                    Color(*C.raised)
                    Rectangle(pos=(x, y), size=(cell, cell))
                    Color(*C.line2)
                    Line(points=[x + 1, y + 1, x + cell - 1, y + cell - 1], width=dp(0.6))
                if d["date"] == self.selected:
                    Color(*C.text)
                    Line(rectangle=(x - dp(1.5), y - dp(1.5), cell + dp(3), cell + dp(3)), width=dp(1.1))
                key = (dd.year, dd.month)
                if key not in months_seen:
                    months_seen.add(key)
                    self._label(str(dd.year) if (dd.month == 1 and len(months_seen) > 1) else dd.strftime("%b"),
                                x, top + dp(1))
        for r, wd in enumerate("MTWTF"):
            self._label(wd, self.x, top - (r + 1) * (cell + gap) + gap + cell / 2 - dp(7), halign="left")

    def _label(self, text, x, y, halign="left"):
        lb = Label(text=text, font_name=MONO, font_size=sp(10), color=C.faint, size_hint=(None, None),
                   size=(dp(40), dp(14)), pos=(x, y), halign=halign, valign="middle")
        lb.text_size = lb.size
        self.add_widget(lb)
        self._labels.append(lb)

    def on_touch_down(self, touch):
        if not self.collide_point(*touch.pos):
            return False
        for iso, (x, y, cell, d) in self._cells.items():
            if x - 2 <= touch.x <= x + cell + 2 and y - 2 <= touch.y <= y + cell + 2:
                if d["kind"] == "ok":
                    self.selected = iso
                    if self.select_cb:
                        self.select_cb(iso)
                return True
        return False


# --------------------------------------------------------------------------- #
# sheets (modal dialogs)
# --------------------------------------------------------------------------- #
class Sheet(ModalView):
    """Centered panel on a dimmed backdrop, no default Kivy chrome."""

    def __init__(self, title="", max_width=dp(520), **kw):
        kw.setdefault("size_hint", (None, None))
        super().__init__(background_color=C.clear, overlay_color=(0, 0, 0, 0.7), **kw)
        from kivy.factory import Factory

        self.max_width = max_width
        self.card = Factory.SheetCard()
        if title:
            t = Label(text=title, font_name=MONO, font_size=sp(13), color=C.muted, size_hint_y=None,
                      height=dp(22), halign="left", valign="middle")
            t.bind(size=lambda l, s: setattr(l, "text_size", s))
            self.card.add_widget(t)
        self.add_widget(self.card)
        from kivy.core.window import Window

        self._fit(Window, Window.size)
        Window.bind(size=self._fit)

    def _fit(self, win, size):
        self.width = min(size[0] - dp(24), self.max_width)

    def fit_height(self, h):
        from kivy.core.window import Window

        self.height = min(h, Window.height - dp(40))

    def on_dismiss(self):
        from kivy.core.window import Window

        Window.unbind(size=self._fit)


def message(title: str, text: str, on_ok=None, ok_text="OK", cancel_text=None):
    sh = Sheet(title=title.upper(), auto_dismiss=cancel_text is None)
    body = Body(text=text, color=C.text, font_size=sp(15), font_name="Roboto")
    sh.card.add_widget(body)
    row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(10))
    if cancel_text:
        row.add_widget(GhostButton(text=cancel_text, height=dp(48), on_release=lambda *_: sh.dismiss()))

    def ok(*_):
        sh.dismiss()
        if on_ok:
            on_ok()

    row.add_widget(PrimaryButton(text=ok_text, height=dp(48), on_release=ok))
    sh.card.add_widget(row)

    def size_it(*_):
        sh.fit_height(body.height + dp(22) + dp(48) + dp(36) + dp(24))

    body.bind(height=size_it)
    size_it()
    sh.open()
    return sh


class DatePickerSheet(Sheet):
    def __init__(self, initial: date, on_pick, data_range=None, holiday_fn=None, title="SELECT DATE", **kw):
        super().__init__(title=title, max_width=dp(420), **kw)
        self.on_pick_cb, self.sel, self.data_range, self.holiday_fn = on_pick, initial, data_range, holiday_fn
        self.view = date(initial.year, initial.month, 1)
        lo = data_range[0].year if data_range else initial.year - 5
        hi = data_range[1].year if data_range else date.today().year
        card = self.card

        head = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        head.add_widget(GhostButton(text="‹", font_size=sp(18), size_hint_x=None, width=dp(44),
                                    on_release=lambda *_: self.shift(-1)))
        self.month_sp = DSpinner(text=calendar.month_name[self.view.month], values=list(calendar.month_name)[1:])
        self.year_sp = DSpinner(text=str(self.view.year), size_hint_x=0.7,
                                values=[str(y) for y in range(max(hi, initial.year), min(lo, initial.year) - 1, -1)])
        self.month_sp.bind(text=lambda *_: self._spin())
        self.year_sp.bind(text=lambda *_: self._spin())
        head.add_widget(self.month_sp)
        head.add_widget(self.year_sp)
        head.add_widget(GhostButton(text="›", font_size=sp(18), size_hint_x=None, width=dp(44),
                                    on_release=lambda *_: self.shift(1)))
        card.add_widget(head)

        self.grid = GridLayout(cols=7, spacing=dp(3), size_hint_y=None, height=dp(18) + 6 * dp(43))
        card.add_widget(self.grid)
        card.add_widget(Label(text="[color=f2a93b]□[/color] US market holiday   [color=5b5e65]dim = weekend / no data[/color]",
                              markup=True, font_name=MONO, font_size=sp(11), color=C.faint,
                              size_hint_y=None, height=dp(16)))
        foot = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(8))
        if data_range:
            foot.add_widget(GhostButton(text="first data", height=dp(42), on_release=lambda *_: self.pick(data_range[0])))
            foot.add_widget(GhostButton(text="last data", height=dp(42), on_release=lambda *_: self.pick(data_range[1])))
        foot.add_widget(GhostButton(text="cancel", height=dp(42), on_release=lambda *_: self.dismiss()))
        card.add_widget(foot)
        self.fit_height(dp(22) + dp(44) + self.grid.height + dp(16) + dp(42) + 4 * dp(12) + dp(36))
        self._render()

    def _spin(self):
        try:
            m = list(calendar.month_name).index(self.month_sp.text)
            self.view = date(int(self.year_sp.text), m, 1)
        except ValueError:
            return
        self._render()

    def shift(self, months):
        y, m = divmod(self.view.year * 12 + self.view.month - 1 + months, 12)
        self.view = date(y, m + 1, 1)
        if str(self.view.year) not in self.year_sp.values:
            self.year_sp.values = sorted(set(self.year_sp.values) | {str(self.view.year)}, reverse=True)
        self.month_sp.text = calendar.month_name[self.view.month]
        self.year_sp.text = str(self.view.year)
        self._render()

    def _render(self):
        g = self.grid
        g.clear_widgets()
        for wd in ("Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"):
            g.add_widget(Label(text=wd, color=C.faint, font_name=MONO, font_size=sp(11),
                               size_hint_y=None, height=dp(18)))
        first = self.view
        lead = first.weekday()
        ndays = calendar.monthrange(first.year, first.month)[1]
        for _ in range(lead):
            g.add_widget(Widget(size_hint_y=None, height=dp(40)))
        for day in range(1, ndays + 1):
            d = date(first.year, first.month, day)
            in_data = not self.data_range or self.data_range[0] <= d <= self.data_range[1]
            hol = self.holiday_fn(d) if self.holiday_fn else None
            selected = d == self.sel
            dim = d.weekday() >= 5 or not in_data
            b = RButton(text=str(day), height=dp(40), radius=dp(4), font_size=sp(14),
                        bg=C.accent if selected else C.clear, bg_down=C.hover,
                        outline=C.accent if (hol and not selected) else C.clear,
                        fg=C.accent_ink if selected else (C.faint if dim else C.text), bold=selected)
            b.bind(on_release=lambda _b, d=d: self.pick(d))
            g.add_widget(b)
        for _ in range(42 - lead - ndays):
            g.add_widget(Widget(size_hint_y=None, height=dp(40)))

    def pick(self, d):
        self.dismiss()
        self.on_pick_cb(d)


class TimePickerSheet(Sheet):
    """Large HH:MM readout, +/- steppers, presets."""

    PRESETS = ["06:00", "07:00", "08:00", "09:00", "09:30", "10:00", "11:00", "12:00", "16:00", "17:00"]

    def __init__(self, initial: str, on_pick, title="TIME · NEW YORK", **kw):
        super().__init__(title=title, max_width=dp(400), **kw)
        hh, mm = (int(x) for x in initial.split(":"))
        self.minutes = hh * 60 + mm
        card = self.card
        self.display = Label(font_name=MONO, font_size=sp(46), bold=True, color=C.text,
                             size_hint_y=None, height=dp(62))
        card.add_widget(self.display)
        row = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(6))
        for txt, delta in (("-1h", -60), ("-5m", -5), ("+5m", 5), ("+1h", 60)):
            row.add_widget(GhostButton(text=txt, height=dp(42), on_release=lambda *_, d=delta: self.step(d)))
        card.add_widget(row)
        chips = GridLayout(cols=5, spacing=dp(6), size_hint_y=None, height=dp(32) * 2 + dp(6))
        self._chips = []
        for p in self.PRESETS:
            c = Chip(text=p, group=f"tp{id(self)}", allow_no_selection=True)
            c.bind(on_release=lambda _c, p=p: self.set(p))
            chips.add_widget(c)
            self._chips.append(c)
        card.add_widget(chips)
        foot = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(10))
        foot.add_widget(GhostButton(text="cancel", height=dp(48), on_release=lambda *_: self.dismiss()))
        foot.add_widget(PrimaryButton(text="set", height=dp(48),
                                      on_release=lambda *_: (self.dismiss(), on_pick(self.text()))))
        card.add_widget(foot)
        self.fit_height(dp(22) + dp(62) + dp(42) + chips.height + dp(48) + 4 * dp(12) + dp(36))
        self._update()

    def text(self):
        return f"{self.minutes // 60:02d}:{self.minutes % 60:02d}"

    def step(self, d):
        self.minutes = (self.minutes + d) % (24 * 60)
        self._update()

    def set(self, s):
        h, m = s.split(":")
        self.minutes = int(h) * 60 + int(m)
        self._update()

    def _update(self):
        self.display.text = self.text()
        for c in self._chips:
            c.state = "down" if c.text == self.text() else "normal"


# --------------------------------------------------------------------------- #
# pinch-zoom viewer
# --------------------------------------------------------------------------- #
class ZoomView(StencilView):
    """Pinch / wheel zoom + pan of a single image. Swipe when not zoomed to
    navigate; double-tap toggles zoom."""

    source = StringProperty("")
    swipe_cb = ObjectProperty(None, allownone=True)  # callable(direction: +1/-1)
    zoomed = BooleanProperty(False)
    max_scale = NumericProperty(10)

    def __init__(self, **kw):
        super().__init__(**kw)
        self.scatter = Scatter(do_rotation=False, scale_min=1, scale_max=self.max_scale, auto_bring_to_front=False)
        self.image = Image(fit_mode="contain", nocache=True)
        self.scatter.add_widget(self.image)
        self.add_widget(self.scatter)
        self.bind(size=self._reset, pos=self._reset, source=self._load)
        self.scatter.bind(on_transform_with_touch=lambda *_: self._clamp())
        if self.source:  # source given at creation time
            self._load()

    def _load(self, *_):
        self.image.source = self.source
        self._reset()

    def _reset(self, *_):
        self.scatter.transform = Matrix()
        self.scatter.size = self.size
        self.image.size = self.size
        self.scatter.pos = self.pos
        self.zoomed = False

    def _clamp(self):
        s = self.scatter
        if s.scale <= 1.001:
            s.pos = self.pos
            self.zoomed = False
            return
        self.zoomed = True
        w, h = self.width * s.scale, self.height * s.scale
        x = min(self.x, max(s.x, self.right - w))
        y = min(self.y, max(s.y, self.top - h))
        s.pos = (x, y)

    def on_touch_down(self, touch):
        if not self.collide_point(*touch.pos):
            return False
        if touch.is_mouse_scrolling:
            f = 1.15 if touch.button == "scrolldown" else 1 / 1.15
            new = min(max(self.scatter.scale * f, 1), self.max_scale)
            f = new / self.scatter.scale
            self.scatter.apply_transform(Matrix().scale(f, f, f), anchor=self.scatter.to_local(*touch.pos))
            self._clamp()
            return True
        if touch.is_double_tap:
            if self.zoomed:
                self._reset()
            else:
                self.scatter.apply_transform(Matrix().scale(2.5, 2.5, 2.5),
                                             anchor=self.scatter.to_local(*touch.pos))
                self._clamp()
            return True
        touch.ud["zv_start"] = (touch.x, self.zoomed)
        return super().on_touch_down(touch)

    def on_touch_up(self, touch):
        st = touch.ud.get("zv_start")
        res = super().on_touch_up(touch)
        if st and not st[1] and not self.zoomed:
            dx = touch.x - st[0]
            self._reset()
            if abs(dx) > max(dp(70), self.width * 0.12) and self.swipe_cb:
                self.swipe_cb(-1 if dx > 0 else 1)
        return res


global_idmap["C"] = C
global_idmap["MONO"] = MONO
Builder.load_string(KV)
