"""Backtest screens: inputs -> (progress) -> results with Summary / Trades tabs,
CSV + PDF export to Downloads/NQES_Backtest/<instrument>_<start>_to_<end>/."""

from __future__ import annotations

import os
import threading
import traceback
from datetime import date

from kivy.app import App
from kivy.clock import Clock, mainthread
from kivy.lang import Builder
from kivy.metrics import dp, sp
from kivy.properties import BooleanProperty, ColorProperty, ListProperty, NumericProperty, StringProperty
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.image import Image as KivyImage
from kivy.uix.screenmanager import Screen

from .. import backtest as bt
from ..platform_io import app_storage_dir, is_android
from .widgets import C, MONO, Sheet, ZoomView, message

ANDROID = is_android()

KV = r"""
<TradeRow>:
    size_hint_y: None
    height: dp(40)
    padding: dp(10), 0
    spacing: dp(6)
    canvas.before:
        Color:
            rgba: C.hover if self.state == "down" else (C.panel if self.index % 2 else C.bg)
        Rectangle:
            pos: self.pos
            size: self.size
    Label:
        text: root.when
        font_name: MONO
        font_size: sp(12)
        color: C.text
        size_hint_x: 1.25
        text_size: self.size
        halign: "left"
        valign: "middle"
    Label:
        text: root.contract
        font_name: MONO
        font_size: sp(12)
        color: C.muted
        size_hint_x: 0.8
        text_size: self.size
        halign: "left"
        valign: "middle"
    Label:
        text: root.direction
        font_size: sp(13)
        color: C.text
        size_hint_x: 0.7
        text_size: self.size
        halign: "left"
        valign: "middle"
    Label:
        text: root.outcome
        font_size: sp(13)
        bold: True
        color: root.tint
        size_hint_x: 1.1
        text_size: self.size
        halign: "left"
        valign: "middle"
    Label:
        text: root.sl_pts
        font_name: MONO
        font_size: sp(12)
        color: C.text
        size_hint_x: 0.75
        text_size: self.size
        halign: "right"
        valign: "middle"
    Label:
        text: root.tp_pts
        font_name: MONO
        font_size: sp(12)
        color: C.text
        size_hint_x: 0.75
        text_size: self.size
        halign: "right"
        valign: "middle"

<BtHead@Label>:
    font_size: sp(11)
    bold: True
    color: C.muted
    text_size: self.size
    valign: "middle"

<BacktestScreen>:
    canvas.before:
        Color:
            rgba: C.bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: "vertical"
        AppBar:
            GhostButton:
                text: "‹  Back"
                size_hint_x: None
                width: dp(92)
                height: dp(40)
                pos_hint: {"center_y": .5}
                on_release: app.go("home")
            Title:
                text: "Backtest"
            Widget:
            GhostButton:
                text: "Strategy rules"
                size_hint_x: None
                width: dp(132)
                height: dp(40)
                pos_hint: {"center_y": .5}
                on_release: root.show_rules()
        ScrollView:
            do_scroll_x: False
            bar_width: dp(3)
            BoxLayout:
                orientation: "vertical"
                size_hint_y: None
                height: self.minimum_height
                padding: max(dp(14), (self.width - dp(760)) / 2), dp(14), max(dp(14), (self.width - dp(760)) / 2), dp(24)
                spacing: dp(14)
                Help:
                    text: "Tests the pre-market sweep + fair value gap strategy on your data: one limit order a day at most, 07:00 to 11:00 New York time. Tap [b]Strategy rules[/b] to read exactly how it works."
                    font_size: sp(15)
                    color: C.text
                StepCard:
                    num: "1"
                    title: "Your data"
                    done: app.data_state == "ready"
                    active: app.data_state != "ready"
                    Help:
                        text: app.data_status
                    BoxLayout:
                        size_hint_y: None
                        height: dp(46) if app.data_state != "ready" else 0
                        opacity: 1 if app.data_state != "ready" else 0
                        disabled: app.data_state == "ready"
                        spacing: dp(10)
                        PrimaryButton:
                            text: "Choose my CSV file"
                            height: dp(46)
                            font_size: sp(15)
                            on_release: app.pick_csv()
                        PrimaryButton:
                            text: "Prepare data"
                            height: dp(46)
                            font_size: sp(15)
                            size_hint_x: 1 if app.data_state == "dirty" else 0.001
                            opacity: 1 if app.data_state == "dirty" else 0
                            disabled: app.data_state != "dirty"
                            on_release: app.prepare_data()
                StepCard:
                    num: "2"
                    title: "Instrument"
                    done: app.has_data
                    GridLayout:
                        cols: 2
                        spacing: dp(10)
                        size_hint_y: None
                        height: dp(84)
                        MarketTile:
                            code: "NQ"
                            name: "Nasdaq-100 futures"
                            info: app.nq_info
                            available: bool(app.nq_info) and not app.nq_info.startswith("no")
                            selected: app.instrument == "NQ"
                            on_release: app.set_instrument("NQ")
                        MarketTile:
                            code: "ES"
                            name: "S&P 500 futures"
                            info: app.es_info
                            available: bool(app.es_info) and not app.es_info.startswith("no")
                            selected: app.instrument == "ES"
                            on_release: app.set_instrument("ES")
                StepCard:
                    num: "3"
                    title: "Date range"
                    done: app.has_data
                    GridLayout:
                        cols: 2 if self.width > dp(330) else 1
                        spacing: dp(10)
                        size_hint_y: None
                        height: self.minimum_height
                        row_default_height: dp(62)
                        row_force_default: True
                        BigField:
                            caption: "Start date"
                            value: app.start_label
                            on_release: app.pick_date("start")
                        BigField:
                            caption: "End date"
                            value: app.end_label
                            on_release: app.pick_date("end")
                    StackLayout:
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(8)
                        PresetChip:
                            text: "Last month"
                            selected: app.range_preset == "1M"
                            on_release: app.quick_range(31)
                        PresetChip:
                            text: "Last 3 months"
                            selected: app.range_preset == "3M"
                            on_release: app.quick_range(92)
                        PresetChip:
                            text: "This year"
                            selected: app.range_preset == "YTD"
                            on_release: app.quick_range("ytd")
                        PresetChip:
                            text: "Last year"
                            selected: app.range_preset == "1Y"
                            on_release: app.quick_range(365)
                        PresetChip:
                            text: "All data"
                            selected: app.range_preset == "ALL"
                            on_release: app.quick_range("all")
                StepCard:
                    num: "4"
                    title: "Entry model"
                    done: True
                    Segmented:
                        height: dp(44)
                        SegButton:
                            text: "Model 1"
                            group: "bt_model"
                            state: "down" if root.model == 1 else "normal"
                            on_release: root.model = 1
                        SegButton:
                            text: "Model 2"
                            group: "bt_model"
                            state: "down" if root.model == 2 else "normal"
                            on_release: root.model = 2
                    Help:
                        text: ("[b]Model 1:[/b] entry at the [b]open of candle 3[/b] of the gap." if root.model == 1 else "[b]Model 2:[/b] entry at the [b]edge of the gap[/b]: low of candle 3 for a long, high of candle 3 for a short.") + " Stop loss at the low (long) / high (short) of candle 2."
                StepCard:
                    num: "5"
                    title: "Risk to reward"
                    done: root.rr_ok
                    BoxLayout:
                        size_hint_y: None
                        height: dp(48)
                        spacing: dp(10)
                        DInput:
                            text: root.rr_text
                            input_filter: "float"
                            hint_text: "for example 2"
                            font_size: sp(18)
                            size_hint_x: 0.4
                            on_text: root.rr_text = self.text
                        StackLayout:
                            spacing: dp(6)
                            PresetChip:
                                text: "1"
                                selected: root.rr_text == "1"
                                on_release: root.rr_text = "1"
                            PresetChip:
                                text: "1.5"
                                selected: root.rr_text == "1.5"
                                on_release: root.rr_text = "1.5"
                            PresetChip:
                                text: "2"
                                selected: root.rr_text == "2"
                                on_release: root.rr_text = "2"
                            PresetChip:
                                text: "3"
                                selected: root.rr_text == "3"
                                on_release: root.rr_text = "3"
                    Help:
                        text: "Take profit = entry ± RR × the distance from entry to stop loss. " + ("" if root.rr_ok else "[color=f2a93b]Type a number above 0.[/color]")
                StepCard:
                    num: "6"
                    title: "Order and breakeven management"
                    done: True
                    BoxLayout:
                        size_hint_y: None
                        height: dp(42)
                        Help:
                            text: "Cancel Entry If TP Is Hit Before Entry"
                            color: C.text
                        PillSwitch:
                            active: root.cancel_tp_before_entry
                            on_active: root.cancel_tp_before_entry = self.active
                    BoxLayout:
                        size_hint_y: None
                        height: dp(42)
                        Help:
                            text: "Enable Breakeven"
                            color: C.text
                        PillSwitch:
                            active: root.be_enabled
                            on_active: root.be_enabled = self.active
                    BoxLayout:
                        size_hint_y: None
                        height: dp(44) if root.be_enabled else 0
                        opacity: 1 if root.be_enabled else 0
                        spacing: dp(10)
                        Help:
                            text: "Move SL to Breakeven At (R)"
                            color: C.text
                        DInput:
                            text: root.be_text
                            input_filter: "float"
                            hint_text: "e.g. 1.5"
                            font_size: sp(17)
                            on_text: root.be_text = self.text
                    Help:
                        text: "BE exits are recorded as 0R. If trigger and stop/target occur in one candle, the engine uses a conservative OHLC assumption."
                PrimaryButton:
                    text: "Run backtest" if app.data_state == "ready" else "Add your data first (step 1)"
                    disabled: not (app.data_state == "ready" and root.rr_ok)
                    on_release: root.run()

<BacktestResultScreen>:
    canvas.before:
        Color:
            rgba: C.bg
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: "vertical"
        AppBar:
            GhostButton:
                text: "‹  Settings"
                size_hint_x: None
                width: dp(112)
                height: dp(40)
                pos_hint: {"center_y": .5}
                on_release: app.go("backtest")
            Title:
                text: "Results"
            Widget:
            GhostButton:
                text: "Rules"
                size_hint_x: None
                width: dp(76)
                height: dp(40)
                pos_hint: {"center_y": .5}
                on_release: app.sm.get_screen("backtest").show_rules()
        BoxLayout:
            orientation: "vertical"
            size_hint_y: None
            height: dp(104)
            padding: dp(14), dp(10), dp(14), dp(8)
            spacing: dp(8)
            Label:
                text: root.header
                markup: True
                font_size: sp(14)
                color: C.muted
                size_hint_y: None
                height: dp(22)
                text_size: self.size
                halign: "left"
                valign: "middle"
                shorten: True
            Segmented:
                height: dp(44)
                SegButton:
                    text: "Summary"
                    group: "bt_tab"
                    state: "down" if root.tab == "summary" else "normal"
                    on_release: root.tab = "summary"
                SegButton:
                    text: "Trades (" + str(len(root.rows)) + ")"
                    group: "bt_tab"
                    state: "down" if root.tab == "trades" else "normal"
                    on_release: root.tab = "trades"
        FloatLayout:
            ScrollView:
                do_scroll_x: False
                bar_width: dp(3)
                pos_hint: {"x": 0, "y": 0}
                opacity: 1 if root.tab == "summary" else 0
                disabled: root.tab != "summary"
                size_hint: (1, 1) if root.tab == "summary" else (0, 0)
                BoxLayout:
                    orientation: "vertical"
                    size_hint_y: None
                    height: self.minimum_height
                    padding: max(dp(14), (self.width - dp(760)) / 2), dp(6), max(dp(14), (self.width - dp(760)) / 2), dp(24)
                    spacing: dp(14)
                    StepCard:
                        title: root.winrate_text
                        help: root.wl_text
                        GridLayout:
                            id: summary_grid
                            cols: 1
                            size_hint_y: None
                            height: self.minimum_height
                    StepCard:
                        title: "Save"
                        help: "Files go to the [b]Download/NQES_Backtest[/b] folder on this phone."
                        PrimaryButton:
                            text: "Download CSV (trade table + day log)"
                            font_size: sp(15)
                            disabled: not root.rows
                            on_release: root.save_csv()
                        BoxLayout:
                            size_hint_y: None
                            height: dp(44)
                            spacing: dp(10)
                            Help:
                                text: "Include cancelled orders in the PDF"
                                color: C.text
                                pos_hint: {"center_y": .5}
                            PillSwitch:
                                active: root.include_cancelled
                                pos_hint: {"center_y": .5}
                                on_active: root.include_cancelled = self.active
                        PrimaryButton:
                            text: "Download PDF of charts (" + str(root.pdf_pages) + " pages)"
                            font_size: sp(15)
                            disabled: not root.pdf_pages
                            on_release: root.save_pdf()
                        Help:
                            text: root.saved_text
                            opacity: 1 if root.saved_text else 0
                            height: self.texture_size[1] if root.saved_text else 0
                        TextButton:
                            text: "Open " + root.last_kind
                            height: dp(34) if root.last_uri else 0
                            opacity: 1 if root.last_uri else 0
                            disabled: not root.last_uri
                            on_release: root.open_last()
            BoxLayout:
                orientation: "vertical"
                pos_hint: {"x": 0, "y": 0}
                opacity: 1 if root.tab == "trades" else 0
                disabled: root.tab != "trades"
                size_hint: (1, 1) if root.tab == "trades" else (0, 0)
                BoxLayout:
                    size_hint_y: None
                    height: dp(34)
                    padding: dp(10), 0
                    spacing: dp(6)
                    canvas.before:
                        Color:
                            rgba: C.raised
                        Rectangle:
                            pos: self.pos
                            size: self.size
                    BtHead:
                        text: "Date"
                        size_hint_x: 1.25
                        halign: "left"
                    BtHead:
                        text: "Contract"
                        size_hint_x: 0.8
                        halign: "left"
                    BtHead:
                        text: "Side"
                        size_hint_x: 0.7
                        halign: "left"
                    BtHead:
                        text: "Outcome"
                        size_hint_x: 1.1
                        halign: "left"
                    BtHead:
                        text: "SL pts"
                        size_hint_x: 0.75
                        halign: "right"
                    BtHead:
                        text: "TP pts"
                        size_hint_x: 0.75
                        halign: "right"
                RecycleView:
                    viewclass: "TradeRow"
                    data: root.rows
                    bar_width: dp(3)
                    RecycleBoxLayout:
                        orientation: "vertical"
                        default_size: None, dp(40)
                        default_size_hint: 1, None
                        size_hint_y: None
                        height: self.minimum_height
                Label:
                    text: "Tap a trade to see its chart. Table lists filled trades; cancelled orders are in the CSV day log."
                    font_size: sp(12)
                    color: C.faint
                    size_hint_y: None
                    height: dp(30)
"""

OUTCOME_TINT = {bt.WIN: C.up, bt.LOSE: C.down, bt.BREAKEVEN: C.accent, bt.BOTH: C.accent, bt.OPEN: (0.36, 0.55, 1, 1)}
OUTCOME_SHORT = {bt.WIN: "Win", bt.LOSE: "Lose", bt.BREAKEVEN: "Breakeven", bt.BOTH: "Both Hit", bt.OPEN: "Open 11:00"}


def load_kv():
    Builder.load_string(KV)


def _publish(local, rel_dir, name, mime):
    if ANDROID:
        from ..platform_io.android_io import publish_download

        return publish_download(local, rel_dir, name, mime)
    from ..platform_io.desktop_io import publish_download

    return publish_download(local, rel_dir, name, mime)


def _toast(text):
    if ANDROID:
        from ..platform_io.android_io import toast

        toast(text)


class TradeRow(ButtonBehavior, BoxLayout):
    index = NumericProperty(0)
    when = StringProperty("")
    contract = StringProperty("")
    direction = StringProperty("")
    outcome = StringProperty("")
    tint = ColorProperty(C.text)
    sl_pts = StringProperty("")
    tp_pts = StringProperty("")

    def on_release(self):
        App.get_running_app().sm.get_screen("bt_results").show_trade(self.index)


class BacktestScreen(Screen):
    model = NumericProperty(1)
    rr_text = StringProperty("2")
    rr_ok = BooleanProperty(True)
    cancel_tp_before_entry = BooleanProperty(True)
    be_enabled = BooleanProperty(False)
    be_text = StringProperty("1")

    def on_rr_text(self, *_):
        try:
            self.rr_ok = float(self.rr_text) > 0
        except ValueError:
            self.rr_ok = False

    def show_rules(self):
        message("Strategy rules", bt.RULES_TEXT, ok_text="Close")

    def run(self):
        app = App.get_running_app()
        try:
            rr = float(self.rr_text)
            be_trigger = float(self.be_text) if self.be_enabled else None
            if self.be_enabled and be_trigger <= 0:
                raise ValueError("Breakeven trigger must be above 0R.")
            start, end = date.fromisoformat(app.start_date), date.fromisoformat(app.end_date)
            store = app._store()
            if store is None:
                raise ValueError("Add and prepare your data first (step 1).")
            if rr <= 0:
                raise ValueError("Risk to reward must be above 0.")
        except ValueError as exc:
            message("Can't run the backtest", str(exc))
            return
        inst, model, skip = app.instrument, self.model, app.skip_holidays
        prog = app.sm.get_screen("progress")
        prog.start(f"Backtesting {inst}", f"Model {model}, RR {rr:g}, {start.isoformat()} to {end.isoformat()}")
        app._begin_job()

        def work():
            try:
                res = bt.run_backtest(store, inst, start, end, model, rr, skip_holidays=skip,
                                      progress=lambda f, t: app._progress(f, t), cancel=app.cancel_event,
                                      cancel_tp_before_entry=self.cancel_tp_before_entry, be_trigger=be_trigger)
                self._done(res, None)
            except Exception as exc:
                traceback.print_exc()
                self._done(None, exc)

        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _done(self, res, exc):
        app = App.get_running_app()
        if exc is not None or res is None or res.cancelled:
            app._finish(f"[color=ef4444][b]Backtest stopped[/b][/color]\n{exc or 'Cancelled.'}")
            return
        app.busy = False
        if ANDROID:
            from ..platform_io.android_io import keep_screen_on

            keep_screen_on(False)
        try:
            from ..run_history import save_run
            snapshot = save_run(res, app_storage_dir())
            res.run_id = os.path.splitext(os.path.basename(snapshot))[0]
            print("Saved immutable backtest snapshot:", snapshot)
        except Exception:
            traceback.print_exc()
        app.sm.get_screen("bt_results").show(res)
        app.go("bt_results")
        if not res.trades:
            message("No trades found", "No limit orders were placed in this date range. Check the date "
                    "range and that your data covers 07:00 to 11:00 New York time on those days.")


class BacktestResultScreen(Screen):
    tab = StringProperty("summary")
    header = StringProperty("")
    winrate_text = StringProperty("")
    wl_text = StringProperty("")
    rows = ListProperty([])
    pdf_pages = NumericProperty(0)
    include_cancelled = BooleanProperty(False)
    saved_text = StringProperty("")
    last_uri = StringProperty("")
    last_kind = StringProperty("")
    result = None

    def on_include_cancelled(self, *_):
        self._count_pages()

    def _count_pages(self):
        r = self.result
        self.pdf_pages = 0 if r is None else sum(1 for t in r.trades if t.status == "filled" or self.include_cancelled)

    def show(self, res: bt.BacktestResult):
        self.result, self.tab, self.saved_text, self.last_uri = res, "summary", "", ""
        s = res.summary
        d0, d1 = date.fromisoformat(res.start), date.fromisoformat(res.end)
        self.header = (f"[b]{res.instrument}[/b]  {d0.strftime('%b')} {d0.day}, {d0.year} – {d1.strftime('%b')} {d1.day}, "
                       f"{d1.year}  ·  Model {res.model}  ·  RR {res.rr:g}  ·  Cancel TP-before-entry: {'ON' if res.cancel_tp_before_entry else 'OFF'}  ·  BE: {res.be_trigger if res.be_trigger is not None else 'OFF'}")
        wr = s["win_rate"]
        self.winrate_text = f"{wr * 100:.1f}% win rate" if wr is not None else "No wins or losses yet"
        self.wl_text = (f"{s['wins']} take profits and {s['losses']} stop losses out of {s['filled']} filled trades "
                        f"({s['orders']} limit orders).")
        g = self.ids.summary_grid
        g.clear_widgets()
        from .. import advanced_analytics as analytics
        self.analytics = analytics.equity_metrics(res.trades)
        extra = [
            ("Net profit", f"{self.analytics['net_r']:.2f}R"),
            ("Gross profit", f"{self.analytics['gross_profit_r']:.2f}R"),
            ("Gross loss", f"{self.analytics['gross_loss_r']:.2f}R"),
            ("Profit factor", "∞" if self.analytics["profit_factor"] == float("inf") else (f"{self.analytics['profit_factor']:.2f}" if self.analytics["profit_factor"] is not None else "–")),
            ("Expectancy", f"{self.analytics['expectancy_r']:.3f}R / trade"),
            ("Average win", f"{self.analytics['average_win_r']:.2f}R"),
            ("Average loss", f"{self.analytics['average_loss_r']:.2f}R"),
            ("Maximum drawdown", f"{self.analytics['max_drawdown_r']:.2f}R"),
            ("Maximum drawdown %", f"{self.analytics['max_drawdown_pct']:.2f}%" if self.analytics["max_drawdown_pct"] is not None else "N/A (no positive equity peak)"),
            ("Total trading days", str(self.analytics["total_trading_days"])),
            ("Average trades / day", f"{self.analytics['average_trades_per_day']:.2f}"),
            ("Longest drawdown", f"{self.analytics['longest_drawdown_trades']} trades"),
            ("BE activated", str(sum(1 for t in res.trades if getattr(t, "be_activated", False)))),
            ("BE exits", str(sum(1 for t in res.trades if getattr(t, "outcome", "") == bt.BREAKEVEN))),
        ]
        month_summary = analytics.monthly_summary(res.trades)
        extra.extend([
            ("Best month", month_summary["best_month"] or "–"),
            ("Worst month", month_summary["worst_month"] or "–"),
            ("Average monthly return", f"{month_summary['average_monthly_r']:.2f}R"),
            ("Profitable months", f"{month_summary['profitable_months']} ({month_summary['profitable_month_pct']:.1f}%)" if month_summary["profitable_month_pct"] is not None else "0"),
        ])
        for label, value in bt.summary_lines(s) + extra:
            row = BoxLayout(size_hint_y=None, height=dp(34))
            a = Label(text=label, font_size=sp(14), color=C.muted, halign="left", valign="middle")
            a.bind(size=lambda l, z: setattr(l, "text_size", z))
            b = Label(text=value, font_name=MONO, font_size=sp(14), color=C.text, halign="right", valign="middle")
            b.bind(size=lambda l, z: setattr(l, "text_size", z))
            row.add_widget(a)
            row.add_widget(b)
            g.add_widget(row)
        filled = [t for t in sorted(res.trades, key=lambda t: t.date) if t.status == "filled"]
        self._filled = filled
        self.rows = [{"index": i, "when": f"{t.date[5:]} {t.weekday}", "contract": t.contract,
                      "direction": t.direction, "outcome": OUTCOME_SHORT.get(t.outcome, t.outcome),
                      "tint": OUTCOME_TINT.get(t.outcome, C.text), "sl_pts": f"{t.risk_pts:,.2f}",
                      "tp_pts": f"{t.reward_pts:,.2f}"} for i, t in enumerate(filled)]
        self._count_pages()
        # Render visual analytics off the UI thread; add the PNG previews when ready.
        result_ref = res
        def make_previews():
            try:
                from .. import advanced_analytics as analytics
                chart_dir = os.path.join(app_storage_dir(), "backtest", res.folder_name,
                                         f"preview_model{res.model}_rr{res.rr:g}")
                paths = analytics.render_analytics_charts(res.trades, chart_dir)
                self._add_chart_previews(result_ref, paths)
            except Exception:
                traceback.print_exc()
        threading.Thread(target=make_previews, daemon=True).start()

    @mainthread
    def _add_chart_previews(self, result_ref, paths):
        if self.result is not result_ref:
            return
        g = self.ids.summary_grid
        titles = ("Equity curve", "Monthly performance", "Yearly performance")
        for title, path in zip(titles, paths):
            label = Label(text=title, size_hint_y=None, height=dp(28), color=C.text,
                          bold=True, font_size=sp(14), halign="left")
            label.bind(size=lambda w, z: setattr(w, "text_size", z))
            g.add_widget(label)
            g.add_widget(KivyImage(source=path, size_hint_y=None, height=dp(220),
                                   allow_stretch=True, keep_ratio=True))

    # ---------------- saving
    def _folder(self):
        r = self.result
        local = os.path.join(app_storage_dir(), "backtest", r.folder_name)
        os.makedirs(local, exist_ok=True)
        be_tag = "beoff" if r.be_trigger is None else f"be{r.be_trigger:g}"
        cancel_tag = "cTPon" if r.cancel_tp_before_entry else "cTPoff"
        run_tag = getattr(r, "run_id", "")
        suffix = f"_{run_tag}" if run_tag else ""
        return local, f"NQES_Backtest/{r.folder_name}", f"model{r.model}_rr{r.rr:g}_{be_tag}_{cancel_tag}{suffix}"

    def save_csv(self):
        local, rel, tag = self._folder()
        try:
            from .. import advanced_analytics as analytics
            metrics = analytics.equity_metrics(self.result.trades)
            weekly = analytics.grouped_performance(self.result.trades, "weekly")
            monthly = analytics.grouped_performance(self.result.trades, "monthly")
            yearly = analytics.grouped_performance(self.result.trades, "yearly")
            charts = analytics.render_analytics_charts(self.result.trades, local)
            instrument_rows = []
            for inst, values in analytics.instrument_performance(self.result.trades).items():
                instrument_rows.append({"instrument": inst, **{k:v for k,v in values.items() if k not in ("equity_curve", "drawdown_details")}})
            from ..run_history import compare_runs
            comparison = compare_runs(app_storage_dir(), self.result.instrument)
            comparison_path = os.path.join(local, f"saved_models_comparison_{tag}.csv")
            analytics.write_grouped_csv(comparison, comparison_path)
            files = [
                bt.write_trades_csv(self.result, os.path.join(local, f"trades_{tag}.csv"), include_cancelled=True),
                bt.write_day_log_csv(self.result, os.path.join(local, f"day_log_{tag}.csv")),
                analytics.write_metrics_csv(metrics, os.path.join(local, f"overall_{tag}.csv")),
                analytics.write_grouped_csv(weekly, os.path.join(local, f"weekly_{tag}.csv")),
                analytics.write_grouped_csv(monthly, os.path.join(local, f"monthly_{tag}.csv")),
                analytics.write_grouped_csv(yearly, os.path.join(local, f"yearly_{tag}.csv")),
                analytics.write_equity_csv(metrics, os.path.join(local, f"equity_{tag}.csv")),
                analytics.write_grouped_csv(instrument_rows, os.path.join(local, f"instrument_{tag}.csv")),
                comparison_path,
            ] + charts
            u1 = None
            for fp in files:
                mime = "image/png" if fp.lower().endswith(".png") else "text/csv"
                uri = _publish(fp, rel, os.path.basename(fp), mime)
                if fp == files[0]: u1 = uri
        except Exception as exc:
            traceback.print_exc()
            message("Could not save the CSV", str(exc))
            return
        where = f"Download/{rel}/" if ANDROID else os.path.dirname(u1)
        self.saved_text = f"[color=22c55e]Saved 9 CSV files and 3 charts[/color] (trades, day log, overall, weekly, monthly, yearly, equity, instrument) to [b]{where}[/b]"
        self.last_uri, self.last_kind, self._last_mime = u1, "trades CSV", "text/csv"
        _toast(f"Saved to {where}")

    def save_pdf(self):
        app = App.get_running_app()
        store = app._store()
        local, rel, tag = self._folder()
        name = f"charts_{tag}{'_with_cancelled' if self.include_cancelled else ''}.pdf"
        path = os.path.join(local, name)
        prog = app.sm.get_screen("progress")
        prog.start("Making the PDF", f"{self.pdf_pages} chart pages, one per trade")
        prog.continue_text, prog.continue_target = "Back to results", "bt_results"
        app._begin_job()
        res, inc = self.result, self.include_cancelled

        def work():
            try:
                from ..backtest_report import write_pdf

                _, pages = write_pdf(res, store, path, include_cancelled=inc,
                                     progress=lambda f, t: app._progress(f, t), cancel=app.cancel_event)
                uri = _publish(path, rel, name, "application/pdf")
                where = f"Download/{rel}/" if ANDROID else os.path.dirname(uri)
                self._pdf_saved(uri, where, name, pages)
                app._finish(f"[b]{pages} chart pages[/b] saved as {name}\nin [b]{where}[/b]", ok=True,
                            stats=[(str(pages), "pages", C.text)])
            except Exception as exc:
                traceback.print_exc()
                app._finish(f"[color=ef4444][b]Could not make the PDF[/b][/color]\n{exc}")

        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _pdf_saved(self, uri, where, name, pages):
        self.saved_text = f"[color=22c55e]Saved[/color] {name} ({pages} pages) to [b]{where}[/b]"
        self.last_uri, self.last_kind, self._last_mime = uri, "PDF", "application/pdf"
        _toast(f"PDF saved to {where}")

    def open_last(self):
        if ANDROID:
            from ..platform_io.android_io import open_uri
        else:
            from ..platform_io.desktop_io import open_uri
        if not open_uri(self.last_uri, getattr(self, "_last_mime", "")):
            message("No app to open it", "Open the file from your Files app, in the Download folder.")

    # ---------------- one trade's chart
    def show_trade(self, i):
        t = self._filled[i]
        app = App.get_running_app()
        store = app._store()
        out = os.path.join(app_storage_dir(), "preview", f"bt_trade_{i}.png")

        def work():
            try:
                from ..backtest_report import render_trade_page

                d = date.fromisoformat(t.date)
                bars = bt.day_bars(store, d)
                r = bt.simulate_day(bars["minutes"], bars["open"], bars["high"], bars["low"], bars["close"],
                                    self.result.model, self.result.rr)

                class _P:
                    def savefig(self, fig, dpi):
                        fig.savefig(out, dpi=150)

                os.makedirs(os.path.dirname(out), exist_ok=True)
                render_trade_page(_P(), bars, t, r, self.result.instrument)
                Clock.schedule_once(lambda dt: self._open_chart(out, t), 0)
            except Exception as exc:
                traceback.print_exc()
                err = str(exc)
                Clock.schedule_once(lambda dt: message("Could not draw the chart", err), 0)

        threading.Thread(target=work, daemon=True).start()

    def _open_chart(self, path, t):
        sh = Sheet(title=f"{t.date} {t.weekday} · {t.contract} · {t.direction} · {OUTCOME_SHORT.get(t.outcome, t.outcome)}",
                   max_width=dp(1200))
        zv = ZoomView(source=path, size_hint_y=None)
        sh.card.add_widget(zv)
        from .widgets import GhostButton

        sh.card.add_widget(GhostButton(text="Close", on_release=lambda *_: sh.dismiss()))

        def fit(*_):
            zv.height = (sh.width - dp(36)) * 9 / 16
            sh.fit_height(zv.height + dp(22) + dp(44) + dp(36) + dp(24))

        sh.bind(width=fit)
        fit()
        sh.open()
