"""StraTradegy: candlestick chart PNGs from local 1-minute futures data."""

__version__ = "0.1.0"

NY_TZ_NAME = "America/New_York"
