"""US equity market (NYSE) full-day holidays, computed from rules.

CME equity-index futures (NQ, ES) often still trade a shortened session on
some of these days (e.g. MLK Day, Presidents Day), so "data exists" is not
enough to call a day a trading day. With "skip US market holidays" enabled the
generator skips these dates, which gives the usual ~20-22 charts per month.
Half days (Jul 3, day after Thanksgiving, Dec 24) are normal trading days.
"""

from __future__ import annotations

from datetime import date, timedelta
from functools import lru_cache

# One-off closures (national days of mourning, weather, 9/11).
SPECIAL_CLOSURES = {
    date(2001, 9, 11): "9/11 closure",
    date(2001, 9, 12): "9/11 closure",
    date(2001, 9, 13): "9/11 closure",
    date(2001, 9, 14): "9/11 closure",
    date(2004, 6, 11): "Reagan day of mourning",
    date(2007, 1, 2): "Ford day of mourning",
    date(2012, 10, 29): "Hurricane Sandy",
    date(2012, 10, 30): "Hurricane Sandy",
    date(2018, 12, 5): "G.H.W. Bush day of mourning",
    date(2025, 1, 9): "Carter day of mourning",
}


def _easter(year: int) -> date:
    """Anonymous Gregorian algorithm."""
    a = year % 19
    b, c = divmod(year, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = ((h + l - 7 * m + 114) % 31) + 1
    return date(year, month, day)


def _nth_weekday(year, month, weekday, n):
    d = date(year, month, 1)
    d += timedelta(days=(weekday - d.weekday()) % 7)
    return d + timedelta(weeks=n - 1)


def _last_weekday(year, month, weekday):
    d = date(year + (month == 12), month % 12 + 1, 1) - timedelta(days=1)
    return d - timedelta(days=(d.weekday() - weekday) % 7)


def _observed(d: date) -> date | None:
    if d.weekday() == 5:
        return d - timedelta(days=1)
    if d.weekday() == 6:
        return d + timedelta(days=1)
    return d


@lru_cache(maxsize=64)
def nyse_holidays(year: int) -> dict:
    h = {}
    # New Year's: Sunday -> Monday; Saturday -> not observed (NYSE rule).
    ny = date(year, 1, 1)
    if ny.weekday() == 6:
        h[ny + timedelta(days=1)] = "New Year's Day (observed)"
    elif ny.weekday() < 5:
        h[ny] = "New Year's Day"
    if year >= 1998:
        h[_nth_weekday(year, 1, 0, 3)] = "Martin Luther King Jr. Day"
    h[_nth_weekday(year, 2, 0, 3)] = "Presidents Day"
    h[_easter(year) - timedelta(days=2)] = "Good Friday"
    h[_last_weekday(year, 5, 0)] = "Memorial Day"
    if year >= 2022:
        h[_observed(date(year, 6, 19))] = "Juneteenth"
    h[_observed(date(year, 7, 4))] = "Independence Day"
    h[_nth_weekday(year, 9, 0, 1)] = "Labor Day"
    h[_nth_weekday(year, 11, 3, 4)] = "Thanksgiving"
    h[_observed(date(year, 12, 25))] = "Christmas"
    for d, name in SPECIAL_CLOSURES.items():
        if d.year == year:
            h[d] = name
    return h


def holiday_name(d: date) -> str | None:
    return nyse_holidays(d.year).get(d)


def is_weekend(d: date) -> bool:
    return d.weekday() >= 5
