"""Auditable R-multiple analytics for StraTradegy.

Resolved filled trades only contribute to realised equity. Unfilled/cancelled,
ambiguous, and open-at-cutoff orders are kept out of realised performance.
Trade ordering is date then fill time; when times are equal, stable input order
is retained. Percentage drawdown is measured against the prior positive R peak;
when no positive peak exists, percentage drawdown is undefined (None).
"""
from __future__ import annotations
from collections import defaultdict
from datetime import date, timedelta
import csv
import math
import os


def _outcome(t):
    return getattr(t, "outcome", "")


def _r(t):
    outcome = _outcome(t)
    if outcome == "Win":
        return float(getattr(t, "final_r", None) if getattr(t, "final_r", None) is not None else getattr(t, "rr", 0))
    if outcome == "Lose":
        return float(getattr(t, "final_r", -1.0))
    if outcome == "Breakeven":
        return 0.0
    return None


def _trade_sort_key(t):
    return (getattr(t, "date", ""), getattr(t, "fill_time", ""))


def _pf(rs):
    gp = sum(x for x in rs if x > 0)
    gl = -sum(x for x in rs if x < 0)
    return gp / gl if gl else (math.inf if gp > 0 else None)


def _streak(rs):
    bestw = bestl = cw = cl = 0
    for x in rs:
        if x > 0:
            cw += 1; cl = 0
        elif x < 0:
            cl += 1; cw = 0
        else:
            cw = cl = 0
        bestw = max(bestw, cw); bestl = max(bestl, cl)
    return bestw, bestl


def equity_metrics(trades):
    all_trades = list(trades)
    resolved = sorted(((t, _r(t)) for t in all_trades if _r(t) is not None), key=lambda x: _trade_sort_key(x[0]))
    ts = [x[0] for x in resolved]
    rs = [x[1] for x in resolved]
    wins = [x for x in rs if x > 0]
    losses = [x for x in rs if x < 0]
    bes = sum(x == 0 for x in rs)
    non_be = len(wins) + len(losses)
    gross_profit = sum(wins)
    gross_loss = -sum(losses)
    expectancy = sum(rs) / len(rs) if rs else 0.0

    equity = peak = 0.0
    max_dd = 0.0
    max_dd_pct = None
    curve = []
    periods = []
    current = None
    dd_depth_samples = []
    last_peak_index = 0
    longest_dd_trades = 0
    for idx, (trade, value) in enumerate(resolved):
        equity += value
        if equity >= peak:
            if current is not None:
                current["end"] = getattr(trade, "date", "")
                current["recovery_trades"] = idx - current["start_index"]
                periods.append(current)
                current = None
            peak = equity
            last_peak_index = idx
        depth = peak - equity
        if depth > 0:
            dd_depth_samples.append(depth)
            if current is None:
                current = {"start": getattr(trade, "date", ""), "start_index": last_peak_index,
                           "trades": 0, "depths": []}
            current["trades"] += 1
            current["depths"].append(depth)
            longest_dd_trades = max(longest_dd_trades, current["trades"])
            max_dd = max(max_dd, depth)
            if peak > 0:
                pct = depth / peak * 100.0
                max_dd_pct = pct if max_dd_pct is None else max(max_dd_pct, pct)
        curve.append({"date": getattr(trade, "date", ""), "time": getattr(trade, "fill_time", ""),
                      "equity_r": equity, "drawdown_r": depth})
    if current is not None:
        current["end"] = getattr(ts[-1], "date", "") if ts else ""
        current["recovery_trades"] = None
        periods.append(current)

    trading_days = len({getattr(t, "date", "") for t in ts})
    order_days = len({getattr(t, "date", "") for t in all_trades})
    wst, lst = _streak(rs)
    return {
        "orders": len(all_trades), "trades": len(rs), "wins": len(wins), "losses": len(losses),
        "breakeven": bes, "cancelled_unfilled": sum(1 for t in all_trades if getattr(t, "status", "") == "cancelled"),
        "win_rate": len(wins) / non_be if non_be else None,
        "loss_rate": len(losses) / non_be if non_be else None,
        "breakeven_rate": bes / len(rs) if rs else None,
        "gross_profit_r": gross_profit, "gross_loss_r": gross_loss, "net_r": sum(rs),
        "average_r": expectancy, "expectancy_r": expectancy,
        "profit_factor": _pf(rs), "max_drawdown_r": max_dd, "max_drawdown_pct": max_dd_pct,
        "max_consecutive_wins": wst, "max_consecutive_losses": lst,
        "average_win_r": sum(wins) / len(wins) if wins else 0.0,
        "average_loss_r": sum(losses) / len(losses) if losses else 0.0,
        "largest_win_r": max(wins) if wins else 0.0,
        "largest_loss_r": min(losses) if losses else 0.0,
        "total_trading_days": trading_days, "order_days": order_days,
        "average_trades_per_day": len(rs) / trading_days if trading_days else 0.0,
        "drawdown_periods": len(periods),
        "longest_drawdown_trades": longest_dd_trades,
        "average_drawdown_r": sum(dd_depth_samples) / len(dd_depth_samples) if dd_depth_samples else 0.0,
        "longest_drawdown_recovery_trades": max((p["recovery_trades"] for p in periods if p["recovery_trades"] is not None), default=None),
        "equity_curve": curve, "drawdown_details": periods,
    }


def grouped_performance(trades, period):
    groups = defaultdict(list)
    for t in trades:
        d = date.fromisoformat(t.date)
        if period == "monthly": key = d.strftime("%Y-%m")
        elif period == "yearly": key = str(d.year)
        elif period == "weekly": key = (d - timedelta(days=d.weekday())).isoformat()
        else: raise ValueError("period must be weekly, monthly or yearly")
        groups[key].append(t)
    out = []
    for key, items in sorted(groups.items()):
        m = equity_metrics(items)
        row = {"period": key, **{k: v for k, v in m.items() if k not in ("equity_curve", "drawdown_details")}}
        if period == "weekly":
            d = date.fromisoformat(key); row["week_start"] = key; row["week_end"] = (d + timedelta(days=6)).isoformat()
        out.append(row)
    return out


def instrument_performance(trades):
    instruments = sorted({getattr(t, "instrument", None) or getattr(t, "root", None) or "" for t in trades})
    return {name: equity_metrics([t for t in trades if (getattr(t, "instrument", None) or getattr(t, "root", None) or "") == name]) for name in instruments}


def write_metrics_csv(metrics, path):
    """Write a flat key/value summary CSV, excluding nested chart/detail objects."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["Metric", "Value"])
        for key, value in metrics.items():
            if key in ("equity_curve", "drawdown_details"): continue
            w.writerow([key, "" if value is None else value])
    return path


def write_grouped_csv(rows, path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if not rows:
        headers = ["period"]
    else:
        headers = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=headers, extrasaction="ignore"); w.writeheader(); w.writerows(rows)
    return path


def write_equity_csv(metrics, path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["date", "time", "equity_r", "drawdown_r"]); w.writeheader(); w.writerows(metrics["equity_curve"])
    return path


def monthly_summary(trades):
    """Calendar-month rollup and aggregate month-quality statistics."""
    rows = grouped_performance(trades, "monthly")
    profitable = sum(r["net_r"] > 0 for r in rows)
    losing = sum(r["net_r"] < 0 for r in rows)
    flat = sum(r["net_r"] == 0 for r in rows)
    values = [r["net_r"] for r in rows]
    return {
        "rows": rows,
        "best_month": max(rows, key=lambda r:r["net_r"])["period"] if rows else None,
        "worst_month": min(rows, key=lambda r:r["net_r"])["period"] if rows else None,
        "average_monthly_r": sum(values)/len(values) if values else 0.0,
        "profitable_months": profitable, "losing_months": losing, "breakeven_months": flat,
        "profitable_month_pct": profitable/len(rows)*100 if rows else None,
    }


def render_analytics_charts(trades, output_dir):
    """Write portable PNGs for equity, monthly net R and yearly net R charts."""
    os.makedirs(output_dir, exist_ok=True)
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    metrics = equity_metrics(trades)
    weekly = grouped_performance(trades, "weekly")
    monthly = grouped_performance(trades, "monthly")
    yearly = grouped_performance(trades, "yearly")
    outputs=[]
    specs = [
        ("equity_curve.png", [x["date"] + (" " + x["time"] if x["time"] else "") for x in metrics["equity_curve"]],
         [x["equity_r"] for x in metrics["equity_curve"]], "Cumulative equity (R)", "Trade date/time", "Cumulative R"),
        ("monthly_performance.png", [x["period"] for x in monthly], [x["net_r"] for x in monthly],
         "Monthly performance", "Month", "Net R"),
        ("yearly_performance.png", [x["period"] for x in yearly], [x["net_r"] for x in yearly],
         "Yearly performance", "Year", "Net R"),
    ]
    for name, labels, values, title, xlabel, ylabel in specs:
        fig=Figure(figsize=(10,4.5), dpi=140)
        ax=fig.add_subplot(111)
        if values:
            ax.plot(range(len(values)), values, marker="o", linewidth=1.5) if name=="equity_curve.png" else ax.bar(range(len(values)), values)
            ax.set_xticks(range(len(labels)))
            if len(labels)>18:
                step=max(1, len(labels)//12); ax.set_xticks(range(0,len(labels),step)); ax.set_xticklabels([labels[i] for i in range(0,len(labels),step)], rotation=35, ha="right")
            else: ax.set_xticklabels(labels, rotation=35, ha="right")
            ax.axhline(0, linewidth=.8)
        else:
            ax.text(.5,.5,"No resolved trades",ha="center",va="center",transform=ax.transAxes)
        ax.set_title(title); ax.set_xlabel(xlabel); ax.set_ylabel(ylabel); ax.grid(axis="y", alpha=.25)
        fig.tight_layout()
        path=os.path.join(output_dir,name); FigureCanvasAgg(fig).print_png(path); outputs.append(path); fig.clear()
    return outputs


def sort_grouped_performance(rows, sort_by="chronological"):
    """Return a copy sorted using the supported weekly/monthly/yearly ranking keys."""
    options = {
        "best": lambda r: (r.get("net_r", 0), r.get("period", "")),
        "worst": lambda r: (r.get("net_r", 0), r.get("period", "")),
        "highest_win_rate": lambda r: (float("-inf") if r.get("win_rate") is None else r["win_rate"], r.get("period", "")),
        "lowest_win_rate": lambda r: (1.0 if r.get("win_rate") is None else r["win_rate"], r.get("period", "")),
    }
    items = list(rows)
    if sort_by == "chronological": return sorted(items, key=lambda r:r.get("period", ""))
    if sort_by not in options: raise ValueError("Unknown performance sort order")
    reverse = sort_by == "best" or sort_by == "highest_win_rate"
    return sorted(items, key=options[sort_by], reverse=reverse)
