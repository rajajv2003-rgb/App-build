"""PDF of backtest trades: one 07:00-11:00 chart page per trade (matplotlib Agg/PDF).

Pages are drawn and written one at a time so memory stays flat even for hundreds
of trades.
"""

from __future__ import annotations

import os
import threading
from datetime import date

import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.collections import LineCollection, PolyCollection
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle
from matplotlib.ticker import FixedLocator, FuncFormatter, MaxNLocator

from . import backtest as bt

PAGE_W_IN, PAGE_H_IN, DPI = 9.6, 5.4, 200   # 1920 x 1080 px at 200 dpi

STYLE = {
    "bg": "#ffffff", "grid": "#eceef2", "text": "#151922", "muted": "#5f6878",
    "up": "#16a34a", "down": "#dc2626", "pm": "#6d28d9", "open": "#d97706",
    "entry": "#2563eb", "sl": "#dc2626", "tp": "#16a34a",
}
OUTCOME_COLOR = {bt.WIN: "#16a34a", bt.LOSE: "#dc2626", bt.BOTH: "#d97706", bt.OPEN: "#2563eb"}


def _candles(ax, x, o, h, l, c):
    up = c >= o
    col = np.where(up, STYLE["up"], STYLE["down"])
    lo, hi = np.minimum(o, c), np.maximum(o, c)
    span = float(h.max() - l.min()) or 1.0
    hi = np.maximum(hi, lo + span * 0.0015)
    w = 0.34
    verts = np.stack([np.column_stack([x - w, lo]), np.column_stack([x - w, hi]),
                      np.column_stack([x + w, hi]), np.column_stack([x + w, lo])], axis=1)
    wicks = np.stack([np.column_stack([x, l]), np.column_stack([x, h])], axis=1)
    ax.add_collection(LineCollection(wicks, colors=col, linewidths=0.45, zorder=3))
    ax.add_collection(PolyCollection(verts, facecolors=col, edgecolors=col, linewidths=0.2, zorder=4))


def render_trade_page(pdf: PdfPages, bars: dict, trade: bt.Trade, r: bt.DayResult, instrument: str):
    m = bars["minutes"]
    x = (m - bt.PRE_START).astype(float)
    o, h, l, c = bars["open"], bars["high"], bars["low"], bars["close"]
    fig = Figure(figsize=(PAGE_W_IN, PAGE_H_IN), dpi=DPI, facecolor=STYLE["bg"])
    ax = fig.add_axes([0.06, 0.09, 0.80, 0.78])
    _candles(ax, x, o, h, l, c)
    lo_p, hi_p = float(min(l.min(), r.sl, r.tp)), float(max(h.max(), r.sl, r.tp))
    pad = (hi_p - lo_p) * 0.05 or 1
    ax.set_ylim(lo_p - pad, hi_p + pad)
    ax.set_xlim(-1, 240)
    labels = []  # right-margin price labels, de-overlapped at the end

    def level(y, color, text, x0=-1, ls="-", lw=0.9):
        ax.plot([x0, 240], [y, y], color=color, lw=lw, ls=ls, zorder=5)
        labels.append([float(y), f"{text} {y:,.2f}", color])

    # pre-market range and 09:30
    level(r.pmh, STYLE["pm"], "PMH", ls=(0, (5, 3)), lw=0.8)
    level(r.pml, STYLE["pm"], "PML", ls=(0, (5, 3)), lw=0.8)
    ax.axvline(150, color=STYLE["open"], lw=0.9, ls=(0, (4, 3)), zorder=2)
    ax.text(150, 1.01, "09:30", transform=ax.get_xaxis_transform(), ha="center", va="bottom",
            fontsize=6.5, color=STYLE["open"], fontweight="bold")

    # sweep
    if r.sweep_i >= 0:
        sx = x[r.sweep_i]
        sy = h[r.sweep_i] if r.direction == "Short" else l[r.sweep_i]
        ax.annotate("sweep", (sx, sy), xytext=(0, 12 if r.direction == "Short" else -14),
                    textcoords="offset points", ha="center", fontsize=6, color=STYLE["pm"],
                    arrowprops=dict(arrowstyle="-|>", color=STYLE["pm"], lw=0.6), zorder=8)

    # FVG
    if r.fvg:
        j1, _, j3 = r.fvg
        if r.direction == "Long":
            y0, y1, col = h[j1], l[j3], STYLE["up"]
        else:
            y0, y1, col = h[j3], l[j1], STYLE["down"]
        x_end = x[r.exit_i] if r.exit_i >= 0 else 239
        ax.add_patch(Rectangle((x[j1] - 0.5, y0), x_end - x[j1] + 0.5, y1 - y0, facecolor=col,
                               alpha=0.16, edgecolor=col, lw=0.5, zorder=1))
        ax.text(x[j1] - 1, (y0 + y1) / 2, "FVG ", fontsize=6, color=col, va="center", ha="right", zorder=8,
                fontweight="bold", bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.8))
        start = x[j3] + 1
        level(r.entry, STYLE["entry"], "Entry", x0=start, lw=1.0)
        level(r.sl, STYLE["sl"], "Initial SL", x0=start, lw=1.0)
        level(r.tp, STYLE["tp"], "TP", x0=start, lw=1.0)
        if trade.be_enabled and trade.be_trigger is not None:
            be_price = trade.entry + trade.be_trigger * trade.risk_pts if trade.direction == "Long" else trade.entry - trade.be_trigger * trade.risk_pts
            level(be_price, STYLE["open"], f"BE trigger {trade.be_trigger:g}R", x0=start, ls=(0,(3,2)), lw=.9)
            if trade.be_activated:
                level(trade.entry, STYLE["open"], "BE stop", x0=start, ls=(0,(2,2)), lw=1.1)

    # fill and exit markers
    if r.fill_i >= 0:
        ax.scatter([x[r.fill_i]], [r.entry], marker="^" if r.direction == "Long" else "v", s=34,
                   color=STYLE["entry"], edgecolors="white", linewidths=0.6, zorder=9)
        ax.annotate("fill", (x[r.fill_i], r.entry), xytext=(-12, 0), textcoords="offset points",
                    fontsize=6, color=STYLE["entry"], ha="right", va="center", zorder=9)
    if r.exit_i >= 0 and trade.status == "filled":
        ey = {bt.WIN: r.tp, bt.LOSE: r.sl, bt.BREAKEVEN: r.entry}.get(r.outcome, (r.tp + r.sl) / 2)
        ax.scatter([x[r.exit_i]], [ey], marker="X", s=38, color=OUTCOME_COLOR.get(r.outcome, "#000"),
                   edgecolors="white", linewidths=0.6, zorder=9)
        ax.annotate("exit", (x[r.exit_i], ey), xytext=(8, 0), textcoords="offset points", fontsize=6,
                    color=OUTCOME_COLOR.get(r.outcome, "#000"), va="center", zorder=9)

    # big outcome label for the special cases
    badge = {bt.BOTH: "BOTH HIT (SAME CANDLE) - not a win or a loss",
             bt.OPEN: "OPEN AT 11:00 - not a win or a loss",
             bt.CANCEL_TP: "NOT FILLED - take profit reached first",
             bt.CANCEL_TIME: "NOT FILLED by 11:00"}.get(r.outcome)
    if badge:
        ax.text(0.01, 0.97, badge, transform=ax.transAxes, fontsize=8, fontweight="bold", va="top", zorder=12,
                color=OUTCOME_COLOR.get(r.outcome, STYLE["muted"]),
                bbox=dict(boxstyle="round,pad=0.35", fc="white", ec=OUTCOME_COLOR.get(r.outcome, "#999"), lw=0.8))

    # price labels in the right margin, pushed apart so none overlap
    y_lo, y_hi = ax.get_ylim()
    gap = (y_hi - y_lo) * 0.032
    labels.sort(key=lambda t: t[0])
    for i in range(1, len(labels)):
        if labels[i][0] - labels[i - 1][0] < gap:
            labels[i][0] = labels[i - 1][0] + gap
    over = labels[-1][0] - (y_hi - gap / 2) if labels else 0
    for t in labels:
        if over > 0:
            t[0] -= over
        ax.text(241, t[0], t[1], color=t[2], fontsize=6.2, va="center", ha="left", clip_on=False, zorder=7)

    # axes
    ticks = [0, 60, 120, 150, 180, 240]
    ax.xaxis.set_major_locator(FixedLocator(ticks))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: bt.hhmm(int(v) + bt.PRE_START)))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=9))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:,.2f}"))
    ax.yaxis.tick_left()
    ax.grid(axis="y", color=STYLE["grid"], lw=0.5, zorder=0)
    ax.tick_params(labelsize=6.5, colors=STYLE["muted"], length=2.5, width=0.5)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    for sp in ("bottom", "left"):
        ax.spines[sp].set_color("#c9ced8")
        ax.spines[sp].set_linewidth(0.6)
    ax.set_xlabel("New York time", fontsize=6.5, color=STYLE["muted"])

    d = date.fromisoformat(trade.date)
    outcome = bt._short_outcome(trade.outcome)
    title = (f"{trade.date} {d.strftime('%A')}  ·  {instrument}  ·  {trade.contract}  ·  {trade.direction}  ·  "
             f"Model {trade.model}  ·  RR {trade.rr:g}  ·  {outcome}")
    fig.text(0.06, 0.95, title, fontsize=10.5, fontweight="bold", color=OUTCOME_COLOR.get(trade.outcome, STYLE["text"]))
    fig.text(0.06, 0.915, (f"Entry {trade.entry:,.2f}  ·  SL {trade.sl:,.2f} ({trade.risk_pts:,.2f} pts)  ·  "
                           f"TP {trade.tp:,.2f} ({trade.reward_pts:,.2f} pts)  ·  sweep {trade.sweep_time}  ·  "
                           f"FVG {trade.fvg_times}" + (f"  ·  fill {trade.fill_time}" if trade.fill_time else "")
                           + (f"  ·  exit {trade.exit_time}" if trade.exit_time and trade.status == "filled" else "")),
             fontsize=6.8, color=STYLE["muted"])
    pdf.savefig(fig, dpi=DPI)
    fig.clear()


def _render_analytics_pages(pdf, result):
    from .advanced_analytics import equity_metrics, monthly_summary, render_analytics_charts, grouped_performance
    import tempfile
    from matplotlib.image import imread
    metrics = equity_metrics(result.trades)
    fig = Figure(figsize=(PAGE_W_IN, PAGE_H_IN), dpi=160, facecolor="white")
    ax = fig.add_axes([0.06, 0.08, 0.88, 0.84]); ax.axis("off")
    cfg = (f"Instrument: {result.instrument}    Model: {result.model}    TP: {result.rr:g}R\n"
           f"BE: {'ON at ' + str(result.be_trigger) + 'R' if result.be_trigger is not None else 'OFF'}    "
           f"Cancel TP before entry: {'ON' if result.cancel_tp_before_entry else 'OFF'}\n"
           f"Date range: {result.start} to {result.end}")
    lines = [
        f"Orders: {metrics['orders']}    Resolved trades: {metrics['trades']}    Cancelled/unfilled: {metrics['cancelled_unfilled']}",
        f"Wins: {metrics['wins']}    Losses: {metrics['losses']}    Breakeven: {metrics['breakeven']}",
        f"Win rate: {metrics['win_rate']*100:.2f}%" if metrics['win_rate'] is not None else "Win rate: N/A",
        f"Gross profit: {metrics['gross_profit_r']:.2f}R    Gross loss: {metrics['gross_loss_r']:.2f}R    Net: {metrics['net_r']:.2f}R",
        f"Profit factor: {'infinity' if metrics['profit_factor']==float('inf') else (f"{metrics['profit_factor']:.2f}" if metrics['profit_factor'] is not None else 'N/A')}    Expectancy: {metrics['expectancy_r']:.3f}R/trade",
        f"Max drawdown: {metrics['max_drawdown_r']:.2f}R    Max DD %: {metrics['max_drawdown_pct']:.2f}%" if metrics['max_drawdown_pct'] is not None else f"Max drawdown: {metrics['max_drawdown_r']:.2f}R    Max DD %: N/A",
        f"Max winning streak: {metrics['max_consecutive_wins']}    Max losing streak: {metrics['max_consecutive_losses']}",
    ]
    ax.text(0, 1, "StraTradegy — Backtest performance report", fontsize=17, weight="bold", va="top")
    ax.text(0, .88, cfg, fontsize=9, va="top", linespacing=1.6)
    ax.text(0, .65, "OVERALL PERFORMANCE", fontsize=11, weight="bold", va="top")
    ax.text(0, .59, "\n".join(lines), fontsize=9, va="top", linespacing=1.7, family="monospace")
    ms = monthly_summary(result.trades)
    extra = (f"Best month: {ms['best_month'] or 'N/A'}    Worst month: {ms['worst_month'] or 'N/A'}\n"
             f"Average monthly return: {ms['average_monthly_r']:.2f}R    Profitable months: {ms['profitable_months']} / {len(ms['rows'])}")
    ax.text(0, .20, "MONTHLY SUMMARY", fontsize=10, weight="bold", va="top")
    ax.text(0, .15, extra, fontsize=8.5, va="top")
    pdf.savefig(fig, dpi=160); fig.clear()
    with tempfile.TemporaryDirectory() as td:
        for chart in render_analytics_charts(result.trades, td):
            fig = Figure(figsize=(PAGE_W_IN, PAGE_H_IN), dpi=160, facecolor="white")
            ax = fig.add_axes([.04,.06,.92,.88]); ax.imshow(imread(chart)); ax.axis("off")
            fig.text(.05,.96,os.path.basename(chart).replace("_"," ").replace(".png",""),fontsize=12,weight="bold")
            pdf.savefig(fig,dpi=160); fig.clear()
    # Detailed period tables are paginated to keep every row legible.
    for period in ("weekly", "monthly", "yearly"):
        rows = grouped_performance(result.trades, period)
        for offset in range(0, max(1, len(rows)), 24):
            chunk = rows[offset:offset+24]
            fig = Figure(figsize=(PAGE_W_IN, PAGE_H_IN), dpi=160, facecolor="white")
            ax = fig.add_axes([.04,.08,.92,.82]); ax.axis("off")
            title = f"{period.title()} performance" + (f" — rows {offset+1}–{offset+len(chunk)}" if chunk else "")
            fig.text(.05,.95,title,fontsize=12,weight="bold")
            headers = ["Period", "Trades", "W", "L", "BE", "Win %", "Net R", "PF", "Exp R", "Max DD"]
            body=[]
            for row in chunk:
                wr = row.get("win_rate")
                pf = row.get("profit_factor")
                body.append([row.get("period", ""), row.get("trades", 0), row.get("wins", 0), row.get("losses", 0),
                    row.get("breakeven", 0), "—" if wr is None else f"{wr*100:.1f}", f"{row.get('net_r',0):.2f}",
                    "∞" if pf == float("inf") else ("—" if pf is None else f"{pf:.2f}"),
                    f"{row.get('expectancy_r',0):.3f}", f"{row.get('max_drawdown_r',0):.2f}"])
            table=ax.table(cellText=body, colLabels=headers, loc="upper center", cellLoc="center")
            table.auto_set_font_size(False); table.set_fontsize(7.2); table.scale(1,1.35)
            if not body: ax.text(.5,.5,"No trades in this period",ha="center",va="center")
            pdf.savefig(fig,dpi=160); fig.clear()


def write_pdf(result: bt.BacktestResult, store, path: str, include_cancelled: bool = False,
              progress=None, cancel: threading.Event | None = None) -> tuple[str, int]:
    """One page per filled trade (plus cancelled orders if asked), in date order."""
    progress = progress or (lambda f, t: None)
    trades = sorted((t for t in result.trades if t.status == "filled" or include_cancelled), key=lambda t: t.date)
    if not trades:
        raise ValueError("There are no trades to put in the PDF for these settings.")
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    pages = 0
    with PdfPages(path) as pdf:
        info = pdf.infodict()
        info["Title"] = f"{result.instrument} backtest {result.start} to {result.end} (Model {result.model}, RR {result.rr:g})"
        info["Creator"] = "StraTradegy"
        _render_analytics_pages(pdf, result)
        for i, t in enumerate(trades):
            if cancel is not None and cancel.is_set():
                break
            d = date.fromisoformat(t.date)
            bars = bt.day_bars(store, d)
            r = bt.simulate_day(bars["minutes"], bars["open"], bars["high"], bars["low"], bars["close"],
                                result.model, result.rr, result.cancel_tp_before_entry, result.be_trigger)
            render_trade_page(pdf, bars, t, r, result.instrument)
            pages += 1
            progress((i + 1) / len(trades), f"PDF page {i + 1} of {len(trades)}: {t.date}")
    return path, pages
