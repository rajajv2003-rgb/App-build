"""Small on-device language model (llama.cpp via llama-cpp-python, GGUF files).

The model never sees the chart. It gets the facts from analysis.py and phrases
them / answers follow-up questions about them, offline. Qwen2.5 Instruct (0.5B
or 1.5B, Q4_K_M, Apache-2.0) uses the ChatML prompt format built here directly.

Android: libllama.so + libggml*.so are built with the NDK (see
tools/build_llama_android.sh) and shipped as native libs; ``_prepare_android``
locates them (or extracts them from the APK) and points llama-cpp-python at them.
"""

from __future__ import annotations

import os
import re
import sys
import threading
import urllib.error
import urllib.request

from .platform_io import is_android

MODELS = {
    "qwen2.5-0.5b": {
        "label": "Qwen2.5 0.5B (fast, 491 MB)",
        "file": "qwen2.5-0.5b-instruct-q4_k_m.gguf",
        "url": "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf",
        "size": 491_400_032,
    },
    "qwen2.5-1.5b": {
        "label": "Qwen2.5 1.5B (better, 1.1 GB)",
        "file": "qwen2.5-1.5b-instruct-q4_k_m.gguf",
        "url": "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf",
        "size": 1_117_320_736,
    },
}

SYSTEM_PROMPT = (
    "You help a beginner understand one trading day of a futures market. "
    "Use ONLY the FACTS below and copy every number exactly as written. "
    "Never invent prices, times, news or reasons, and do not mix up which number belongs to what. "
    "If the facts do not answer the question, say you don't know. "
    "Answer in 2 to 4 short sentences of plain English. "
    "Describe what happened; never recommend trades or predict prices."
)

SUGGESTIONS = [
    "Summarize this day",
    "What happened at the 9:30 open?",
    "Was it a trend day or a choppy day?",
    "Explain the opening range",
]


_TOPICS = [
    (("open", "9:30", "09:30", "opening", "first 15", "bell"), ("stock-market open", "From 09:30", "Opening range")),
    (("trend", "chop", "type", "direction", "kind of day"), ("Type of day", "Result")),
    (("overnight", "gap", "previous", "yesterday", "prior"), ("Overnight", "Previous day")),
    (("high", "low", "range", "top", "bottom"), ("Highest price", "Compared")),
    (("fast", "biggest", "spike", "sharp", "drop", "jump"), ("Fastest",)),
    (("8:00", "08:00", "9:00", "09:00", "line", "marker"), ("marker lines",)),
    (("summar", "overall", "what happened", "explain the day", "recap"),
     ("Result", "Type of day", "Compared", "Opening range")),
]


def select_facts(facts, question: str) -> str:
    """Header + headline + only the fact lines relevant to the question."""
    q = question.lower()
    want = set()
    for keys, prefixes in _TOPICS:
        if any(k in q for k in keys):
            want.update(prefixes)
    lines = facts.lines if not want else [ln for ln in facts.lines if any(w in ln for w in want)]
    head = facts.text().split("\n", 1)[0]
    return head + "\n- Summary: " + facts.headline() + "\n" + "\n".join(f"- {ln}" for ln in lines)


_NUM = re.compile(r"\d[\d,]*(?:\.\d+)?")


def unverified_numbers(answer: str, facts_text: str) -> list[str]:
    """Numbers in the answer that do not appear in the facts (likely made up)."""
    norm = lambda x: x.replace(",", "").rstrip("0").rstrip(".") if "." in x else x.replace(",", "")  # noqa: E731
    allowed = {norm(n) for n in _NUM.findall(facts_text)}
    bad = []
    for n in _NUM.findall(answer):
        k = norm(n)
        if k in allowed or (k.isdigit() and int(k) <= 60):  # small counts, minutes, dates parts
            continue
        bad.append(n)
    return bad


class AIUnavailable(RuntimeError):
    pass


_LOAD_LOCK = threading.Lock()


def _prepare_android():
    """Make libllama.so loadable on Android and point llama-cpp-python at it."""
    from jnius import autoclass  # type: ignore

    ctx = autoclass("org.kivy.android.PythonActivity").mActivity
    info = ctx.getApplicationInfo()
    native_dir = info.nativeLibraryDir
    lib_dir = native_dir
    if not os.path.exists(os.path.join(native_dir, "libllama.so")):
        # libs not extracted (extractNativeLibs=false): copy them out of the APK once
        import zipfile

        lib_dir = os.path.join(ctx.getFilesDir().getAbsolutePath(), "llama_libs")
        os.makedirs(lib_dir, exist_ok=True)
        with zipfile.ZipFile(info.sourceDir) as apk:
            for name in apk.namelist():
                base = os.path.basename(name)
                if name.startswith("lib/arm64-v8a/") and (base.startswith("libggml") or base == "libllama.so"):
                    dest = os.path.join(lib_dir, base)
                    if not os.path.exists(dest):
                        with apk.open(name) as src, open(dest, "wb") as out:
                            out.write(src.read())
    import ctypes

    for name in ("libggml-base.so", "libggml-cpu.so", "libggml.so", "libllama.so"):
        path = os.path.join(lib_dir, name)
        if os.path.exists(path):
            ctypes.CDLL(path, mode=ctypes.RTLD_GLOBAL)  # deps resolve by soname afterwards
    os.environ["LLAMA_CPP_LIB_PATH"] = lib_dir


def _import_llama():
    try:
        if is_android():
            _prepare_android()
            real = sys.platform
            if not real.startswith("linux"):
                sys.platform = "linux"  # llama-cpp-python's loader only knows "linux"
            try:
                from llama_cpp import Llama  # type: ignore
            finally:
                sys.platform = real
        else:
            from llama_cpp import Llama  # type: ignore
        return Llama
    except Exception as exc:  # ImportError, OSError, RuntimeError from ctypes
        raise AIUnavailable(f"The on-device AI engine could not start: {exc}") from exc


def engine_available() -> bool:
    try:
        _import_llama()
        return True
    except AIUnavailable:
        return False


class LocalModel:
    """Lazy-loading wrapper; one generation at a time."""

    def __init__(self, path: str, n_ctx: int = 2048, n_threads: int | None = None):
        self.path = path
        self.n_ctx = n_ctx
        cpus = os.cpu_count() or 4
        self.n_threads = n_threads or max(2, min(4, cpus // 2))
        self._llm = None
        self.cancel = threading.Event()

    @property
    def loaded(self) -> bool:
        return self._llm is not None

    def load(self):
        with _LOAD_LOCK:
            if self._llm is None:
                if not os.path.exists(self.path):
                    raise AIUnavailable("Model file not found - download or choose a model first.")
                Llama = _import_llama()
                self._llm = Llama(model_path=self.path, n_ctx=self.n_ctx, n_threads=self.n_threads,
                                  n_batch=256, verbose=False)
        return self._llm

    @staticmethod
    def build_prompt(facts: str, question: str, history: list[tuple[str, str]] | None = None) -> str:
        parts = [f"<|im_start|>system\n{SYSTEM_PROMPT}\n\nFACTS:\n{facts}<|im_end|>\n"]
        for q, a in (history or [])[-2:]:
            parts.append(f"<|im_start|>user\n{q}<|im_end|>\n<|im_start|>assistant\n{a}<|im_end|>\n")
        parts.append(f"<|im_start|>user\n{question}<|im_end|>\n<|im_start|>assistant\n")
        return "".join(parts)

    def ask(self, facts: str, question: str, on_token=None, history=None, max_tokens: int = 180) -> str:
        """Generate an answer. ``on_token(text_so_far)`` is called while streaming."""
        llm = self.load()
        self.cancel.clear()
        prompt = self.build_prompt(facts, question, history)
        out = ""
        for chunk in llm(prompt, max_tokens=max_tokens, temperature=0.1, top_p=0.9, repeat_penalty=1.15,
                         stop=["<|im_end|>", "<|im_start|>"], stream=True):
            out += chunk["choices"][0]["text"]
            if on_token:
                on_token(out)
            if self.cancel.is_set():
                break
        return out.strip()


def _ssl_context():
    """HTTPS context that also works on Android, where Python cannot see the
    system certificate store: use the bundled certifi CA list when available."""
    import ssl

    try:
        import certifi

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def download_model(key: str, dest_dir: str, progress=None, cancel: threading.Event | None = None) -> str:
    """Download a catalogue model (resumable). ``progress(fraction, text)``."""
    m = MODELS[key]
    os.makedirs(dest_dir, exist_ok=True)
    final = os.path.join(dest_dir, m["file"])
    if os.path.exists(final) and os.path.getsize(final) == m["size"]:
        return final
    part = final + ".part"
    have = os.path.getsize(part) if os.path.exists(part) else 0
    headers = {"User-Agent": "StraTradegy/0.1 (offline chart helper)"}
    if have:
        headers["Range"] = f"bytes={have}-"
    req = urllib.request.Request(m["url"], headers=headers)
    try:
        resp_cm = urllib.request.urlopen(req, timeout=30, context=_ssl_context())
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", exc)
        if "CERTIFICATE" in str(reason).upper():
            raise IOError(f"Secure connection failed ({reason}). Check the phone's date and time.") from exc
        raise IOError(f"Could not reach huggingface.co: {reason}. Check your internet connection.") from exc
    with resp_cm as resp, open(part, "ab" if have else "wb") as out:
        if have and resp.status != 206:  # server ignored the range: start over
            out.truncate(0)
            have = 0
        done = have
        while True:
            if cancel is not None and cancel.is_set():
                raise InterruptedError("Download cancelled")
            buf = resp.read(1 << 20)
            if not buf:
                break
            out.write(buf)
            done += len(buf)
            if progress:
                progress(done / m["size"], f"Downloading {m['label']}: {done / 1e6:,.0f} / {m['size'] / 1e6:,.0f} MB")
    if os.path.getsize(part) != m["size"]:
        raise IOError("Download incomplete - tap download again to resume.")
    os.replace(part, final)
    return final
