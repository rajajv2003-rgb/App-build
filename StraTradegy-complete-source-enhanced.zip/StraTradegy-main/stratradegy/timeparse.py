"""Fast timestamp parsing and timezone conversion.

Everything is converted to int64 UTC epoch seconds. The hot paths are vectorised
with numpy so a 15-year 1-minute file can be indexed on a phone in minutes,
without pandas.

Supported ``ts_format`` values:
  * a strptime-style format, e.g. ``%Y-%m-%d %H:%M:%S`` or ``%m/%d/%Y %H:%M``
    (zero-padded fixed-width formats take the fast vectorised path; anything
    else falls back to per-row parsing)
  * ``iso8601``  - ISO strings, optionally with an offset (``Z``, ``-05:00``)
  * ``epoch_s`` / ``epoch_ms`` / ``epoch_us`` / ``epoch_ns`` - Unix time (UTC)
"""

from __future__ import annotations

import re
from datetime import date, datetime, time as dtime, timedelta, timezone
from functools import lru_cache
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import numpy as np

EPOCH_NAIVE = datetime(1970, 1, 1)
EPOCH_FORMATS = {"epoch_s": 1, "epoch_ms": 1_000, "epoch_us": 1_000_000, "epoch_ns": 1_000_000_000}

# Formats tried (in order) when auto-detecting. Day-first variants come after
# month-first ones; detection switches to them when a first field is > 12.
CANDIDATE_FORMATS = [
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d %H:%M",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%dT%H:%M",
    "%Y/%m/%d %H:%M:%S",
    "%Y/%m/%d %H:%M",
    "%Y%m%d %H%M%S",
    "%Y%m%d %H:%M:%S",
    "%Y%m%d %H%M",
    "%Y%m%d%H%M%S",
    "%m/%d/%Y %H:%M:%S",
    "%m/%d/%Y %H:%M",
    "%d/%m/%Y %H:%M:%S",
    "%d/%m/%Y %H:%M",
    "%d.%m.%Y %H:%M:%S",
    "%d.%m.%Y %H:%M",
    "%m-%d-%Y %H:%M:%S",
    "%m-%d-%Y %H:%M",
    "%d-%m-%Y %H:%M:%S",
    "%d-%m-%Y %H:%M",
    "%m/%d/%y %H:%M:%S",
    "%m/%d/%y %H:%M",
]

_WIDTHS = {"Y": 4, "y": 2, "m": 2, "d": 2, "H": 2, "M": 2, "S": 2}


class TimestampError(ValueError):
    pass


@lru_cache(maxsize=32)
def get_zone(name: str):
    if name.upper() in ("UTC", "GMT", "Z", "ETC/UTC"):
        return timezone.utc
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError) as exc:
        raise TimestampError(
            f"Unknown timezone '{name}'. Use an IANA name such as America/New_York, "
            "America/Chicago or UTC. (On Android this also fails if the 'tzdata' "
            "package is missing from buildozer.spec requirements.)"
        ) from exc


# --------------------------------------------------------------------------- #
# fixed-width vectorised parsing
# --------------------------------------------------------------------------- #
@lru_cache(maxsize=64)
def compile_fixed_width(fmt: str):
    """Return (layout, total_len) for zero-padded formats, or None.

    layout is a tuple of (field_letter, start, end).
    """
    layout = []
    pos = 0
    i = 0
    while i < len(fmt):
        ch = fmt[i]
        if ch == "%":
            if i + 1 >= len(fmt):
                return None
            d = fmt[i + 1]
            if d == "%":
                pos += 1
            elif d in _WIDTHS:
                w = _WIDTHS[d]
                layout.append((d, pos, pos + w))
                pos += w
            else:
                return None  # %f, %z, %b, %p ... not fixed width
            i += 2
        else:
            pos += 1
            i += 1
    letters = [f for f, _, _ in layout]
    if not ({"Y", "y"} & set(letters)) or "m" not in letters or "d" not in letters:
        return None
    return tuple(layout), pos


def _digits(u8: np.ndarray, start: int, end: int):
    block = u8[:, start:end].astype(np.int64) - 48
    ok = np.all((block >= 0) & (block <= 9), axis=1)
    weights = 10 ** np.arange(end - start - 1, -1, -1, dtype=np.int64)
    return block @ weights, ok


def _fields_to_secs(u8: np.ndarray, layout):
    """Digits at fixed byte positions -> (naive seconds, valid mask)."""
    fields = {}
    ok = np.ones(u8.shape[0], dtype=bool)
    for letter, s, e in layout:
        val, good = _digits(u8, s, e)
        fields[letter] = val
        ok &= good
    if "Y" in fields:
        year = fields["Y"]
    else:
        yy = fields["y"]
        year = np.where(yy < 69, 2000 + yy, 1900 + yy)
    month = fields["m"]
    day = fields["d"]
    hour = fields.get("H", np.zeros_like(month))
    minute = fields.get("M", np.zeros_like(month))
    second = fields.get("S", np.zeros_like(month))

    ok &= (month >= 1) & (month <= 12) & (day >= 1) & (hour <= 23) & (minute <= 59) & (second <= 60)
    month_c = np.clip(month, 1, 12)
    months = (year - 1970) * 12 + (month_c - 1)
    first = months.astype("datetime64[M]").astype("datetime64[D]").astype(np.int64)
    nxt = (months + 1).astype("datetime64[M]").astype("datetime64[D]").astype(np.int64)
    ok &= day <= (nxt - first)
    days = first + day - 1
    return days * 86400 + hour * 3600 + minute * 60 + second, ok


def _parse_fixed(values: list[str], layout, total_len: int):
    """Vectorised parse. Returns (naive_seconds int64, valid bool mask)."""
    n = len(values)
    lens = np.fromiter(map(len, values), dtype=np.int64, count=n)
    valid = lens == total_len
    secs = np.zeros(n, dtype=np.int64)
    if not valid.any():
        return secs, valid
    idx = np.nonzero(valid)[0]
    sub = [values[i] for i in idx] if not valid.all() else values
    try:
        raw = np.array(sub, dtype=f"S{total_len}")
    except UnicodeEncodeError:
        return secs, np.zeros(n, dtype=bool)
    u8 = raw.view(np.uint8).reshape(-1, total_len)
    out, ok = _fields_to_secs(u8, layout)
    secs[idx] = np.where(ok, out, 0)
    valid[idx] = ok
    return secs, valid


_ISO_LAYOUT = (("Y", 0, 4), ("m", 5, 7), ("d", 8, 10), ("H", 11, 13), ("M", 14, 16), ("S", 17, 19))
_ISO_TAIL = re.compile(r"(\.\d+)?(Z|[+-]\d\d:?\d\d)?")


def _parse_iso_fast(values: list[str]):
    """Vectorised ISO-8601 for uniform strings such as Databento's
    ``2011-01-02T23:00:00.000000000Z``. Fractional seconds are ignored (bars sit
    on whole minutes). Returns (secs, valid, aware) or None if not uniform."""
    n = len(values)
    if n == 0 or len(values[0]) < 19:
        return None
    L = len(values[0])
    m = _ISO_TAIL.fullmatch(values[0][19:])
    if not m:
        return None
    lens = np.fromiter(map(len, values), dtype=np.int64, count=n)
    if not (lens == L).all():
        return None
    try:
        u8 = np.array(values, dtype=f"S{L}").view(np.uint8).reshape(n, L)
    except UnicodeEncodeError:
        return None
    secs, ok = _fields_to_secs(u8, _ISO_LAYOUT)
    ok &= (u8[:, 4] == 45) & (u8[:, 7] == 45) & ((u8[:, 10] == 84) | (u8[:, 10] == 32)) \
        & (u8[:, 13] == 58) & (u8[:, 16] == 58)
    tz = m.group(2)
    if tz:
        k = len(tz)
        ok &= (u8[:, L - k:] == u8[0, L - k:]).all(axis=1)  # same suffix on every row
        if tz != "Z":
            sign = -1 if tz[0] == "-" else 1
            digits = tz[1:].replace(":", "")
            secs = secs - sign * (int(digits[:2]) * 3600 + int(digits[2:]) * 60)
    return secs, ok, tz is not None


# --------------------------------------------------------------------------- #
# slow per-row fallbacks
# --------------------------------------------------------------------------- #
def _parse_strptime(values, fmt):
    n = len(values)
    secs = np.zeros(n, dtype=np.int64)
    valid = np.zeros(n, dtype=bool)
    has_tz = "%z" in fmt
    for i, v in enumerate(values):
        try:
            dt = datetime.strptime(v, fmt)
        except ValueError:
            continue
        if has_tz and dt.tzinfo is not None:
            secs[i] = int(dt.timestamp())
        else:
            secs[i] = (dt - EPOCH_NAIVE) // timedelta(seconds=1)
        valid[i] = True
    return secs, valid, has_tz


def _parse_iso(values):
    """Returns (seconds, valid, aware_mask). Aware rows are already UTC."""
    n = len(values)
    secs = np.zeros(n, dtype=np.int64)
    valid = np.zeros(n, dtype=bool)
    aware = np.zeros(n, dtype=bool)
    fromiso = datetime.fromisoformat
    for i, v in enumerate(values):
        try:
            dt = fromiso(v[:-1] + "+00:00" if v.endswith("Z") else v)
        except ValueError:
            continue
        if dt.tzinfo is not None:
            secs[i] = int(dt.timestamp())
            aware[i] = True
        else:
            secs[i] = (dt - EPOCH_NAIVE) // timedelta(seconds=1)
        valid[i] = True
    return secs, valid, aware


_NUM_RE = re.compile(r"^-?\d+(\.\d+)?$")


def _parse_epoch(values, unit_div):
    arr = np.array(values, dtype=object)
    valid = np.fromiter((bool(_NUM_RE.match(v)) for v in values), dtype=bool, count=len(values))
    secs = np.zeros(len(values), dtype=np.int64)
    if valid.any():
        nums = np.array([float(v) for v, ok in zip(arr, valid) if ok])
        secs[valid] = np.floor(nums / unit_div).astype(np.int64)
    return secs, valid


# --------------------------------------------------------------------------- #
# timezone conversion
# --------------------------------------------------------------------------- #
def local_naive_to_utc(naive_secs: np.ndarray, tz_name: str) -> np.ndarray:
    """Convert naive wall-clock seconds in ``tz_name`` to UTC epoch seconds.

    DST-correct: the UTC offset is looked up with zoneinfo for every distinct
    half hour present in the data (cheap: ~3k lookups per 200k-row chunk).
    Ambiguous fall-back times use the first occurrence (fold=0), which never
    matters for CME data because the market is closed at 01:00-02:00 Sunday.
    """
    tz = get_zone(tz_name)
    if tz is timezone.utc or naive_secs.size == 0:
        return naive_secs.astype(np.int64, copy=False)
    buckets = naive_secs // 1800
    uniq, inv = np.unique(buckets, return_inverse=True)
    offs = np.empty(len(uniq), dtype=np.int64)
    for i, b in enumerate(uniq.tolist()):
        dt = (EPOCH_NAIVE + timedelta(seconds=b * 1800)).replace(tzinfo=tz)
        offs[i] = int(dt.utcoffset().total_seconds())
    return naive_secs - offs[inv.reshape(-1)]


def parse_timestamps(values: list[str], fmt: str, source_tz: str):
    """Parse strings into UTC epoch seconds.

    Returns (utc_seconds int64 array, valid bool mask).
    """
    values = [v.strip() for v in values]
    if fmt in EPOCH_FORMATS:
        return _parse_epoch(values, EPOCH_FORMATS[fmt])

    if fmt == "iso8601":
        fast = _parse_iso_fast(values)
        if fast is not None:
            secs, valid, is_aware = fast
            aware = np.full(len(values), is_aware)
            if not valid.all():  # odd rows: slow path
                bad = np.nonzero(~valid)[0]
                s2, v2, a2 = _parse_iso([values[i] for i in bad])
                secs[bad], valid[bad], aware[bad] = s2, v2, a2
        else:
            secs, valid, aware = _parse_iso(values)
        naive = valid & ~aware
        if naive.any():
            secs[naive] = local_naive_to_utc(secs[naive], source_tz)
        return secs, valid

    compiled = compile_fixed_width(fmt)
    if compiled is not None:
        layout, total = compiled
        secs, valid = _parse_fixed(values, layout, total)
        bad = ~valid
        if bad.any():  # e.g. non-padded "1/2/2012 9:31" rows mixed in
            bad_idx = np.nonzero(bad)[0]
            s2, v2, _ = _parse_strptime([values[i] for i in bad_idx], fmt)
            secs[bad_idx] = s2
            valid[bad_idx] = v2
        aware = False
    else:
        secs, valid, aware = _parse_strptime(values, fmt)

    if not aware:
        secs = local_naive_to_utc(secs, source_tz)
    return secs, valid


# --------------------------------------------------------------------------- #
# detection
# --------------------------------------------------------------------------- #
def detect_format(samples: list[str]) -> tuple[str | None, str]:
    """Guess the timestamp format from sample strings. Returns (fmt, note)."""
    samples = [s.strip() for s in samples if s and s.strip()]
    if not samples:
        return None, "No timestamp samples."

    if all(_NUM_RE.match(s) for s in samples):
        v = float(samples[0])
        if v > 1e17:
            return "epoch_ns", "Looks like Unix time in nanoseconds (UTC)."
        if v > 1e14:
            return "epoch_us", "Looks like Unix time in microseconds (UTC)."
        if v > 1e11:
            return "epoch_ms", "Looks like Unix time in milliseconds (UTC)."
        if v > 1e8:
            return "epoch_s", "Looks like Unix time in seconds (UTC)."

    if any(re.search(r"(Z|[+-]\d\d:?\d\d)$", s) and "T" in s for s in samples):
        return "iso8601", "ISO-8601 timestamps with a UTC offset; source timezone is ignored for those rows."

    def _all_parse(fmt):
        try:
            for s in samples:
                datetime.strptime(s, fmt)
            return True
        except ValueError:
            return False

    # Pass 1: zero-padded formats whose width matches exactly (strptime alone is
    # too lenient: "%H%M%S" happily reads "0700" as 00:07:00).
    matches = []
    for fmt in CANDIDATE_FORMATS:
        comp = compile_fixed_width(fmt)
        if comp and all(len(s) == comp[1] for s in samples) and _all_parse(fmt):
            matches.append(fmt)
    # Pass 2: non-padded values such as "1/2/2012 9:31".
    if not matches:
        matches = [f for f in CANDIDATE_FORMATS if _all_parse(f)]
    if not matches:
        try:
            for s in samples:
                datetime.fromisoformat(s)
            return "iso8601", "ISO-8601 timestamps."
        except ValueError:
            return None, "Could not recognise the timestamp format; enter it manually (strptime codes)."

    fmt = matches[0]
    note = f"Detected format {fmt}."
    dayfirst = [m for m in matches if m.startswith("%d")]
    monthfirst = [m for m in matches if m.startswith("%m")]
    if monthfirst and dayfirst:
        note += " Month/day order is ambiguous in these rows - assumed month first (US). Check the preview."
    return fmt, note


# --------------------------------------------------------------------------- #
# New York wall-clock helpers
# --------------------------------------------------------------------------- #
def parse_hhmm(s: str) -> dtime:
    try:
        hh, mm = s.strip().split(":")
        return dtime(int(hh), int(mm))
    except (ValueError, AttributeError):
        raise ValueError(f"Invalid time '{s}'. Use HH:MM, e.g. 07:00.") from None


def ny_epoch(day: date, t: dtime) -> int:
    """Epoch seconds of a New York wall-clock time (DST-aware via zoneinfo)."""
    return int(datetime.combine(day, t, tzinfo=get_zone("America/New_York")).timestamp())
