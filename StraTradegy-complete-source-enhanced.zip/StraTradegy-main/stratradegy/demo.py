"""Demo data so a new user can try the app before copying their own CSV over.

Writes made-up NQ and ES 1-minute bars (Databento-style columns, UTC timestamps,
quarterly contract symbols) for the last ~3 months. Clearly labelled as demo.
"""

from __future__ import annotations

import os
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import numpy as np

from .calendar_us import holiday_name

DEMO_NAME = "DEMO-made-up-NQ-ES-1min.csv"
_MONTHS = "HMUZ"  # Mar, Jun, Sep, Dec


def _contract(root: str, d: date) -> str:
    q = [3, 6, 9, 12]
    m = next((x for x in q if x > d.month or (x == d.month and d.day < 12)), None)
    y = d.year if m else d.year + 1
    m = m or 3
    return f"{root}{_MONTHS[q.index(m)]}{y % 10}"


def write_demo_csv(folder: str, days: int = 92, seed: int = 11) -> str:
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, DEMO_NAME)
    rng = np.random.default_rng(seed)
    chi = ZoneInfo("America/Chicago")
    end = date.today() - timedelta(days=1)
    start = end - timedelta(days=days)
    price = {"NQ": 21000.0, "ES": 6000.0}
    vol = {"NQ": 4.0, "ES": 0.9}
    minutes = np.arange(1440)
    with open(path, "w", newline="") as f:
        f.write("ts_event,rtype,publisher_id,instrument_id,open,high,low,close,volume,symbol\n")
        d = start
        while d <= end:
            wd = d.weekday()
            if wd == 5 or holiday_name(d) in ("Christmas", "New Year's Day", "Good Friday", "Thanksgiving"):
                d += timedelta(days=1)
                continue
            if wd == 6:
                mins = minutes[minutes >= 17 * 60]
            elif wd == 4:
                mins = minutes[minutes < 16 * 60]
            else:
                mins = minutes[(minutes < 16 * 60) | (minutes >= 17 * 60)]
            base = datetime(d.year, d.month, d.day, tzinfo=chi)
            off = int(base.utcoffset().total_seconds())
            epoch0 = int(datetime(d.year, d.month, d.day, tzinfo=timezone.utc).timestamp()) - off
            ts = epoch0 + mins * 60
            stamps = [datetime.fromtimestamp(int(t), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:00.000000000Z")
                      for t in ts]
            busy = (mins >= 8 * 60 + 30) & (mins < 10 * 60)  # 9:30-11:00 New York
            for root in ("NQ", "ES"):
                v = np.where(busy, vol[root] * 2.4, vol[root])
                drift = rng.normal(0, vol[root] * 0.05)
                closes = price[root] + np.cumsum(rng.normal(drift, v))
                opens = np.concatenate([[price[root]], closes[:-1]])
                hi = np.maximum(opens, closes) + np.abs(rng.normal(0, v * 0.6))
                lo = np.minimum(opens, closes) - np.abs(rng.normal(0, v * 0.6))
                q = lambda x: np.round(x * 4) / 4  # noqa: E731  quarter-point ticks
                o, h, l, c = q(opens), q(hi), q(lo), q(closes)
                vols = rng.integers(20, 2500, len(mins))
                price[root] = float(c[-1])
                sym = _contract(root, d)
                f.write("".join(f"{s},33,1,1,{o[i]:.2f},{h[i]:.2f},{l[i]:.2f},{c[i]:.2f},{vols[i]},{sym}\n"
                                for i, s in enumerate(stamps)))
            d += timedelta(days=1)
    return path
