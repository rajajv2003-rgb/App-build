"""Desktop stand-ins for the Android storage functions."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys


class DesktopSink:
    """Copies PNGs to <pictures_root>/FuturesCharts/<inst>/<start>_to_<end>/."""

    def __init__(self, pictures_root: str | None = None):
        self.root = os.path.expanduser(pictures_root or os.environ.get("STRATRADEGY_PICTURES") or "~/Pictures")

    def publish(self, local_png: str, req, filename: str) -> str:
        rel = req.public_rel_dir.split("/", 1)[1]  # drop leading "Pictures"
        dest_dir = os.path.join(self.root, rel)
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, filename)
        shutil.copyfile(local_png, dest)
        return dest


def share_image(path_or_uri: str, title: str = ""):
    """On desktop, reveal the file in the OS file manager."""
    path = path_or_uri
    if not path or not os.path.exists(path):
        return False
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", "-R", path])
        elif os.name == "nt":
            subprocess.Popen(["explorer", "/select,", path])
        else:
            subprocess.Popen(["xdg-open", os.path.dirname(path)])
        return True
    except OSError:
        return False


def publish_download(local_path: str, rel_dir: str, name: str, mime: str = "") -> str:
    """Desktop: copy into ~/Downloads/<rel_dir>/ (STRATRADEGY_DOWNLOADS overrides)."""
    root = os.path.expanduser(os.environ.get("STRATRADEGY_DOWNLOADS") or "~/Downloads")
    dest_dir = os.path.join(root, rel_dir)
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, name)
    if os.path.abspath(dest) != os.path.abspath(local_path):
        shutil.copyfile(local_path, dest)
    return dest


def open_uri(path: str, mime: str = "") -> bool:
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", path])
        elif os.name == "nt":
            os.startfile(path)  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", path])
        return True
    except OSError:
        return False
