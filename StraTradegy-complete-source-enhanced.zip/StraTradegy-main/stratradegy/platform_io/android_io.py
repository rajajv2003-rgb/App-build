"""Android storage via pyjnius: SAF file picker, MediaStore gallery saves, sharing.

Scoped storage (Android 10+/11+) notes
--------------------------------------
* Reading the CSV: we use the Storage Access Framework picker
  (ACTION_OPEN_DOCUMENT). No storage permission is needed; the user grants
  access to the chosen file(s). We take a *persistable* URI permission so the
  app can re-index later without asking again. The file is read through a raw
  file descriptor (ContentResolver.openFileDescriptor -> os.fdopen), so Python
  streams it at native speed and the 1 GB CSV is never copied.
* Writing PNGs: inserted into MediaStore.Images with
  RELATIVE_PATH = "Pictures/FuturesCharts/<inst>/<start>_to_<end>/". Apps may
  always write their own media on API 29+, so again no permission is needed,
  and the images show up in Google Photos / the Gallery app immediately.
* Sharing: the MediaStore content:// URI is passed to ACTION_SEND with a read
  grant, so no FileProvider is needed.
"""

from __future__ import annotations

import os

from jnius import autoclass, cast  # type: ignore

PythonActivity = autoclass("org.kivy.android.PythonActivity")
Intent = autoclass("android.content.Intent")
Uri = autoclass("android.net.Uri")
Activity = autoclass("android.app.Activity")
ContentValues = autoclass("android.content.ContentValues")
ContentUris = autoclass("android.content.ContentUris")
MediaStore = autoclass("android.provider.MediaStore")
ImagesMedia = autoclass("android.provider.MediaStore$Images$Media")
MediaColumns = autoclass("android.provider.MediaStore$MediaColumns")
OpenableColumns = autoclass("android.provider.OpenableColumns")
JString = autoclass("java.lang.String")
JInteger = autoclass("java.lang.Integer")
BuildVersion = autoclass("android.os.Build$VERSION")

REQUEST_PICK_CSV = 0x5CF1


def _activity():
    return PythonActivity.mActivity


def _resolver():
    return _activity().getContentResolver()


def api_level() -> int:
    return int(BuildVersion.SDK_INT)


# --------------------------------------------------------------------------- #
# picking & reading
# --------------------------------------------------------------------------- #
def _query_meta(uri):
    """(display_name, size) for a content URI."""
    name, size = uri.getLastPathSegment() or "data.csv", 0
    cursor = _resolver().query(uri, None, None, None, None)
    if cursor is not None:
        try:
            if cursor.moveToFirst():
                ni = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                si = cursor.getColumnIndex(OpenableColumns.SIZE)
                if ni >= 0 and not cursor.isNull(ni):
                    name = cursor.getString(ni)
                if si >= 0 and not cursor.isNull(si):
                    size = int(cursor.getLong(si))
        finally:
            cursor.close()
    return name, size


def pick_csv_files(callback, multiple: bool = True):
    """Open the system file picker. ``callback(list_of_source_dicts)`` runs on the
    Kivy thread; an empty list means the user cancelled."""
    from android import activity  # type: ignore
    from kivy.clock import Clock

    def on_result(request_code, result_code, data):
        if request_code != REQUEST_PICK_CSV:
            return
        activity.unbind(on_activity_result=on_result)
        picked = []
        if result_code == Activity.RESULT_OK and data is not None:
            uris = []
            clip = data.getClipData()
            if clip is not None:
                for i in range(clip.getItemCount()):
                    uris.append(clip.getItemAt(i).getUri())
            elif data.getData() is not None:
                uris.append(data.getData())
            for uri in uris:
                try:
                    _resolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                except Exception:
                    pass  # not all providers support persistable grants
                name, size = _query_meta(uri)
                picked.append({"name": name, "size": size, "uri": uri.toString(), "path": "", "mtime": 0.0})
        Clock.schedule_once(lambda dt: callback(picked), 0)

    activity.bind(on_activity_result=on_result)
    intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
    intent.addCategory(Intent.CATEGORY_OPENABLE)
    intent.setType("*/*")  # CSV MIME types are reported inconsistently by providers
    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, bool(multiple))
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
    _activity().startActivityForResult(intent, REQUEST_PICK_CSV)


def refresh_meta(uri_str: str):
    """Current (name, size) of a previously picked URI; raises if access was lost."""
    return _query_meta(Uri.parse(uri_str))


def open_uri_binary(uri_str: str):
    """Binary file object for a content:// URI, backed by a real fd (fast)."""
    uri = Uri.parse(uri_str)
    try:
        pfd = _resolver().openFileDescriptor(uri, "r")
    except Exception as exc:
        raise OSError(
            "Cannot open the CSV - access may have been revoked or the file moved. "
            "Pick the file again with 'Import CSV'."
        ) from exc
    fd = pfd.detachFd()
    return os.fdopen(fd, "rb", buffering=1024 * 1024)


# --------------------------------------------------------------------------- #
# MediaStore output
# --------------------------------------------------------------------------- #
def _images_collection():
    if api_level() >= 29:
        return ImagesMedia.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    return ImagesMedia.EXTERNAL_CONTENT_URI


def _find_existing(collection, rel_dir: str, name: str):
    proj = [MediaColumns._ID]
    sel = f"{MediaColumns.RELATIVE_PATH}=? AND {MediaColumns.DISPLAY_NAME}=?"
    cursor = _resolver().query(collection, proj, sel, [rel_dir, name], None)
    if cursor is None:
        return None
    try:
        if cursor.moveToFirst():
            return ContentUris.withAppendedId(collection, cursor.getLong(0))
    finally:
        cursor.close()
    return None


class MediaStoreSink:
    """Publishes PNGs to Pictures/FuturesCharts/... so they appear in the gallery."""

    def publish(self, local_png: str, req, filename: str) -> str:
        rel_dir = req.public_rel_dir.rstrip("/") + "/"
        collection = _images_collection()
        resolver = _resolver()
        uri = _find_existing(collection, rel_dir, filename)  # re-run: overwrite our own file
        mode = "wt"
        if uri is None:
            cv = ContentValues()
            cv.put(MediaColumns.DISPLAY_NAME, JString(filename))
            cv.put(MediaColumns.MIME_TYPE, JString("image/png"))
            cv.put(MediaColumns.RELATIVE_PATH, JString(rel_dir))
            try:
                cv.put(MediaColumns.IS_PENDING, JInteger(1))
            except Exception:
                pass
            uri = resolver.insert(collection, cv)
            if uri is None:
                raise OSError("MediaStore refused to create the image entry.")
            mode = "w"
        pfd = resolver.openFileDescriptor(uri, mode)
        with os.fdopen(pfd.detachFd(), "wb") as out, open(local_png, "rb") as src:
            while True:
                buf = src.read(1 << 20)
                if not buf:
                    break
                out.write(buf)
        try:
            cv = ContentValues()
            cv.put(MediaColumns.IS_PENDING, JInteger(0))
            resolver.update(uri, cv, None, None)
        except Exception:
            pass
        return uri.toString()


# --------------------------------------------------------------------------- #
# share & misc
# --------------------------------------------------------------------------- #
def share_image(uri_str: str, title: str = "Share chart") -> bool:
    if not uri_str or not uri_str.startswith("content://"):
        return False
    uri = Uri.parse(uri_str)
    intent = Intent(Intent.ACTION_SEND)
    intent.setType("image/png")
    intent.putExtra(Intent.EXTRA_STREAM, cast("android.os.Parcelable", uri))
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    chooser = Intent.createChooser(intent, cast("java.lang.CharSequence", JString(title)))
    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    _activity().startActivity(chooser)
    return True


def keep_screen_on(on: bool):
    """Stop the screen sleeping during long jobs (the work keeps running anyway)."""
    try:
        from android.runnable import run_on_ui_thread  # type: ignore

        LayoutParams = autoclass("android.view.WindowManager$LayoutParams")

        @run_on_ui_thread
        def _apply():
            win = _activity().getWindow()
            if on:
                win.addFlags(LayoutParams.FLAG_KEEP_SCREEN_ON)
            else:
                win.clearFlags(LayoutParams.FLAG_KEEP_SCREEN_ON)

        _apply()
    except Exception:
        pass


def system_bar_insets(window_height: int) -> tuple[int, int]:
    """(top, bottom) pixels hidden by the status bar and gesture/navigation bar.

    Apps targeting Android 15 (API 35) are drawn edge-to-edge, behind those bars.
    Returns (0, 0) when the app window already excludes them."""
    try:
        act = _activity()
        win = act.getWindow()
        decor = win.getDecorView()
        metrics = autoclass("android.util.DisplayMetrics")()
        act.getWindowManager().getDefaultDisplay().getRealMetrics(metrics)
        content = autoclass("android.graphics.Rect")()
        decor.getWindowVisibleDisplayFrame(content)
        ins = decor.getRootWindowInsets()
        if ins is not None and api_level() >= 30:
            Type = autoclass("android.view.WindowInsets$Type")
            bars = ins.getInsets(Type.systemBars() | Type.displayCutout())
            top, bottom = int(bars.top), int(bars.bottom)
        else:
            res = act.getResources()

            def dim(name):
                rid = res.getIdentifier(name, "dimen", "android")
                return int(res.getDimensionPixelSize(rid)) if rid > 0 else 0

            top, bottom = dim("status_bar_height"), dim("navigation_bar_height")
        if window_height < metrics.heightPixels - max(top, bottom) // 2:
            return 0, 0  # window already sits between the bars
        return top, bottom
    except Exception:
        return 0, 0


# --------------------------------------------------------------------------- #
# Downloads folder (backtest CSV / PDF)
# --------------------------------------------------------------------------- #
def publish_download(local_path: str, rel_dir: str, name: str, mime: str) -> str:
    """Copy a file into the public Download/<rel_dir>/ via MediaStore (no permission
    needed on Android 10+). Overwrites our own earlier copy. Returns the content URI."""
    Downloads = autoclass("android.provider.MediaStore$Downloads")
    collection = Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    resolver = _resolver()
    rel = "Download/" + rel_dir.strip("/") + "/"
    uri = _find_existing(collection, rel, name)
    mode = "wt"
    if uri is None:
        cv = ContentValues()
        cv.put(MediaColumns.DISPLAY_NAME, JString(name))
        cv.put(MediaColumns.MIME_TYPE, JString(mime))
        cv.put(MediaColumns.RELATIVE_PATH, JString(rel))
        uri = resolver.insert(collection, cv)
        if uri is None:
            raise OSError("Android refused to create the file in Downloads.")
        mode = "w"
    pfd = resolver.openFileDescriptor(uri, mode)
    with os.fdopen(pfd.detachFd(), "wb") as out, open(local_path, "rb") as src:
        while True:
            buf = src.read(1 << 20)
            if not buf:
                break
            out.write(buf)
    return uri.toString()


def toast(text: str):
    try:
        from android.runnable import run_on_ui_thread  # type: ignore

        Toast = autoclass("android.widget.Toast")

        @run_on_ui_thread
        def _show():
            Toast.makeText(_activity(), cast("java.lang.CharSequence", JString(text)), Toast.LENGTH_LONG).show()

        _show()
    except Exception:
        pass


def open_uri(uri_str: str, mime: str) -> bool:
    """Open a saved file (e.g. the PDF) in the user's viewer app."""
    try:
        intent = Intent(Intent.ACTION_VIEW)
        intent.setDataAndType(Uri.parse(uri_str), mime)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK)
        _activity().startActivity(intent)
        return True
    except Exception:
        return False
