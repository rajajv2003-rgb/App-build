"""Platform-specific storage: Android (SAF + MediaStore via pyjnius) or desktop."""

import os
import sys


def is_android() -> bool:
    return "ANDROID_ARGUMENT" in os.environ or "ANDROID_PRIVATE" in os.environ or hasattr(sys, "getandroidapilevel")


def app_storage_dir(app_name: str = "stratradegy") -> str:
    """Private, permission-free storage for settings, cache and local PNG copies."""
    override = os.environ.get("STRATRADEGY_HOME")
    if override:
        os.makedirs(override, exist_ok=True)
        return override
    if is_android():
        try:
            from android.storage import app_storage_path  # type: ignore

            return app_storage_path()
        except ImportError:
            return os.environ.get("ANDROID_PRIVATE", os.getcwd())
    if sys.platform == "darwin":
        base = os.path.expanduser("~/Library/Application Support")
    elif os.name == "nt":
        base = os.environ.get("APPDATA", os.path.expanduser("~"))
    else:
        base = os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share"))
    path = os.path.join(base, app_name)
    os.makedirs(path, exist_ok=True)
    return path
